// Package store persiste a linha de base (o "habitual"), o histórico de análises
// e o cache de pesquisas em arquivos JSON no diretório de dados.
package store

import (
	"encoding/json"
	"os"
	"path/filepath"
	"sort"
	"time"

	"logcentralizer/internal/util"
)

const baselineVersion = 1

// TemplateInfo descreve um modelo de mensagem já visto.
type TemplateInfo struct {
	Source string    `json:"fonte"`
	Text   string    `json:"texto"`
	First  time.Time `json:"primeira"`
	Last   time.Time `json:"ultima"`
	Count  int64     `json:"contagem"`
}

// Entity é algo conhecido (IP, usuário, porta, executável, hash de arquivo...).
type Entity struct {
	First time.Time `json:"primeira"`
	Last  time.Time `json:"ultima"`
	Count int64     `json:"contagem"`
	Extra string    `json:"extra,omitempty"`
}

// FileInfo guarda metadados de arquivos de log para detectar truncamento/remoção.
type FileInfo struct {
	Inode uint64    `json:"inode"`
	Size  int64     `json:"tamanho"`
	MTime time.Time `json:"mtime"`
}

// Baseline é o modelo do comportamento habitual da máquina.
type Baseline struct {
	Version   int                           `json:"versao"`
	Created   time.Time                     `json:"criada"`
	LastRun   time.Time                     `json:"ultima_execucao"`
	Runs      int                           `json:"execucoes"`
	Hours     map[string]map[string]int     `json:"horas"`      // fonte -> hora -> contagem
	Covered   map[string]bool               `json:"cobertas"`   // horas em que a máquina estava ligada
	Templates map[string]*TemplateInfo      `json:"modelos"`    // hash -> modelo
	Entities  map[string]map[string]*Entity `json:"entidades"`  // categoria -> valor -> entidade
	Counters  map[string]float64            `json:"contadores"` // contadores monotônicos (EDAC, SMART...)
	Files     map[string]FileInfo           `json:"arquivos"`
	Metrics   map[string]map[string]float64 `json:"metricas"` // métrica -> hora -> valor
}

func NewBaseline() *Baseline {
	return &Baseline{
		Version:   baselineVersion,
		Created:   time.Now(),
		Hours:     map[string]map[string]int{},
		Covered:   map[string]bool{},
		Templates: map[string]*TemplateInfo{},
		Entities:  map[string]map[string]*Entity{},
		Counters:  map[string]float64{},
		Files:     map[string]FileInfo{},
		Metrics:   map[string]map[string]float64{},
	}
}

func (b *Baseline) ensure() {
	if b.Hours == nil {
		b.Hours = map[string]map[string]int{}
	}
	if b.Covered == nil {
		b.Covered = map[string]bool{}
	}
	if b.Templates == nil {
		b.Templates = map[string]*TemplateInfo{}
	}
	if b.Entities == nil {
		b.Entities = map[string]map[string]*Entity{}
	}
	if b.Counters == nil {
		b.Counters = map[string]float64{}
	}
	if b.Files == nil {
		b.Files = map[string]FileInfo{}
	}
	if b.Metrics == nil {
		b.Metrics = map[string]map[string]float64{}
	}
}

// LoadBaseline carrega a linha de base (ou cria uma nova).
func LoadBaseline(dir string) (*Baseline, error) {
	b := NewBaseline()
	data, err := os.ReadFile(filepath.Join(dir, "linha_de_base.json"))
	if err != nil {
		if os.IsNotExist(err) {
			return b, nil
		}
		return nil, err
	}
	if err := json.Unmarshal(data, b); err != nil {
		return nil, err
	}
	b.ensure()
	return b, nil
}

// Save grava a linha de base de forma atômica.
func (b *Baseline) Save(dir string) error {
	data, err := json.Marshal(b)
	if err != nil {
		return err
	}
	return util.WriteFileAtomic(filepath.Join(dir, "linha_de_base.json"), data, 0o600)
}

// AddHour soma contagem a uma fonte/hora.
func (b *Baseline) AddHour(source, hour string, n int) {
	m := b.Hours[source]
	if m == nil {
		m = map[string]int{}
		b.Hours[source] = m
	}
	m[hour] += n
}

// HasEntityCategory informa se a categoria já foi inicializada.
func (b *Baseline) HasEntityCategory(cat string) bool {
	_, ok := b.Entities[cat]
	return ok
}

// KnownEntity informa se o valor já é conhecido na categoria.
func (b *Baseline) KnownEntity(cat, val string) bool {
	m := b.Entities[cat]
	if m == nil {
		return false
	}
	_, ok := m[val]
	return ok
}

// GetEntity devolve a entidade, se existir.
func (b *Baseline) GetEntity(cat, val string) *Entity {
	if m := b.Entities[cat]; m != nil {
		return m[val]
	}
	return nil
}

// InitCategory cria a categoria vazia (marca como inicializada).
func (b *Baseline) InitCategory(cat string) {
	if b.Entities[cat] == nil {
		b.Entities[cat] = map[string]*Entity{}
	}
}

// TouchEntity registra/atualiza uma entidade.
func (b *Baseline) TouchEntity(cat, val, extra string, t time.Time) {
	b.InitCategory(cat)
	e := b.Entities[cat][val]
	if e == nil {
		e = &Entity{First: t, Last: t}
		b.Entities[cat][val] = e
	}
	if t.Before(e.First) {
		e.First = t
	}
	if t.After(e.Last) {
		e.Last = t
	}
	e.Count++
	if extra != "" {
		e.Extra = extra
	}
}

// CoveredHoursSince devolve as horas cobertas a partir de since, ordenadas.
func (b *Baseline) CoveredHoursSince(since time.Time) []string {
	var out []string
	k0 := util.HourKey(since)
	for h := range b.Covered {
		if h >= k0 {
			out = append(out, h)
		}
	}
	sort.Strings(out)
	return out
}

// Prune remove dados mais antigos que as janelas configuradas.
func (b *Baseline) Prune(now time.Time, baselineDays, entityDays, maxTemplatesPerSource int) {
	cut := util.HourKey(now.AddDate(0, 0, -baselineDays))
	for h := range b.Covered {
		if h < cut {
			delete(b.Covered, h)
		}
	}
	for s, m := range b.Hours {
		for h := range m {
			if h < cut {
				delete(m, h)
			}
		}
		if len(m) == 0 {
			delete(b.Hours, s)
		}
	}
	for s, m := range b.Metrics {
		for h := range m {
			if h < cut {
				delete(m, h)
			}
		}
		if len(m) == 0 {
			delete(b.Metrics, s)
		}
	}
	if entityDays > 0 {
		ecut := now.AddDate(0, 0, -entityDays)
		for _, m := range b.Entities {
			for k, e := range m {
				if e.Last.Before(ecut) {
					delete(m, k)
				}
			}
		}
		for k, t := range b.Templates {
			if t.Last.Before(ecut) {
				delete(b.Templates, k)
			}
		}
	}
	// limita modelos por fonte (remove os menos recentes)
	per := map[string][]string{}
	for k, t := range b.Templates {
		per[t.Source] = append(per[t.Source], k)
	}
	for _, keys := range per {
		if len(keys) <= maxTemplatesPerSource {
			continue
		}
		sort.Slice(keys, func(i, j int) bool { return b.Templates[keys[i]].Last.After(b.Templates[keys[j]].Last) })
		for _, k := range keys[maxTemplatesPerSource:] {
			delete(b.Templates, k)
		}
	}
}

// ---------------------------------------------------------------- histórico

// HistoryEntry resume uma análise realizada.
type HistoryEntry struct {
	Time        time.Time        `json:"data"`
	Since       time.Time        `json:"inicio_periodo"`
	Until       time.Time        `json:"fim_periodo"`
	DurationSec float64          `json:"duracao_segundos"`
	Events      int64            `json:"eventos"`
	BySource    map[string]int64 `json:"eventos_por_fonte"`
	Severities  map[string]int   `json:"severidades"`
	Verdict     string           `json:"veredito"`
	Top         []string         `json:"principais_anomalias"`
	Report      string           `json:"relatorio"`
	Backup      string           `json:"backup"`
	Learning    bool             `json:"aprendizado"`
	Sensitivity string           `json:"sensibilidade"`
}

func historyPath(dir string) string { return filepath.Join(dir, "historico.json") }

// LoadHistory carrega o histórico.
func LoadHistory(dir string) ([]HistoryEntry, error) {
	data, err := os.ReadFile(historyPath(dir))
	if err != nil {
		if os.IsNotExist(err) {
			return nil, nil
		}
		return nil, err
	}
	var h []HistoryEntry
	if err := json.Unmarshal(data, &h); err != nil {
		return nil, err
	}
	return h, nil
}

// SaveHistory grava o histórico limitado a max registros.
func SaveHistory(dir string, h []HistoryEntry, max int) error {
	if max > 0 && len(h) > max {
		h = h[len(h)-max:]
	}
	data, err := json.MarshalIndent(h, "", "  ")
	if err != nil {
		return err
	}
	return util.WriteFileAtomic(historyPath(dir), data, 0o600)
}

// ---------------------------------------------------------------- cache de busca

// CachedSearch guarda resultados de uma consulta.
type CachedSearch struct {
	Time    time.Time         `json:"data"`
	Engine  string            `json:"motor"`
	Results []json.RawMessage `json:"resultados"`
}

// SearchCache é um cache simples em disco.
type SearchCache struct {
	Entries map[string]*CachedSearch `json:"consultas"`
	path    string
}

// LoadSearchCache carrega o cache.
func LoadSearchCache(dir string) *SearchCache {
	c := &SearchCache{Entries: map[string]*CachedSearch{}, path: filepath.Join(dir, "cache_busca.json")}
	if data, err := os.ReadFile(c.path); err == nil {
		_ = json.Unmarshal(data, c)
		if c.Entries == nil {
			c.Entries = map[string]*CachedSearch{}
		}
	}
	return c
}

// Save grava o cache removendo entradas expiradas.
func (c *SearchCache) Save(maxAge time.Duration) error {
	for k, e := range c.Entries {
		if time.Since(e.Time) > maxAge {
			delete(c.Entries, k)
		}
	}
	data, err := json.Marshal(c)
	if err != nil {
		return err
	}
	return util.WriteFileAtomic(c.path, data, 0o600)
}
