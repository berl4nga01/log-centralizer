// Package backup cria cópias compactadas (.tar.gz, opcionalmente criptografadas)
// de todos os logs a cada análise, com manifesto SHA-256 para verificar integridade.
package backup

import (
	"archive/tar"
	"compress/gzip"
	"context"
	"crypto/sha256"
	"encoding/hex"
	"fmt"
	"io"
	"io/fs"
	"os"
	"path/filepath"
	"sort"
	"strings"
	"syscall"
	"time"

	"logcentralizer/internal/config"
	"logcentralizer/internal/util"
)

// Info descreve um backup criado.
type Info struct {
	Path      string
	Size      int64
	Files     int
	Skipped   []string
	SHA256    string
	Duration  time.Duration
	Encrypted bool
	Removed   []string
	Journal   string
}

// Meta são informações gravadas dentro do backup.
type Meta struct {
	Host    string
	Since   time.Time
	Until   time.Time
	Verdict string
	Report  string
	Anomaly int
}

// FreePercent devolve o percentual livre do sistema de arquivos de path.
func FreePercent(path string) (float64, int64) {
	var st syscall.Statfs_t
	for p := path; p != "/" && p != "."; p = filepath.Dir(p) {
		if syscall.Statfs(p, &st) == nil {
			break
		}
	}
	if st.Blocks == 0 {
		_ = syscall.Statfs("/", &st)
	}
	if st.Blocks == 0 {
		return 100, 0
	}
	free := int64(st.Bavail) * int64(st.Bsize)
	return float64(st.Bavail) / float64(st.Blocks) * 100, free
}

// Create gera um backup completo (recapitulação geral de todos os logs).
func Create(ctx context.Context, cfg *config.Config, meta Meta, now time.Time) (*Info, error) {
	b := cfg.Backup
	t0 := time.Now()
	if err := os.MkdirAll(b.Diretorio, 0o700); err != nil {
		return nil, err
	}
	if pct, free := FreePercent(b.Diretorio); pct < b.EspacoLivreMinimoPercentual {
		return nil, fmt.Errorf("backup cancelado: apenas %.1f%% (%s) livre em %s; mínimo configurado %.0f%%",
			pct, util.HumanBytes(free), b.Diretorio, b.EspacoLivreMinimoPercentual)
	}
	host := strings.ReplaceAll(cfg.NomeHost, "/", "_")
	name := fmt.Sprintf("logcentralizer_%s_%s.tar.gz", host, now.Format("20060102_150405"))
	var pass string
	if b.Criptografia.Ativo {
		p, err := ReadPassphrase(b.Criptografia.ArquivoSenha)
		if err != nil {
			return nil, err
		}
		pass = p
		name += ".enc"
	}
	final := filepath.Join(b.Diretorio, name)
	for i := 2; util.Exists(final); i++ {
		final = filepath.Join(b.Diretorio, strings.Replace(name, ".tar.gz", fmt.Sprintf("_%d.tar.gz", i), 1))
	}
	tmp := final + ".parcial"
	f, err := os.OpenFile(tmp, os.O_CREATE|os.O_WRONLY|os.O_TRUNC, 0o600)
	if err != nil {
		return nil, err
	}
	info := &Info{Path: final, Encrypted: pass != ""}
	cleanup := func() { f.Close(); os.Remove(tmp) }

	var sink io.Writer = f
	var enc *encWriter
	if pass != "" {
		enc, err = newEncWriter(f, pass)
		if err != nil {
			cleanup()
			return nil, err
		}
		sink = enc
	}
	gz, _ := gzip.NewWriterLevel(sink, gzip.DefaultCompression)
	tw := tar.NewWriter(gz)
	var manifest strings.Builder
	maxSize := int64(b.TamanhoMaxArquivoMB) * 1024 * 1024

	excluded := func(p string) bool {
		for _, e := range b.Excluir {
			e = strings.TrimSuffix(e, "/")
			if p == e || strings.HasPrefix(p, e+"/") {
				return true
			}
			if ok, _ := filepath.Match(e, p); ok {
				return true
			}
		}
		bd := strings.TrimSuffix(b.Diretorio, "/")
		return p == bd || strings.HasPrefix(p, bd+"/")
	}

	addFile := func(path, arcName string, st fs.FileInfo) error {
		if st.Mode()&fs.ModeSymlink != 0 {
			target, err := os.Readlink(path)
			if err != nil {
				return nil
			}
			hdr, _ := tar.FileInfoHeader(st, target)
			hdr.Name = arcName
			return tw.WriteHeader(hdr)
		}
		if !st.Mode().IsRegular() {
			return nil
		}
		if maxSize > 0 && st.Size() > maxSize {
			info.Skipped = append(info.Skipped, fmt.Sprintf("%s (%s, acima do limite)", path, util.HumanBytes(st.Size())))
			return nil
		}
		src, err := os.Open(path)
		if err != nil {
			info.Skipped = append(info.Skipped, path+" ("+err.Error()+")")
			return nil
		}
		defer src.Close()
		hdr, _ := tar.FileInfoHeader(st, "")
		hdr.Name = arcName
		hdr.Uname, hdr.Gname = "", ""
		if err := tw.WriteHeader(hdr); err != nil {
			return err
		}
		h := sha256.New()
		n, err := io.CopyN(io.MultiWriter(tw, h), src, st.Size())
		if err != nil && err != io.EOF {
			return err
		}
		if n < st.Size() { // arquivo encolheu durante a cópia: completa com zeros
			pad := make([]byte, st.Size()-n)
			tw.Write(pad)
			h.Write(pad)
		}
		manifest.WriteString(hex.EncodeToString(h.Sum(nil)) + "  " + arcName + "\n")
		info.Files++
		return nil
	}

	roots := append([]string{}, b.Caminhos...)
	if cfg.DiretorioDados != "" {
		roots = append(roots, cfg.DiretorioDados)
	}
	seen := map[string]bool{}
	for _, root := range roots {
		root = filepath.Clean(root)
		if seen[root] || !util.Exists(root) {
			continue
		}
		seen[root] = true
		err := filepath.WalkDir(root, func(p string, d fs.DirEntry, err error) error {
			if ctx.Err() != nil {
				return ctx.Err()
			}
			if err != nil {
				info.Skipped = append(info.Skipped, p+" ("+err.Error()+")")
				if d != nil && d.IsDir() {
					return fs.SkipDir
				}
				return nil
			}
			if excluded(p) {
				if d.IsDir() {
					return fs.SkipDir
				}
				return nil
			}
			if d.IsDir() {
				return nil
			}
			st, err := os.Lstat(p)
			if err != nil {
				return nil
			}
			return addFile(p, strings.TrimPrefix(p, "/"), st)
		})
		if err != nil {
			tw.Close()
			gz.Close()
			cleanup()
			return nil, err
		}
	}

	// exportação do journal em texto (o journal binário fica excluído por padrão)
	if b.ExportacaoJournal != "nenhuma" && util.CmdExists("journalctl") {
		jt := filepath.Join(b.Diretorio, ".journal_export.tmp")
		args := []string{"--no-pager", "-q", "-o", "short-iso-precise"}
		desc := "journal completo"
		if b.ExportacaoJournal == "periodo" && !meta.Since.IsZero() {
			args = append(args, "--since", fmt.Sprintf("@%d", meta.Since.Unix()), "--until", fmt.Sprintf("@%d", meta.Until.Unix()))
			desc = "journal do período analisado"
		}
		if jf, err := os.OpenFile(jt, os.O_CREATE|os.O_WRONLY|os.O_TRUNC, 0o600); err == nil {
			_ = util.RunLines(ctx, func(l string) { jf.WriteString(l + "\n") }, "journalctl", args...)
			jf.Close()
			if st, err := os.Stat(jt); err == nil && st.Size() > 0 {
				if err := addFile(jt, "journal/journal_exportado.log", st); err == nil {
					info.Journal = desc + " (" + util.HumanBytes(st.Size()) + ")"
				}
			}
			os.Remove(jt)
		}
	}

	// manifesto e informações
	periodo := "-"
	if !meta.Since.IsZero() {
		periodo = meta.Since.Format("02/01/2006 15:04") + " até " + meta.Until.Format("02/01/2006 15:04")
	}
	infoTxt := fmt.Sprintf("logcentralizer - backup de logs\nHost: %s\nCriado em: %s\nPeríodo analisado: %s\nVeredito da análise: %s\nAnomalias: %d\nRelatório: %s\nArquivos: %d\n",
		meta.Host, now.Format("02/01/2006 15:04:05"), periodo, meta.Verdict, meta.Anomaly, meta.Report, info.Files)
	for _, extra := range []struct{ name, body string }{
		{"LEIA-ME.txt", infoTxt + "\nVerifique a integridade com:\n  tar -xzf <backup> -C /tmp/restauro && cd /tmp/restauro && sha256sum -c MANIFESTO.sha256\n"},
		{"MANIFESTO.sha256", manifest.String()},
	} {
		hdr := &tar.Header{Name: extra.name, Mode: 0o600, Size: int64(len(extra.body)), ModTime: time.Now().Add(-time.Second).Truncate(time.Second), Typeflag: tar.TypeReg}
		if err := tw.WriteHeader(hdr); err == nil {
			tw.Write([]byte(extra.body))
		}
	}
	if err := tw.Close(); err != nil {
		gz.Close()
		cleanup()
		return nil, err
	}
	if err := gz.Close(); err != nil {
		cleanup()
		return nil, err
	}
	if enc != nil {
		if err := enc.Close(); err != nil {
			cleanup()
			return nil, err
		}
	}
	if err := f.Sync(); err != nil {
		cleanup()
		return nil, err
	}
	f.Close()
	if err := os.Rename(tmp, final); err != nil {
		os.Remove(tmp)
		return nil, err
	}
	sum, err := util.SHA256File(final)
	if err != nil {
		return nil, err
	}
	info.SHA256 = sum
	_ = os.WriteFile(final+".sha256", []byte(sum+"  "+filepath.Base(final)+"\n"), 0o600)
	if st, err := os.Stat(final); err == nil {
		info.Size = st.Size()
	}
	info.Removed = applyRetention(b, now)
	info.Duration = time.Since(t0)
	return info, nil
}

// Entry é um backup existente.
type Entry struct {
	Path    string
	Size    int64
	ModTime time.Time
	HasSum  bool
}

// List lista os backups do diretório (mais recentes primeiro).
func List(dir string) []Entry {
	var out []Entry
	files, _ := filepath.Glob(filepath.Join(dir, "logcentralizer_*.tar.gz*"))
	for _, f := range files {
		if strings.HasSuffix(f, ".sha256") || strings.HasSuffix(f, ".parcial") {
			continue
		}
		st, err := os.Stat(f)
		if err != nil {
			continue
		}
		out = append(out, Entry{Path: f, Size: st.Size(), ModTime: st.ModTime(), HasSum: util.Exists(f + ".sha256")})
	}
	sort.Slice(out, func(i, j int) bool { return out[i].ModTime.After(out[j].ModTime) })
	return out
}

func applyRetention(b config.Backup, now time.Time) []string {
	var removed []string
	list := List(b.Diretorio)
	for i, e := range list {
		del := false
		if b.RetencaoDias > 0 && now.Sub(e.ModTime) > time.Duration(b.RetencaoDias)*24*time.Hour {
			del = true
		}
		if b.MaxBackups > 0 && i >= b.MaxBackups {
			del = true
		}
		if del {
			os.Remove(e.Path)
			os.Remove(e.Path + ".sha256")
			removed = append(removed, filepath.Base(e.Path))
		}
	}
	return removed
}

// VerifyResult é o resultado da verificação de um backup.
type VerifyResult struct {
	Path string
	OK   bool
	Msg  string
}

// Verify confere o SHA-256 de todos os backups.
func Verify(dir string) []VerifyResult {
	var out []VerifyResult
	for _, e := range List(dir) {
		r := VerifyResult{Path: e.Path}
		data, err := os.ReadFile(e.Path + ".sha256")
		if err != nil {
			r.Msg = "arquivo .sha256 ausente"
			out = append(out, r)
			continue
		}
		want := strings.Fields(string(data))
		got, err := util.SHA256File(e.Path)
		switch {
		case err != nil:
			r.Msg = err.Error()
		case len(want) == 0 || want[0] != got:
			r.Msg = "HASH DIFERENTE: o arquivo foi alterado ou corrompido"
		default:
			r.OK, r.Msg = true, "íntegro"
		}
		out = append(out, r)
	}
	return out
}
