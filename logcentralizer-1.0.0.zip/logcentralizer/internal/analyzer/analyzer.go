// Package analyzer orquestra os coletores, compara os eventos atuais com a linha
// de base (o comportamento habitual) e produz a lista de anomalias.
package analyzer

import (
	"context"
	"fmt"
	"io"
	"os"
	"regexp"
	"sort"
	"strings"
	"sync"
	"time"

	"logcentralizer/internal/collectors"
	"logcentralizer/internal/config"
	"logcentralizer/internal/model"
	"logcentralizer/internal/store"
	"logcentralizer/internal/util"
)

// Options controla uma execução.
type Options struct {
	OnlySources []string      // limitar a estas fontes (vazio = todas)
	Lookback    time.Duration // forçar janela (0 = automático)
	Verbose     bool
	Out         io.Writer // progresso
	Now         time.Time
}

// SourceStat resume uma fonte na execução.
type SourceStat struct {
	ID, Name, Category string
	Available          bool
	Enabled            bool
	Mode               string
	Notes              []string
	Error              string
	Events             int64
	Ignored            int64
	Duration           time.Duration
	BaseMeanPerHour    float64
	CurPerHour         float64
	Snapshot           bool
	BaseHours          int
}

// Result é o resultado completo de uma análise.
type Result struct {
	Host            string
	Start           time.Time
	Since, Until    time.Time
	Duration        time.Duration
	Bootstrap       bool
	BootstrapSince  time.Time
	BootstrapEvents int64
	Learning        bool
	BaseHoursBefore int
	BaseHoursAfter  int
	MinHours        int
	CurrentHours    int
	Sources         []*SourceStat
	Anomalies       []*model.Anomaly
	TotalEvents     int64
	Snapshot        []string
	Sensitivity     string
	SensParams      config.Sensibilidade
	Templates       int
	EntityCounts    map[string]int
	Runs            int
	Verdict         string
}

// SeverityCounts conta anomalias por severidade.
func (r *Result) SeverityCounts() map[string]int {
	m := map[string]int{}
	for _, a := range r.Anomalies {
		m[a.Severity.String()]++
	}
	return m
}

type burst struct {
	times    []time.Time
	evidence []string
	extra    map[string]bool
	sources  map[string]bool
	ports    []int // para varredura
}

type entityTouch struct {
	cat, val, extra string
	t               time.Time
}

// Analyzer guarda o estado de uma execução.
type Analyzer struct {
	cfg  *config.Config
	base *store.Baseline
	opt  Options

	learn    bool // passada atual é só de aprendizado
	learning bool // linha de base insuficiente: regras de novidade/volume desligadas

	mu         sync.Mutex
	anomalies  map[string]*model.Anomaly
	curHours   map[string]map[string]int
	curCovered map[string]bool
	pendTpl    map[string]*store.TemplateInfo
	pendEnt    []entityTouch
	pendCnt    map[string]float64
	stats      map[string]*SourceStat

	bursts     map[string]*burst // regra|chave
	sshOK      map[string][]time.Time
	counters   map[string]int
	usbAnom    map[string]*model.Anomaly
	web5xx     map[string]int
	spikeHours map[string]map[string]bool
	snapshot   []string
	uidOf      map[string]int
	maxTemp    float64
	procTotal  float64
}

// New cria um analisador.
func New(cfg *config.Config, base *store.Baseline, opt Options) *Analyzer {
	if opt.Now.IsZero() {
		opt.Now = time.Now()
	}
	if opt.Out == nil {
		opt.Out = io.Discard
	}
	return &Analyzer{cfg: cfg, base: base, opt: opt}
}

func (a *Analyzer) reset() {
	a.anomalies = map[string]*model.Anomaly{}
	a.curHours = map[string]map[string]int{}
	a.curCovered = map[string]bool{}
	a.pendTpl = map[string]*store.TemplateInfo{}
	a.pendEnt = nil
	a.pendCnt = map[string]float64{}
	a.bursts = map[string]*burst{}
	a.sshOK = map[string][]time.Time{}
	a.counters = map[string]int{}
	a.usbAnom = map[string]*model.Anomaly{}
	a.web5xx = map[string]int{}
	a.spikeHours = map[string]map[string]bool{}
	a.snapshot = nil
	a.uidOf = readUIDs()
}

func (a *Analyzer) logf(format string, args ...any) {
	fmt.Fprintf(a.opt.Out, format+"\n", args...)
}

func (a *Analyzer) debugf(format string, args ...any) {
	if a.opt.Verbose {
		fmt.Fprintf(a.opt.Out, "  [debug] "+format+"\n", args...)
	}
}

// Run executa a análise completa.
func (a *Analyzer) Run(ctx context.Context) (*Result, error) {
	a.reset()
	now := a.opt.Now
	res := &Result{Host: a.cfg.NomeHost, Start: now, Sensitivity: a.cfg.Deteccao.Sensibilidade,
		SensParams: a.cfg.SensitivityParams(), MinHours: a.cfg.LinhaDeBase.HorasMinimas}

	all := collectors.All(a.cfg)
	var active []collectors.Collector
	for _, c := range all {
		st := &SourceStat{ID: c.ID(), Name: c.Name(), Category: c.Category(), Snapshot: c.SnapshotOnly()}
		st.Enabled = a.cfg.SourceEnabled(c.ID())
		if len(a.opt.OnlySources) > 0 && !config.Contains(a.opt.OnlySources, c.ID()) {
			st.Enabled = false
		}
		if st.Enabled {
			p := c.Probe(a.cfg)
			st.Available, st.Mode, st.Notes = p.Available, p.Mode, p.Notes
			if p.Available {
				active = append(active, c)
			}
		} else {
			st.Notes = []string{"desativada"}
		}
		a.stats = mapSet(a.stats, c.ID(), st)
		res.Sources = append(res.Sources, st)
	}

	// ----------------------------------------------------------- janela
	until := now
	var since time.Time
	switch {
	case a.opt.Lookback > 0:
		since = now.Add(-a.opt.Lookback)
	case a.base.LastRun.IsZero():
		since = now.Add(-time.Duration(a.cfg.Analise.JanelaInicialHoras) * time.Hour)
	default:
		since = a.base.LastRun
		max := now.AddDate(0, 0, -a.cfg.Analise.RetroativoMaximoDias)
		if a.cfg.Analise.RetroativoMaximoDias > 0 && since.Before(max) {
			since = max
		}
	}
	if !since.Before(until) {
		since = until.Add(-time.Minute)
	}
	res.Since, res.Until = since, until

	// ----------------------------------------------------------- passada de aprendizado (primeira execução)
	if a.base.Runs == 0 && len(a.base.Covered) == 0 {
		bs := since.AddDate(0, 0, -a.cfg.LinhaDeBase.Dias)
		a.logf("• Primeira execução: construindo a linha de base com os logs antigos (%s → %s)...",
			bs.Format("02/01 15:04"), since.Format("02/01 15:04"))
		a.learn = true
		n := a.pass(ctx, active, bs, since)
		a.learn = false
		res.Bootstrap, res.BootstrapSince, res.BootstrapEvents = true, bs, n
		// incorpora as horas aprendidas
		for src, m := range a.curHours {
			for h, c := range m {
				a.base.AddHour(src, h, c)
			}
		}
		for h := range a.curCovered {
			a.base.Covered[h] = true
		}
		if len(a.base.Covered) >= a.cfg.LinhaDeBase.HorasMinimas {
			for _, c := range logCategories {
				a.base.InitCategory(c)
			}
		}
		a.curHours = map[string]map[string]int{}
		a.curCovered = map[string]bool{}
		for _, st := range a.stats {
			st.Events, st.Ignored, st.Duration, st.Error = 0, 0, 0, ""
		}
		a.logf("  %d eventos históricos aprendidos, %d horas de atividade na linha de base.", n, len(a.base.Covered))
	}

	res.BaseHoursBefore = len(a.base.CoveredHoursSince(now.AddDate(0, 0, -a.cfg.LinhaDeBase.Dias)))
	a.learning = res.BaseHoursBefore < a.cfg.LinhaDeBase.HorasMinimas
	res.Learning = a.learning

	// ----------------------------------------------------------- passada de detecção
	a.logf("• Analisando %d fontes de %s até %s...", len(active), since.Format("02/01/2006 15:04"), until.Format("02/01/2006 15:04"))
	res.TotalEvents = a.pass(ctx, active, since, until)

	a.finalize(all, active)
	res.CurrentHours = len(a.curCovered)

	// estatísticas por fonte
	baseKeys := a.base.CoveredHoursSince(now.AddDate(0, 0, -a.cfg.LinhaDeBase.Dias))
	for _, st := range res.Sources {
		if st.Snapshot {
			continue
		}
		var sum int
		for _, h := range baseKeys {
			sum += a.base.Hours[st.ID][h]
		}
		st.BaseHours = len(baseKeys)
		if len(baseKeys) > 0 {
			st.BaseMeanPerHour = float64(sum) / float64(len(baseKeys))
		}
		if len(a.curCovered) > 0 {
			st.CurPerHour = float64(st.Events) / float64(len(a.curCovered))
		}
	}

	a.commit(active, until)
	res.BaseHoursAfter = len(a.base.CoveredHoursSince(now.AddDate(0, 0, -a.cfg.LinhaDeBase.Dias)))
	res.Templates = len(a.base.Templates)
	res.EntityCounts = map[string]int{}
	for k, m := range a.base.Entities {
		res.EntityCounts[k] = len(m)
	}
	res.Runs = a.base.Runs

	for _, an := range a.anomalies {
		an.SeverityStr = an.Severity.String()
		res.Anomalies = append(res.Anomalies, an)
	}
	sort.Slice(res.Anomalies, func(i, j int) bool {
		x, y := res.Anomalies[i], res.Anomalies[j]
		if x.Severity != y.Severity {
			return x.Severity > y.Severity
		}
		if x.Count != y.Count {
			return x.Count > y.Count
		}
		return x.Key < y.Key
	})
	res.Snapshot = a.snapshot
	res.Verdict = Verdict(res.Anomalies)
	res.Duration = time.Since(now)
	if res.Duration < 0 {
		res.Duration = 0
	}
	return res, nil
}

// Verdict calcula o veredito geral.
func Verdict(list []*model.Anomaly) string {
	max := model.Info
	any := false
	for _, a := range list {
		if a.Severity > model.Info {
			any = true
		}
		if a.Severity > max {
			max = a.Severity
		}
	}
	switch {
	case max >= model.High:
		return "ANORMAL"
	case max == model.Medium:
		return "ATENÇÃO"
	case any:
		return "NORMAL (com observações)"
	}
	return "NORMAL"
}

func mapSet(m map[string]*SourceStat, k string, v *SourceStat) map[string]*SourceStat {
	if m == nil {
		m = map[string]*SourceStat{}
	}
	m[k] = v
	return m
}

// pass executa os coletores em paralelo e consome os eventos em um único goroutine.
func (a *Analyzer) pass(ctx context.Context, active []collectors.Collector, since, until time.Time) int64 {
	ch := make(chan *model.Event, 20000)
	var wg sync.WaitGroup
	var total int64
	done := make(chan struct{})
	go func() {
		for e := range ch {
			total++
			a.consume(e)
		}
		close(done)
	}()
	sem := make(chan struct{}, 6)
	for _, c := range active {
		if a.learn && c.SnapshotOnly() {
			continue
		}
		wg.Add(1)
		go func(c collectors.Collector) {
			defer wg.Done()
			sem <- struct{}{}
			defer func() { <-sem }()
			cctx, cancel := context.WithTimeout(ctx, time.Duration(a.cfg.Analise.TimeoutFonteSegundos)*time.Second)
			defer cancel()
			t0 := time.Now()
			cx := &collectors.Ctx{Cfg: a.cfg, Since: since, Until: until, Learn: a.learn, Now: a.opt.Now,
				Emit: func(e *model.Event) {
					if e.Source == "" {
						e.Source = c.ID()
					}
					ch <- e
				},
				Debug: a.debugf}
			err := c.Collect(cctx, cx)
			a.mu.Lock()
			st := a.stats[c.ID()]
			st.Duration += time.Since(t0)
			if err != nil {
				msg := err.Error()
				if cctx.Err() == context.DeadlineExceeded {
					msg = "tempo limite excedido (" + msg + ")"
				}
				st.Error = util.Truncate(msg, 200)
			}
			a.mu.Unlock()
			a.debugf("fonte %s concluída em %s", c.ID(), time.Since(t0).Round(time.Millisecond))
		}(c)
	}
	wg.Wait()
	close(ch)
	<-done
	return total
}

// ---------------------------------------------------------------- consumo de eventos

func (a *Analyzer) consume(e *model.Event) {
	a.mu.Lock()
	st := a.stats[e.Source]
	a.mu.Unlock()
	if st == nil {
		return
	}
	if a.cfg.MessageIgnored(e.Message) {
		st.Ignored++
		return
	}
	st.Events++
	if !e.Snapshot && !e.Time.IsZero() {
		hk := util.HourKey(e.Time)
		m := a.curHours[e.Source]
		if m == nil {
			m = map[string]int{}
			a.curHours[e.Source] = m
		}
		m[hk]++
		a.curCovered[hk] = true
	}
	if !a.learn {
		a.novelTemplate(e)
		a.rules(e)
	} else {
		a.learnTemplate(e)
	}
	a.learnEntities(e)
}

// ---------------------------------------------------------------- utilitários de anomalia

func (a *Analyzer) raise(rule, key string, sev model.Severity, title, desc string, e *model.Event) *model.Anomaly {
	if !a.cfg.RuleEnabled(rule) {
		return nil
	}
	sev = a.cfg.SeverityFor(rule, sev)
	k := rule + "|" + key
	an := a.anomalies[k]
	if an == nil {
		an = &model.Anomaly{Key: k, Rule: rule, Title: title, Severity: sev, Description: desc, Entity: key}
		if e != nil {
			an.First, an.Last = e.Time, e.Time
		}
		a.anomalies[k] = an
	} else if sev > an.Severity {
		an.Severity = sev
		an.Title = title
		an.Description = desc
	}
	an.Count++
	if e != nil {
		if !e.Time.IsZero() {
			if an.First.IsZero() || e.Time.Before(an.First) {
				an.First = e.Time
			}
			if e.Time.After(an.Last) {
				an.Last = e.Time
			}
		}
		an.AddSource(e.Source)
		if len(an.Evidence) < a.cfg.Analise.MaxAmostrasPorAnomalia {
			ev := e.Evidence()
			dup := false
			for _, x := range an.Evidence {
				if x == ev {
					dup = true
					break
				}
			}
			if !dup {
				an.Evidence = append(an.Evidence, ev)
			}
		}
	}
	return an
}

func (a *Analyzer) burstAdd(rule, key string, e *model.Event, extra string) {
	k := rule + "|" + key
	b := a.bursts[k]
	if b == nil {
		b = &burst{extra: map[string]bool{}, sources: map[string]bool{}}
		a.bursts[k] = b
	}
	b.times = append(b.times, e.Time)
	b.sources[e.Source] = true
	if extra != "" && len(b.extra) < 15 {
		b.extra[extra] = true
	}
	if len(b.evidence) < a.cfg.Analise.MaxAmostrasPorAnomalia {
		b.evidence = append(b.evidence, e.Evidence())
	}
}

// isNew informa se o valor é novidade (categoria já conhecida e valor nunca visto).
func (a *Analyzer) isNew(cat, val string) bool {
	if a.learning || val == "" {
		return false
	}
	return a.base.HasEntityCategory(cat) && !a.base.KnownEntity(cat, val)
}

func (a *Analyzer) touch(cat, val, extra string, t time.Time) {
	if val == "" {
		return
	}
	if a.learn {
		a.base.TouchEntity(cat, val, extra, t)
		return
	}
	a.pendEnt = append(a.pendEnt, entityTouch{cat, val, extra, t})
}

// logCategories são as categorias de entidades aprendidas a partir de logs históricos.
var logCategories = []string{"login_ip", "login_user", "sudo_user", "sudo_cmd", "su_pair", "cron_cmd",
	"usb_device", "apparmor", "unit_failed", "core_proc", "container_image", "crash_exe", "segfault_proc"}

// snapshotCategoryOwner liga cada categoria de "fotografia" ao coletor que a produz.
var snapshotCategoryOwner = map[string]string{"listen_port": "processos", "root_exe": "processos", "deleted_exe": "processos",
	"file_hash": "integridade", "account": "integridade", "cron_file": "cron", "timer": "cron", "lastlog_user": "logins"}

var reDigitsSeg = regexp.MustCompile(`/\d+(/|$)`)

func normExe(p string) string {
	p = strings.TrimSuffix(p, " (deleted)")
	return reDigitsSeg.ReplaceAllString(reDigitsSeg.ReplaceAllString(p, "/<n>$1"), "/<n>$1")
}

var multiWordCmds = map[string]bool{"apt": true, "apt-get": true, "systemctl": true, "snap": true, "dpkg": true,
	"ufw": true, "docker": true, "service": true, "journalctl": true, "flatpak": true, "ip": true, "mount": true}

func sudoCmdKey(cmd string) string {
	f := strings.Fields(cmd)
	if len(f) == 0 {
		return ""
	}
	b := strings.TrimSuffix(f[0], "")
	b = baseName(b)
	if multiWordCmds[b] {
		for _, x := range f[1:] {
			if !strings.HasPrefix(x, "-") {
				return b + " " + x
			}
		}
	}
	return b
}

func baseName(p string) string {
	if i := strings.LastIndexByte(p, '/'); i >= 0 {
		return p[i+1:]
	}
	return p
}

func readUIDs() map[string]int {
	m := map[string]int{}
	data, err := os.ReadFile("/etc/passwd")
	if err != nil {
		return m
	}
	for _, l := range strings.Split(string(data), "\n") {
		p := strings.Split(l, ":")
		if len(p) > 2 {
			var uid int
			fmt.Sscanf(p[2], "%d", &uid)
			m[p[0]] = uid
		}
	}
	return m
}

// ---------------------------------------------------------------- modelos de mensagem

func isErrorEvent(e *model.Event) bool {
	if e.Snapshot || e.Kind != "" || e.Get("skip_novel") != "" || e.Message == "" {
		return false
	}
	if e.Level >= 0 {
		return e.Level <= 3
	}
	return util.LooksLikeError(e.Message)
}

func templateOf(e *model.Event) (string, string) {
	t := e.Program + ": " + util.Template(e.Message)
	return util.Hash64(t), t
}

func (a *Analyzer) learnTemplate(e *model.Event) {
	if !isErrorEvent(e) {
		return
	}
	h, t := templateOf(e)
	ti := a.base.Templates[h]
	if ti == nil {
		a.base.Templates[h] = &store.TemplateInfo{Source: e.Source, Text: t, First: e.Time, Last: e.Time, Count: 1}
		return
	}
	ti.Count++
	if e.Time.After(ti.Last) {
		ti.Last = e.Time
	}
}

func (a *Analyzer) novelTemplate(e *model.Event) {
	if !isErrorEvent(e) {
		return
	}
	h, t := templateOf(e)
	if ti := a.base.Templates[h]; ti != nil {
		ti.Count++
		if e.Time.After(ti.Last) {
			ti.Last = e.Time
		}
		return
	}
	p := a.pendTpl[h]
	if p == nil {
		p = &store.TemplateInfo{Source: e.Source, Text: t, First: e.Time, Last: e.Time}
		a.pendTpl[h] = p
	}
	p.Count++
	if e.Time.After(p.Last) {
		p.Last = e.Time
	}
	if a.learning {
		return
	}
	sev := model.Low
	if e.Level >= 0 && e.Level <= 2 {
		sev = model.Medium
	}
	prog := e.Program
	if prog == "" {
		prog = e.Source
	}
	an := a.raise("erro_novo", h, sev, "Mensagem de erro nunca vista antes ("+prog+")",
		"Este modelo de mensagem de erro não aparece na linha de base dos últimos "+
			itoa(a.cfg.LinhaDeBase.Dias)+" dias. Modelo: \""+util.Truncate(t, 160)+"\"", e)
	if an != nil && an.SearchHint == "" {
		an.SearchHint = prog + " " + util.Truncate(stripVars(e.Message), 90)
	}
}

var reVarTokens = regexp.MustCompile(`<[a-z]+>|\S*\d\S*|\S*/\S*`)

func stripVars(s string) string {
	s = util.Template(s)
	s = reVarTokens.ReplaceAllString(s, " ")
	return strings.Join(strings.Fields(s), " ")
}

func itoa(n int) string { return fmt.Sprintf("%d", n) }
