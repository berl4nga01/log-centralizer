#!/usr/bin/env bash
# Remove o logcentralizer. Pergunta antes de apagar configuração, dados e backups.
set -euo pipefail
if [ "$(id -u)" -ne 0 ]; then echo "Execute como root: sudo $0" >&2; exit 1; fi

ask() { local r; read -r -p "$1 [s/N] " r || true; [[ "$r" =~ ^([sS]|[sS][iI][mM]|[yY])$ ]]; }

rm -f /usr/local/bin/logcentralizer /usr/local/bin/logcentralizer-simulador /run/logcentralizer.lock
echo "✔ Binários removidos."

if ask "Apagar a configuração (/etc/logcentralizer, inclui a senha dos backups criptografados)?"; then
  rm -rf /etc/logcentralizer && echo "✔ Configuração removida."
fi
if ask "Apagar a linha de base, histórico e relatórios (/var/lib/logcentralizer)?"; then
  rm -rf /var/lib/logcentralizer && echo "✔ Dados removidos."
fi
if ask "Apagar TODOS os backups de logs (/var/backups/logcentralizer)?"; then
  rm -rf /var/backups/logcentralizer && echo "✔ Backups removidos."
fi
if [ -f /etc/audit/rules.d/logcentralizer.rules ] && ask "Remover as regras de auditoria instaladas pelo logcentralizer?"; then
  rm -f /etc/audit/rules.d/logcentralizer.rules
  augenrules --load >/dev/null 2>&1 || true
  echo "✔ Regras de auditoria removidas."
fi
echo "Desinstalação concluída. Pacotes do sistema (ufw, auditd, etc.) foram mantidos."
