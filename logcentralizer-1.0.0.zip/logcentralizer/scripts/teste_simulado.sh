#!/usr/bin/env bash
# Teste de ponta a ponta com logs SIMULADOS (não toca nos logs reais nem na
# configuração real). Gera 14 dias de uso normal, roda a 1ª análise (deve dar
# NORMAL), injeta incidentes e roda a 2ª análise (deve dar ANORMAL).
#
# Uso: sudo ./scripts/teste_simulado.sh [diretório_de_teste]
set -euo pipefail

DIR="${1:-/tmp/logcentralizer-teste}"
shift || true
HERE="$(cd "$(dirname "$0")/.." && pwd)"

case "$(uname -m)" in x86_64|amd64) ARCH=amd64 ;; aarch64|arm64) ARCH=arm64 ;; *) ARCH=x ;; esac
find_bin() {
  for c in "$(command -v "$1" 2>/dev/null || true)" "$HERE/build/$1" "$HERE/bin/linux-$ARCH/$1"; do
    [ -n "$c" ] && [ -x "$c" ] && { echo "$c"; return; }
  done
  echo ""
}
LCZ="$(find_bin logcentralizer)"
SIM="$(find_bin logcentralizer-simulador)"
if [ -z "$LCZ" ] || [ -z "$SIM" ]; then
  echo "Binários não encontrados. Instale antes com: sudo ./scripts/install.sh" >&2
  exit 1
fi
if [ "$(id -u)" -ne 0 ]; then
  echo "Execute como root: sudo $0" >&2
  exit 1
fi

rm -rf "$DIR"
mkdir -p "$DIR/logs"
L="$DIR/logs"
cat > "$DIR/config.json" <<EOF
{
  "nome_host": "desktop-simulado",
  "diretorio_dados": "$DIR/dados",
  "diretorio_relatorios": "$DIR/dados/relatorios",
  "fontes": {
    "syslog":   {"modo": "arquivo", "caminhos": ["$L/syslog"]},
    "auth":     {"modo": "arquivo", "caminhos": ["$L/auth.log"]},
    "kernel":   {"modo": "arquivo", "caminhos": ["$L/kern.log"]},
    "ufw":      {"modo": "arquivo", "caminhos": ["$L/ufw.log"]},
    "pacotes":  {"caminhos": ["$L/apt/history.log", "$L/dpkg.log"]},
    "auditd":   {"caminhos": ["$L/audit/audit.log"]},
    "fail2ban": {"caminhos": ["$L/fail2ban.log"]},
    "nginx":    {"caminhos": ["$L/nginx/access.log"]},
    "mysql":    {"caminhos": ["$L/mysql/error.log"]},
    "journald": {"ativo": false}, "logins": {"ativo": false}, "apparmor": {"ativo": false},
    "cron": {"ativo": false}, "apache": {"ativo": false}, "docker": {"ativo": false},
    "postgresql": {"ativo": false}, "hardware": {"ativo": false}, "recursos": {"ativo": false},
    "processos": {"ativo": false}, "acct": {"ativo": false}, "integridade": {"ativo": false},
    "crash": {"ativo": false}
  },
  "backup": {"diretorio": "$DIR/backups", "caminhos": ["$L"], "exportacao_journal": "nenhuma",
             "espaco_livre_minimo_percentual": 1},
  "busca_web": {"ativo": true}
}
EOF

echo "== 1/4 Gerando 14 dias de logs normais =="
"$SIM" -dir "$L" -modo normal
echo
echo "== 2/4 Primeira análise (constrói a linha de base; esperado: NORMAL) =="
"$LCZ" --config "$DIR/config.json" analisar --sem-internet || true
echo
echo "== 3/4 Injetando incidentes simulados =="
"$SIM" -dir "$L" -modo ataque
echo
echo "== 4/4 Segunda análise (esperado: ANORMAL) =="
"$LCZ" --config "$DIR/config.json" analisar --periodo 4h "$@" || true
echo
echo "Relatório: $DIR/dados/relatorios/ultimo_relatorio.txt"
echo "Para ver:  sudo $LCZ --config $DIR/config.json relatorio | less"
echo "Para apagar o teste: sudo rm -rf $DIR"
