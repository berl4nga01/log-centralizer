# logcentralizer

Centralizador de logs para Ubuntu 26.04 LTS escrito em Go, sem dependências externas.

A cada execução, o logcentralizer:

- coleta de uma vez os logs do sistema, de segurança, do kernel, de hardware, de processos e de
  serviços;
- compara o período com a **linha de base** (o comportamento habitual da máquina) e aponta o que
  está fora do padrão;
- sugere soluções a partir de uma base local e de pesquisa na internet (DuckDuckGo, ou Brave Search
  com chave);
- gera um **relatório TXT** em português com o histórico das últimas análises;
- cria um **backup** `.tar.gz` com todos os logs, manifesto SHA-256 e criptografia AES-256 opcional.

## Início rápido

```bash
unzip logcentralizer-1.0.0.zip && cd logcentralizer
sudo ./scripts/install.sh
sudo logcentralizer analisar
sudo logcentralizer relatorio | less
```

Teste com ataques simulados, sem tocar nos logs reais:

```bash
sudo ./scripts/teste_simulado.sh
```

Instalação detalhada, todos os comandos, configuração, regras, backups e a obtenção da chave da Brave
estão no **[TUTORIAL.md](TUTORIAL.md)**.

## Estrutura

| Caminho | Conteúdo |
|---|---|
| `bin/linux-amd64`, `bin/linux-arm64` | binários estáticos prontos |
| `cmd/` | código da CLI e do simulador |
| `internal/` | coletores, analisador, linha de base, soluções, backup e relatório |
| `scripts/` | instalação, desinstalação e teste simulado |
| `configs/` | exemplo de configuração e regras do auditd |
