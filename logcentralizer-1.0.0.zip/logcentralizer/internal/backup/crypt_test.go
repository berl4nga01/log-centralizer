package backup

import (
	"bytes"
	"crypto/rand"
	"os"
	"path/filepath"
	"testing"
)

func TestEncryptRoundTrip(t *testing.T) {
	d := t.TempDir()
	plain := make([]byte, 3*encChunk+123)
	rand.Read(plain)
	enc := filepath.Join(d, "x.enc")
	f, _ := os.Create(enc)
	w, err := newEncWriter(f, "senha-de-teste-forte")
	if err != nil {
		t.Fatal(err)
	}
	w.Write(plain[:1000])
	w.Write(plain[1000:])
	w.Close()
	f.Close()
	out := filepath.Join(d, "x.out")
	if err := Decrypt(enc, out, "senha-de-teste-forte"); err != nil {
		t.Fatal(err)
	}
	got, _ := os.ReadFile(out)
	if !bytes.Equal(got, plain) {
		t.Fatal("conteúdo diferente após descriptografar")
	}
	if err := Decrypt(enc, out, "senha-errada-123456"); err == nil {
		t.Fatal("senha errada deveria falhar")
	}
	// truncamento deve ser detectado
	data, _ := os.ReadFile(enc)
	os.WriteFile(enc, data[:len(data)-40], 0o600)
	if err := Decrypt(enc, out, "senha-de-teste-forte"); err == nil {
		t.Fatal("arquivo truncado deveria falhar")
	}
}
