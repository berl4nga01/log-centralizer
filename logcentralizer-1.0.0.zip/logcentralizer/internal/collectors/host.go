package collectors

import (
	"bufio"
	"context"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"regexp"
	"runtime"
	"strconv"
	"strings"
	"syscall"
	"time"

	"logcentralizer/internal/config"
	"logcentralizer/internal/model"
	"logcentralizer/internal/util"
)

// ================================================================= hardware

type hardware struct{ base }

func newHardware() Collector {
	return &hardware{base{"hardware", "hardware (temperaturas, SMART dos discos, EDAC/memória, bateria, smartd)", "hardware"}}
}

func (h *hardware) Requirements() []Requirement {
	return []Requirement{
		{Kind: "dir", Name: "/sys/class/hwmon", Package: "linux-image", Desc: "sensores de temperatura do kernel"},
		{Kind: "cmd", Name: "smartctl", Package: "smartmontools", Desc: "saúde SMART dos discos (SSD/HD/NVMe)"},
		{Kind: "cmd", Name: "sensors", Package: "lm-sensors", Optional: true, Desc: "detecção extra de sensores (sensors-detect)"},
		{Kind: "dir", Name: "/sys/devices/system/edac/mc", Package: "linux-image", Optional: true, Desc: "contadores de erro de memória ECC"},
		{Kind: "cmd", Name: "ras-mc-ctl", Package: "rasdaemon", Optional: true, Desc: "registro de erros de hardware (MCE/ECC)"},
	}
}

func (h *hardware) Probe(cfg *config.Config) Probe {
	var parts, notes []string
	if len(hwmonTemps()) > 0 {
		parts = append(parts, "hwmon")
	} else if zs, _ := filepath.Glob("/sys/class/thermal/thermal_zone*/temp"); len(zs) > 0 {
		parts = append(parts, "thermal_zone")
	} else {
		notes = append(notes, "nenhum sensor de temperatura exposto pelo kernel")
	}
	if util.CmdExists("smartctl") {
		parts = append(parts, "smartctl")
	} else {
		notes = append(notes, "smartctl ausente: saúde dos discos não será verificada (sudo apt install smartmontools)")
	}
	if util.Exists("/sys/devices/system/edac/mc/mc0") {
		parts = append(parts, "EDAC")
	}
	if b, _ := filepath.Glob("/sys/class/power_supply/BAT*"); len(b) > 0 {
		parts = append(parts, "bateria")
	}
	if journalAvailable() {
		parts = append(parts, "smartd/rasdaemon via journal")
	}
	if len(parts) == 0 {
		return Probe{Available: false, Notes: notes}
	}
	return Probe{Available: true, Mode: strings.Join(parts, " + "), Notes: notes}
}

func (h *hardware) SnapshotOnly() bool { return false }

type tempReading struct {
	Name  string
	Value float64
	Crit  float64
}

func readFloatFile(p string) (float64, bool) {
	b, err := os.ReadFile(p)
	if err != nil {
		return 0, false
	}
	v, err := strconv.ParseFloat(strings.TrimSpace(string(b)), 64)
	return v, err == nil
}

func readStrFile(p string) string {
	b, err := os.ReadFile(p)
	if err != nil {
		return ""
	}
	return strings.TrimSpace(string(b))
}

func hwmonTemps() []tempReading {
	var out []tempReading
	inputs, _ := filepath.Glob("/sys/class/hwmon/hwmon*/temp*_input")
	for _, in := range inputs {
		v, ok := readFloatFile(in)
		if !ok || v <= 0 {
			continue
		}
		dir := filepath.Dir(in)
		prefix := strings.TrimSuffix(filepath.Base(in), "_input")
		name := readStrFile(filepath.Join(dir, "name"))
		if l := readStrFile(filepath.Join(dir, prefix+"_label")); l != "" {
			name += "/" + l
		} else {
			name += "/" + prefix
		}
		crit, _ := readFloatFile(filepath.Join(dir, prefix+"_crit"))
		out = append(out, tempReading{Name: name, Value: v / 1000, Crit: crit / 1000})
	}
	return out
}

var reSmartd = regexp.MustCompile(`(?i)(FAILED|FAILING_NOW|Currently unreadable|Offline uncorrectable|Prefailure Attribute|failed self-test|ATA error count increased|Critical Warning|Media and Data Integrity Errors)`)

func (h *hardware) Collect(ctx context.Context, c *Ctx) error {
	// mensagens históricas do smartd/rasdaemon no journal
	if journalAvailable() {
		_ = readJournal(ctx, c, h.id, []string{"SYSLOG_IDENTIFIER=smartd", "SYSLOG_IDENTIFIER=rasdaemon", "SYSLOG_IDENTIFIER=mcelog"}, func(e *model.Event) {
			if reSmartd.MatchString(e.Message) ||
				(e.Program != "smartd" && strings.Contains(strings.ToLower(e.Message), "error")) {
				e.Kind = "hw_log"
				e.Set("what", e.Program)
				e.Set("skip_novel", "1")
			}
			c.Emit(e)
		})
	}
	if c.Learn {
		return nil
	}
	temps := hwmonTemps()
	if len(temps) == 0 {
		zs, _ := filepath.Glob("/sys/class/thermal/thermal_zone*/temp")
		for _, z := range zs {
			v, ok := readFloatFile(z)
			if !ok || v <= 0 {
				continue
			}
			temps = append(temps, tempReading{Name: readStrFile(filepath.Join(filepath.Dir(z), "type")), Value: v / 1000})
		}
	}
	for _, t := range temps {
		e := &model.Event{Time: c.Now, Source: h.id, Kind: "hw_temp", Snapshot: true,
			Message: fmt.Sprintf("temperatura %s = %.1f°C", t.Name, t.Value)}
		e.Set("sensor", t.Name)
		e.Set("value", fmt.Sprintf("%.1f", t.Value))
		e.Set("crit", fmt.Sprintf("%.1f", t.Crit))
		c.Emit(e)
	}
	if util.CmdExists("smartctl") {
		h.smart(ctx, c)
	}
	mcs, _ := filepath.Glob("/sys/devices/system/edac/mc/mc*")
	for _, mc := range mcs {
		ce, ok1 := readFloatFile(filepath.Join(mc, "ce_count"))
		ue, ok2 := readFloatFile(filepath.Join(mc, "ue_count"))
		if !ok1 && !ok2 {
			continue
		}
		e := &model.Event{Time: c.Now, Source: h.id, Kind: "hw_edac", Snapshot: true,
			Message: fmt.Sprintf("%s: erros corrigidos=%.0f, não corrigidos=%.0f", filepath.Base(mc), ce, ue)}
		e.Set("mc", filepath.Base(mc))
		e.Set("ce", fmt.Sprintf("%.0f", ce))
		e.Set("ue", fmt.Sprintf("%.0f", ue))
		c.Emit(e)
	}
	bats, _ := filepath.Glob("/sys/class/power_supply/BAT*")
	for _, b := range bats {
		full, ok1 := readFloatFile(filepath.Join(b, "energy_full"))
		design, ok2 := readFloatFile(filepath.Join(b, "energy_full_design"))
		if !ok1 || !ok2 {
			full, ok1 = readFloatFile(filepath.Join(b, "charge_full"))
			design, ok2 = readFloatFile(filepath.Join(b, "charge_full_design"))
		}
		if !ok1 || !ok2 || design <= 0 {
			continue
		}
		pct := full / design * 100
		e := &model.Event{Time: c.Now, Source: h.id, Kind: "hw_battery", Snapshot: true,
			Message: fmt.Sprintf("bateria %s: saúde %.0f%% da capacidade original", filepath.Base(b), pct)}
		e.Set("bat", filepath.Base(b))
		e.Set("health", fmt.Sprintf("%.1f", pct))
		c.Emit(e)
	}
	return nil
}

type smartJSON struct {
	Device struct {
		Name string `json:"name"`
		Type string `json:"type"`
	} `json:"device"`
	ModelName   string `json:"model_name"`
	SmartStatus *struct {
		Passed bool `json:"passed"`
	} `json:"smart_status"`
	Temperature struct {
		Current float64 `json:"current"`
	} `json:"temperature"`
	ATA struct {
		Table []struct {
			ID   int    `json:"id"`
			Name string `json:"name"`
			Raw  struct {
				Value float64 `json:"value"`
			} `json:"raw"`
		} `json:"table"`
	} `json:"ata_smart_attributes"`
	NVMe *struct {
		CriticalWarning int     `json:"critical_warning"`
		MediaErrors     float64 `json:"media_errors"`
		PercentageUsed  float64 `json:"percentage_used"`
		AvailableSpare  float64 `json:"available_spare"`
		SpareThreshold  float64 `json:"available_spare_threshold"`
	} `json:"nvme_smart_health_information_log"`
}

var reScan = regexp.MustCompile(`^(\S+)\s+-d\s+(\S+)`)

func (h *hardware) smart(ctx context.Context, c *Ctx) {
	out, _ := util.RunOutput(ctx, 30*time.Second, "smartctl", "--scan")
	for _, line := range strings.Split(out, "\n") {
		x := reScan.FindStringSubmatch(line)
		if x == nil {
			continue
		}
		dev, typ := x[1], x[2]
		raw, _ := util.RunOutput(ctx, 60*time.Second, "smartctl", "-H", "-A", "-i", "-j", "-d", typ, dev)
		var s smartJSON
		if json.Unmarshal([]byte(raw), &s) != nil {
			continue
		}
		e := &model.Event{Time: c.Now, Source: h.id, Kind: "hw_smart", Snapshot: true}
		e.Set("dev", dev)
		e.Set("model", s.ModelName)
		status := "desconhecido"
		if s.SmartStatus != nil {
			if s.SmartStatus.Passed {
				status = "PASSED"
			} else {
				status = "FAILED"
			}
		}
		e.Set("status", status)
		for _, a := range s.ATA.Table {
			switch a.ID {
			case 5:
				e.Set("realloc", fmt.Sprintf("%.0f", a.Raw.Value))
			case 197:
				e.Set("pending", fmt.Sprintf("%.0f", a.Raw.Value))
			case 198:
				e.Set("uncorrect", fmt.Sprintf("%.0f", a.Raw.Value))
			}
		}
		if s.NVMe != nil {
			e.Set("nvme_warn", strconv.Itoa(s.NVMe.CriticalWarning))
			e.Set("media_errors", fmt.Sprintf("%.0f", s.NVMe.MediaErrors))
			e.Set("pct_used", fmt.Sprintf("%.0f", s.NVMe.PercentageUsed))
			if s.NVMe.SpareThreshold > 0 && s.NVMe.AvailableSpare <= s.NVMe.SpareThreshold {
				e.Set("spare_low", "1")
			}
		}
		if s.Temperature.Current > 0 {
			e.Set("temp", fmt.Sprintf("%.0f", s.Temperature.Current))
		}
		e.Message = fmt.Sprintf("SMART %s (%s): %s", dev, s.ModelName, status)
		c.Emit(e)
	}
}

// ================================================================= recursos

type resources struct{ base }

func newResources() Collector {
	return &resources{base{"recursos", "recursos do sistema (disco, inodes, memória, swap, carga)", "hardware"}}
}

func (r *resources) SnapshotOnly() bool { return true }

func (r *resources) Requirements() []Requirement {
	return []Requirement{{Kind: "file", Name: "/proc/meminfo", Package: "linux-image", Desc: "/proc"}}
}

func (r *resources) Probe(cfg *config.Config) Probe {
	return Probe{Available: util.Exists("/proc/meminfo"), Mode: "/proc/mounts + statfs + /proc/meminfo + /proc/loadavg"}
}

var realFS = map[string]bool{"ext2": true, "ext3": true, "ext4": true, "xfs": true, "btrfs": true, "vfat": true,
	"exfat": true, "ntfs": true, "ntfs3": true, "fuseblk": true, "f2fs": true, "zfs": true, "jfs": true, "reiserfs": true, "overlay": false}

func (r *resources) Collect(ctx context.Context, c *Ctx) error {
	if c.Learn {
		return nil
	}
	seen := map[string]bool{}
	if f, err := os.Open("/proc/mounts"); err == nil {
		sc := bufio.NewScanner(f)
		for sc.Scan() {
			p := strings.Fields(sc.Text())
			if len(p) < 3 || !realFS[p[2]] || seen[p[0]] || strings.HasPrefix(p[1], "/snap/") {
				continue
			}
			seen[p[0]] = true
			mnt := strings.ReplaceAll(p[1], `\040`, " ")
			var st syscall.Statfs_t
			if syscall.Statfs(mnt, &st) != nil || st.Blocks == 0 {
				continue
			}
			used := float64(st.Blocks-st.Bfree) / float64(st.Blocks-st.Bfree+st.Bavail) * 100
			ipct := 0.0
			if st.Files > 0 {
				ipct = float64(st.Files-st.Ffree) / float64(st.Files) * 100
			}
			free := int64(st.Bavail) * int64(st.Bsize)
			e := &model.Event{Time: c.Now, Source: r.id, Kind: "res_disk", Snapshot: true,
				Message: fmt.Sprintf("%s (%s): %.1f%% usado, inodes %.1f%%, livre %s", mnt, p[2], used, ipct, util.HumanBytes(free))}
			e.Set("mount", mnt)
			e.Set("dev", p[0])
			e.Set("pct", fmt.Sprintf("%.1f", used))
			e.Set("ipct", fmt.Sprintf("%.1f", ipct))
			e.Set("free", util.HumanBytes(free))
			c.Emit(e)
		}
		f.Close()
	}
	mi := readMeminfo()
	if mi["MemTotal"] > 0 {
		avail := mi["MemAvailable"] / mi["MemTotal"] * 100
		swap := 0.0
		if mi["SwapTotal"] > 0 {
			swap = (mi["SwapTotal"] - mi["SwapFree"]) / mi["SwapTotal"] * 100
		}
		e := &model.Event{Time: c.Now, Source: r.id, Kind: "res_mem", Snapshot: true,
			Message: fmt.Sprintf("memória disponível %.1f%% de %s, swap usado %.1f%%", avail, util.HumanBytes(int64(mi["MemTotal"]*1024)), swap)}
		e.Set("avail_pct", fmt.Sprintf("%.1f", avail))
		e.Set("swap_pct", fmt.Sprintf("%.1f", swap))
		e.Set("swap_total", fmt.Sprintf("%.0f", mi["SwapTotal"]))
		c.Emit(e)
	}
	if la := readStrFile("/proc/loadavg"); la != "" {
		f := strings.Fields(la)
		if len(f) >= 3 {
			e := &model.Event{Time: c.Now, Source: r.id, Kind: "res_load", Snapshot: true,
				Message: fmt.Sprintf("carga média %s %s %s (%d CPUs)", f[0], f[1], f[2], runtime.NumCPU())}
			e.Set("load1", f[0])
			e.Set("load5", f[1])
			e.Set("load15", f[2])
			e.Set("ncpu", strconv.Itoa(runtime.NumCPU()))
			c.Emit(e)
		}
	}
	if up := readStrFile("/proc/uptime"); up != "" {
		v, _ := strconv.ParseFloat(strings.Fields(up)[0], 64)
		e := &model.Event{Time: c.Now, Source: r.id, Kind: "res_uptime", Snapshot: true,
			Message: fmt.Sprintf("ligado há %s", (time.Duration(v) * time.Second).String())}
		c.Emit(e)
	}
	return nil
}

func readMeminfo() map[string]float64 {
	m := map[string]float64{}
	f, err := os.Open("/proc/meminfo")
	if err != nil {
		return m
	}
	defer f.Close()
	sc := bufio.NewScanner(f)
	for sc.Scan() {
		k, v, ok := strings.Cut(sc.Text(), ":")
		if !ok {
			continue
		}
		fs := strings.Fields(v)
		if len(fs) > 0 {
			n, _ := strconv.ParseFloat(fs[0], 64)
			m[k] = n
		}
	}
	return m
}

// ================================================================= processos

type processes struct{ base }

func newProcesses() Collector {
	return &processes{base{"processos", "processos do sistema operacional (/proc: executáveis, portas abertas, CPU/memória)", "sistema"}}
}

func (p *processes) SnapshotOnly() bool { return true }

func (p *processes) Requirements() []Requirement {
	return []Requirement{{Kind: "dir", Name: "/proc/1", Package: "linux-image", Desc: "/proc (precisa de root para ver todos os processos)"}}
}

func (p *processes) Probe(cfg *config.Config) Probe {
	if !util.Exists("/proc/1") {
		return Probe{Available: false, Notes: []string{"/proc indisponível"}}
	}
	pr := Probe{Available: true, Mode: "/proc (processos, sockets em escuta, amostragem de CPU de 1s)"}
	if os.Geteuid() != 0 {
		pr.Notes = append(pr.Notes, "sem root parte dos executáveis não será visível")
	}
	return pr
}

type procInfo struct {
	pid     int
	comm    string
	state   string
	ppid    string
	ticks   float64
	rssKB   float64
	uid     string
	exe     string
	cmdline string
}

func readProc(pid int) (*procInfo, bool) {
	dir := "/proc/" + strconv.Itoa(pid)
	stat, err := os.ReadFile(dir + "/stat")
	if err != nil {
		return nil, false
	}
	s := string(stat)
	l, r := strings.IndexByte(s, '('), strings.LastIndexByte(s, ')')
	if l < 0 || r < l {
		return nil, false
	}
	pi := &procInfo{pid: pid, comm: s[l+1 : r]}
	f := strings.Fields(s[r+1:])
	if len(f) > 22 {
		pi.state = f[0]
		pi.ppid = f[1]
		ut, _ := strconv.ParseFloat(f[11], 64)
		st, _ := strconv.ParseFloat(f[12], 64)
		pi.ticks = ut + st
		rss, _ := strconv.ParseFloat(f[21], 64)
		pi.rssKB = rss * float64(os.Getpagesize()) / 1024
	}
	if st, err := os.ReadFile(dir + "/status"); err == nil {
		for _, line := range strings.Split(string(st), "\n") {
			if strings.HasPrefix(line, "Uid:") {
				fs := strings.Fields(line)
				if len(fs) > 1 {
					pi.uid = fs[1]
				}
				break
			}
		}
	}
	pi.exe, _ = os.Readlink(dir + "/exe")
	if cl, err := os.ReadFile(dir + "/cmdline"); err == nil {
		pi.cmdline = strings.TrimSpace(strings.ReplaceAll(string(cl), "\x00", " "))
	}
	return pi, true
}

func listPIDs() []int {
	ents, _ := os.ReadDir("/proc")
	var out []int
	for _, e := range ents {
		if n, err := strconv.Atoi(e.Name()); err == nil {
			out = append(out, n)
		}
	}
	return out
}

func totalJiffies() float64 {
	s := readStrFile("/proc/stat")
	line := strings.SplitN(s, "\n", 2)[0]
	var t float64
	for _, f := range strings.Fields(line)[1:] {
		v, _ := strconv.ParseFloat(f, 64)
		t += v
	}
	return t
}

func userName(uid string) string {
	data, err := os.ReadFile("/etc/passwd")
	if err != nil {
		return uid
	}
	for _, l := range strings.Split(string(data), "\n") {
		p := strings.Split(l, ":")
		if len(p) > 2 && p[2] == uid {
			return p[0]
		}
	}
	return uid
}

func (p *processes) Collect(ctx context.Context, c *Ctx) error {
	if c.Learn {
		return nil
	}
	first := map[int]float64{}
	j1 := totalJiffies()
	for _, pid := range listPIDs() {
		if pi, ok := readProc(pid); ok {
			first[pid] = pi.ticks
		}
	}
	select {
	case <-time.After(time.Second):
	case <-ctx.Done():
		return ctx.Err()
	}
	j2 := totalJiffies()
	ncpu := float64(runtime.NumCPU())
	memTotal := readMeminfo()["MemTotal"]
	users := map[string]string{}
	total, zombies := 0, 0
	inodeOwner := socketOwners()
	for _, pid := range listPIDs() {
		pi, ok := readProc(pid)
		if !ok {
			continue
		}
		total++
		if pi.state == "Z" {
			zombies++
		}
		if pi.exe == "" || pid == os.Getpid() { // thread de kernel, sem permissão ou o próprio logcentralizer
			continue
		}
		cpu := 0.0
		if t0, ok := first[pid]; ok && j2 > j1 {
			cpu = (pi.ticks - t0) / (j2 - j1) * 100 * ncpu
		}
		mem := 0.0
		if memTotal > 0 {
			mem = pi.rssKB / memTotal * 100
		}
		if _, ok := users[pi.uid]; !ok {
			users[pi.uid] = userName(pi.uid)
		}
		e := &model.Event{Time: c.Now, Source: p.id, Kind: "proc", Snapshot: true,
			Message: fmt.Sprintf("pid %d %s (%s) usuário=%s cpu=%.1f%% mem=%.1f%%", pid, pi.comm, pi.exe, users[pi.uid], cpu, mem)}
		e.Set("pid", strconv.Itoa(pid))
		e.Set("comm", pi.comm)
		e.Set("exe", pi.exe)
		e.Set("uid", pi.uid)
		e.Set("user", users[pi.uid])
		e.Set("cpu", fmt.Sprintf("%.1f", cpu))
		e.Set("mem", fmt.Sprintf("%.1f", mem))
		e.Set("state", pi.state)
		e.Set("ppid", pi.ppid)
		e.Set("cmdline", util.Truncate(pi.cmdline, 200))
		c.Emit(e)
	}
	sum := &model.Event{Time: c.Now, Source: p.id, Kind: "proc_summary", Snapshot: true,
		Message: fmt.Sprintf("%d processos, %d zumbis", total, zombies)}
	sum.Set("total", strconv.Itoa(total))
	sum.Set("zombies", strconv.Itoa(zombies))
	c.Emit(sum)
	for _, l := range listeners() {
		owner := inodeOwner[l.inode]
		e := &model.Event{Time: c.Now, Source: p.id, Kind: "listen", Snapshot: true,
			Message: fmt.Sprintf("%s %s:%d em escuta por %s", l.proto, l.addr, l.port, owner.exe)}
		e.Set("proto", l.proto)
		e.Set("addr", l.addr)
		e.Set("port", strconv.Itoa(l.port))
		e.Set("exe", owner.exe)
		e.Set("pid", owner.pid)
		c.Emit(e)
	}
	return nil
}

type listener struct {
	proto string
	addr  string
	port  int
	inode string
}

func listeners() []listener {
	var out []listener
	seen := map[string]bool{}
	for _, spec := range []struct{ file, proto, state string }{
		{"/proc/net/tcp", "tcp", "0A"}, {"/proc/net/tcp6", "tcp6", "0A"},
		{"/proc/net/udp", "udp", "07"}, {"/proc/net/udp6", "udp6", "07"},
	} {
		data, err := os.ReadFile(spec.file)
		if err != nil {
			continue
		}
		for i, line := range strings.Split(string(data), "\n") {
			f := strings.Fields(line)
			if i == 0 || len(f) < 10 || f[3] != spec.state {
				continue
			}
			if strings.HasPrefix(spec.proto, "udp") && !strings.HasSuffix(f[2], ":0000") {
				continue
			}
			addr, port := decodeAddr(f[1])
			k := spec.proto + addr + strconv.Itoa(port)
			if seen[k] {
				continue
			}
			seen[k] = true
			out = append(out, listener{proto: spec.proto, addr: addr, port: port, inode: f[9]})
		}
	}
	return out
}

func decodeAddr(s string) (string, int) {
	h, p, ok := strings.Cut(s, ":")
	if !ok {
		return "", 0
	}
	port, _ := strconv.ParseInt(p, 16, 32)
	b := make([]byte, len(h)/2)
	for i := 0; i < len(b); i++ {
		v, _ := strconv.ParseUint(h[2*i:2*i+2], 16, 8)
		b[i] = byte(v)
	}
	switch len(b) {
	case 4:
		return fmt.Sprintf("%d.%d.%d.%d", b[3], b[2], b[1], b[0]), int(port)
	case 16:
		// cada palavra de 32 bits está em little-endian
		var ip [16]byte
		for w := 0; w < 4; w++ {
			for k := 0; k < 4; k++ {
				ip[w*4+k] = b[w*4+3-k]
			}
		}
		allZero := true
		for _, x := range ip {
			if x != 0 {
				allZero = false
			}
		}
		if allZero {
			return "::", int(port)
		}
		if ip == [16]byte{15: 1} {
			return "::1", int(port)
		}
		parts := make([]string, 8)
		for i := 0; i < 8; i++ {
			parts[i] = strconv.FormatUint(uint64(ip[2*i])<<8|uint64(ip[2*i+1]), 16)
		}
		return strings.Join(parts, ":"), int(port)
	}
	return h, int(port)
}

type sockOwner struct{ pid, exe string }

func socketOwners() map[string]sockOwner {
	m := map[string]sockOwner{}
	for _, pid := range listPIDs() {
		dir := "/proc/" + strconv.Itoa(pid)
		fds, err := os.ReadDir(dir + "/fd")
		if err != nil {
			continue
		}
		exe, _ := os.Readlink(dir + "/exe")
		for _, fd := range fds {
			l, err := os.Readlink(dir + "/fd/" + fd.Name())
			if err != nil || !strings.HasPrefix(l, "socket:[") {
				continue
			}
			ino := strings.TrimSuffix(strings.TrimPrefix(l, "socket:["), "]")
			if _, ok := m[ino]; !ok {
				m[ino] = sockOwner{pid: strconv.Itoa(pid), exe: exe}
			}
		}
	}
	return m
}

// ================================================================= contabilidade de processos (acct)

type accounting struct{ base }

func newAccounting() Collector {
	return &accounting{base{"acct", "contabilidade de processos (acct/lastcomm: comandos executados)", "sistema"}}
}

func (a *accounting) Requirements() []Requirement {
	return []Requirement{
		{Kind: "cmd", Name: "lastcomm", Package: "acct", Desc: "registro de todos os comandos executados"},
		{Kind: "file", Name: "/var/log/account/pacct", Package: "acct", Desc: "arquivo de contabilidade"},
	}
}

func (a *accounting) path(cfg *config.Config) string {
	return cfg.SourcePaths(a.id, []string{"/var/log/account/pacct"})[0]
}

func (a *accounting) Probe(cfg *config.Config) Probe {
	if !util.CmdExists("lastcomm") || !util.Exists(a.path(cfg)) {
		return Probe{Available: false, Notes: []string{"acct não instalado (opcional: sudo apt install acct)"}}
	}
	return Probe{Available: true, Mode: "lastcomm -f " + a.path(cfg)}
}

var reLastcomm = regexp.MustCompile(`^(\S+)\s+([SFCDX ]*?)\s*(\S+)\s+(\S+)\s+([\d.]+) secs (\w{3} \w{3}\s+\d{1,2} \d{2}:\d{2})`)

func (a *accounting) Collect(ctx context.Context, c *Ctx) error {
	return util.RunLines(ctx, func(line string) {
		x := reLastcomm.FindStringSubmatch(line)
		if x == nil {
			return
		}
		t, err := time.ParseInLocation("Mon Jan _2 15:04 2006", strings.Join(strings.Fields(x[6]), " ")+" "+strconv.Itoa(c.Now.Year()), time.Local)
		if err != nil {
			t, err = time.ParseInLocation("Mon Jan 2 15:04 2006", strings.Join(strings.Fields(x[6]), " ")+" "+strconv.Itoa(c.Now.Year()), time.Local)
			if err != nil {
				return
			}
		}
		if t.After(c.Now.Add(48 * time.Hour)) {
			t = t.AddDate(-1, 0, 0)
		}
		if t.Before(c.Since.Truncate(time.Minute)) || !t.Before(c.Until) {
			return
		}
		e := &model.Event{Time: t, Source: a.id, Program: "acct", Level: -1, Kind: "exec", Message: line}
		e.Set("cmd", x[1])
		e.Set("user", x[3])
		e.Set("tty", x[4])
		e.Set("skip_novel", "1")
		c.Emit(e)
	}, "lastcomm", "--forwards", "-f", a.path(c.Cfg))
}
