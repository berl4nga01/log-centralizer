module logcentralizer

go 1.24
