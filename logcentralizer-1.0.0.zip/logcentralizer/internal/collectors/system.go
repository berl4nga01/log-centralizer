package collectors

import (
	"context"
	"crypto/sha256"
	"encoding/hex"
	"os"
	"path/filepath"
	"regexp"
	"strings"
	"time"

	"logcentralizer/internal/config"
	"logcentralizer/internal/model"
	"logcentralizer/internal/util"
)

// ================================================================= journald / systemd

type journald struct{ base }

func newJournald() Collector {
	return &journald{base{"journald", "journald / systemd (serviços, unidades, core dumps)", "sistema"}}
}

func (j *journald) Requirements() []Requirement {
	return []Requirement{
		{Kind: "cmd", Name: "journalctl", Package: "systemd", Desc: "leitura do journal"},
		{Kind: "dir", Name: "/var/log/journal", Package: "systemd", Optional: true, Desc: "journal persistente (histórico após reiniciar)"},
	}
}

func (j *journald) Probe(cfg *config.Config) Probe {
	if !journalAvailable() {
		return Probe{Available: false, Notes: []string{"journalctl não encontrado"}}
	}
	p := Probe{Available: true, Mode: "journalctl -o json (exceto kernel e autenticação, lidos por fontes próprias)"}
	if !util.Exists("/var/log/journal") {
		p.Notes = append(p.Notes, "journal não persistente: o histórico se perde ao reiniciar (crie /var/log/journal)")
	}
	return p
}

func (j *journald) Collect(ctx context.Context, c *Ctx) error {
	return readJournal(ctx, c, j.id, nil, func(e *model.Event) {
		if e.Get("transport") == "kernel" || e.Get("transport") == "audit" {
			return
		}
		if f := e.Get("facility"); f == "4" || f == "10" {
			return
		}
		parseSystemd(e)
		c.Emit(e)
	})
}

var (
	reUnitFailedResult = regexp.MustCompile(`^(\S+?\.(?:service|socket|mount|timer|target|path|scope|swap)): Failed with result '([^']+)'`)
	reUnitFailedStart  = regexp.MustCompile(`^Failed to start (.+?)\.?$`)
	reUnitRepeated     = regexp.MustCompile(`^(\S+?\.service): Start request repeated too quickly`)
	reUnitRestart      = regexp.MustCompile(`^(\S+?\.service): Scheduled restart job, restart counter is at (\d+)`)
	reCoreDump         = regexp.MustCompile(`Process (\d+) \((.+?)\) of user (\d+) (?:dumped core|terminated abnormally)`)
)

// parseSystemd classifica mensagens do systemd.
func parseSystemd(e *model.Event) {
	msg := e.Message
	switch {
	case reUnitFailedResult.MatchString(msg):
		m := reUnitFailedResult.FindStringSubmatch(msg)
		e.Kind = "unit_failed"
		e.Set("unit", m[1])
		e.Set("result", m[2])
	case reUnitRepeated.MatchString(msg):
		m := reUnitRepeated.FindStringSubmatch(msg)
		e.Kind = "unit_failed"
		e.Set("unit", m[1])
		e.Set("result", "start-limit-hit")
	case reUnitRestart.MatchString(msg):
		m := reUnitRestart.FindStringSubmatch(msg)
		e.Kind = "unit_restart"
		e.Set("unit", m[1])
		e.Set("counter", m[2])
	case reCoreDump.MatchString(msg):
		m := reCoreDump.FindStringSubmatch(msg)
		e.Kind = "core_dump"
		e.Set("proc", m[2])
		e.Set("uid", m[3])
	case strings.HasPrefix(msg, "Failed to start ") && (e.Program == "systemd" || e.Program == "init"):
		m := reUnitFailedStart.FindStringSubmatch(msg)
		if m != nil {
			e.Kind = "unit_failed_desc"
			e.Set("desc", m[1])
		}
	}
}

// ================================================================= syslog

type syslogSrc struct{ base }

func newSyslog() Collector {
	return &syslogSrc{base{"syslog", "syslog (/var/log/syslog, eventos gerais)", "sistema"}}
}

func (s *syslogSrc) paths(cfg *config.Config) []string {
	return cfg.SourcePaths(s.id, []string{"/var/log/syslog", "/var/log/messages"})
}

func (s *syslogSrc) Requirements() []Requirement {
	return []Requirement{{Kind: "file", Name: "/var/log/syslog", Package: "rsyslog", Desc: "arquivo syslog clássico (rsyslog)"}}
}

func (s *syslogSrc) WatchedFiles(cfg *config.Config) []string { return util.ExpandGlobs(s.paths(cfg)) }

func (s *syslogSrc) Probe(cfg *config.Config) Probe {
	if modeFor(cfg, s.id, s.paths(cfg), false) == "" {
		n := "arquivo syslog inexistente (rsyslog não instalado)"
		if journalAvailable() {
			n += "; os mesmos eventos já são cobertos pela fonte journald"
		}
		return Probe{Available: false, Notes: []string{n}}
	}
	return Probe{Available: true, Mode: "arquivo " + strings.Join(util.ExpandGlobs(s.paths(cfg)), ", ")}
}

func (s *syslogSrc) Collect(ctx context.Context, c *Ctx) error {
	parse := !journalAvailable() || !c.Cfg.SourceEnabled("journald")
	return readSyslogFiles(ctx, c, s.id, s.paths(c.Cfg), func(e *model.Event) {
		if parse {
			parseSystemd(e)
		}
		c.Emit(e)
	})
}

// ================================================================= auth

type auth struct{ base }

func newAuth() Collector {
	return &auth{base{"auth", "autenticação (auth.log: SSH, sudo, su, contas)", "seguranca"}}
}

func (a *auth) paths(cfg *config.Config) []string {
	return cfg.SourcePaths(a.id, []string{"/var/log/auth.log", "/var/log/secure"})
}

func (a *auth) Requirements() []Requirement {
	return []Requirement{
		{Kind: "file", Name: "/var/log/auth.log", Package: "rsyslog", Optional: true, Desc: "auth.log (sem ele usa o journal)"},
		{Kind: "cmd", Name: "journalctl", Package: "systemd", Optional: true, Desc: "fallback via journal"},
	}
}

func (a *auth) WatchedFiles(cfg *config.Config) []string { return util.ExpandGlobs(a.paths(cfg)) }

func (a *auth) Probe(cfg *config.Config) Probe {
	switch modeFor(cfg, a.id, a.paths(cfg), true) {
	case "arquivo":
		return Probe{Available: true, Mode: "arquivo " + strings.Join(util.ExpandGlobs(a.paths(cfg)), ", ")}
	case "journal":
		return Probe{Available: true, Mode: "journal (facilidades auth/authpriv)", Notes: []string{"auth.log ausente; lendo do journal"}}
	}
	return Probe{Available: false, Notes: []string{"nem auth.log nem journalctl disponíveis"}}
}

func (a *auth) Collect(ctx context.Context, c *Ctx) error {
	emit := func(e *model.Event) { parseAuth(e); c.Emit(e) }
	if modeFor(c.Cfg, a.id, a.paths(c.Cfg), true) == "arquivo" {
		return readSyslogFiles(ctx, c, a.id, a.paths(c.Cfg), emit)
	}
	return readJournal(ctx, c, a.id, []string{"SYSLOG_FACILITY=4", "SYSLOG_FACILITY=10"}, emit)
}

var (
	reSSHFail      = regexp.MustCompile(`Failed (?:password|publickey|keyboard-interactive/pam|none) for (invalid user )?(\S+) from (\S+) port`)
	reSSHInvalid   = regexp.MustCompile(`^Invalid user (\S*) from (\S+)`)
	reSSHMaxAuth   = regexp.MustCompile(`maximum authentication attempts exceeded for (invalid user )?(\S+) from (\S+)`)
	reSSHPreauth   = regexp.MustCompile(`Connection (?:closed|reset) by (?:authenticating|invalid) user (\S+) (\S+) port \d+ \[preauth\]`)
	reSSHOK        = regexp.MustCompile(`Accepted (\S+) for (\S+) from (\S+) port`)
	reSudoCmd      = regexp.MustCompile(`^\s*(\S+) : (?:(\d+) incorrect (?:password|authentication) attempts? ; )?(?:.*?; )?TTY=(\S+) ; PWD=(.*?) ; USER=(\S+) ;(?:.*?;)? COMMAND=(.*)$`)
	reSudoNot      = regexp.MustCompile(`^\s*(\S+) : (?:user NOT in sudoers|user NOT authorized on host|command not allowed)`)
	rePamAuthFail  = regexp.MustCompile(`pam_unix\(([^:]+):auth\): authentication failure;.*?(?:rhost=(\S*))?\s+user=(\S*)`)
	rePamAuthFail2 = regexp.MustCompile(`pam_unix\(([^:]+):auth\): authentication failure;.*logname=(\S*) uid=(\d+)`)
	rePamSession   = regexp.MustCompile(`pam_unix\(([^:]+):session\): session opened for user (\S+?)(?:\(uid=\d+\))? by (\S*?)(?:\(uid=\d+\))?$`)
	reSuFailed     = regexp.MustCompile(`FAILED SU \(to (\S+)\) (\S+) on`)
	reNewUser      = regexp.MustCompile(`new user: name=([^,]+), UID=(\d+)`)
	reNewGroup     = regexp.MustCompile(`new group: name=([^,]+), GID=(\d+)`)
	reUserMod      = regexp.MustCompile(`(?:add '([^']+)' to (?:shadow )?group '([^']+)'|change user '([^']+)'|lock user '([^']+)'|unlock user '([^']+)')`)
	rePasswd       = regexp.MustCompile(`(?:password changed for|changed password expiry for|pam_unix\(passwd:chauthtok\): password changed for) (\S+)`)
	reUserDel      = regexp.MustCompile(`delete user '([^']+)'`)
	reGroupDel     = regexp.MustCompile(`(?:group '([^']+)' removed|removed group '([^']+)')`)
)

// parseAuth classifica mensagens de autenticação.
func parseAuth(e *model.Event) {
	m := e.Message
	prog := e.Program
	switch {
	case prog == "sshd" || strings.HasPrefix(prog, "sshd"):
		if x := reSSHOK.FindStringSubmatch(m); x != nil {
			e.Kind = "ssh_ok"
			e.Set("method", x[1])
			e.Set("user", x[2])
			e.Set("ip", x[3])
		} else if x := reSSHFail.FindStringSubmatch(m); x != nil {
			e.Kind = "ssh_fail"
			e.Set("user", x[2])
			e.Set("ip", x[3])
			if x[1] != "" {
				e.Set("invalid", "1")
			}
		} else if x := reSSHInvalid.FindStringSubmatch(m); x != nil {
			e.Kind = "ssh_fail"
			e.Set("user", x[1])
			e.Set("ip", x[2])
			e.Set("invalid", "1")
		} else if x := reSSHMaxAuth.FindStringSubmatch(m); x != nil {
			e.Kind = "ssh_fail"
			e.Set("user", x[2])
			e.Set("ip", x[3])
		} else if x := reSSHPreauth.FindStringSubmatch(m); x != nil {
			e.Kind = "ssh_fail"
			e.Set("user", x[1])
			e.Set("ip", x[2])
		} else if x := rePamSession.FindStringSubmatch(m); x != nil {
			e.Kind = "session_open"
			e.Set("service", "sshd")
			e.Set("user", x[2])
		}
	case prog == "sudo" || strings.HasPrefix(prog, "sudo-rs") || (strings.Contains(m, "TTY=") && strings.Contains(m, " ; COMMAND=")):
		if x := reSudoNot.FindStringSubmatch(m); x != nil {
			e.Kind = "sudo_denied"
			e.Set("user", x[1])
		} else if x := reSudoCmd.FindStringSubmatch(m); x != nil {
			e.Set("user", x[1])
			e.Set("tty", x[3])
			e.Set("runas", x[5])
			e.Set("cmd", x[6])
			if x[2] != "" {
				e.Kind = "sudo_fail"
				e.Set("attempts", x[2])
			} else {
				e.Kind = "sudo"
			}
		} else if x := rePamAuthFail2.FindStringSubmatch(m); x != nil && (strings.Contains(m, "pam_unix(sudo") || strings.Contains(m, "pam_unix(sudo-rs")) {
			e.Kind = "sudo_fail"
			e.Set("user", x[2])
		}
	case prog == "su":
		if x := reSuFailed.FindStringSubmatch(m); x != nil {
			e.Kind = "su_fail"
			e.Set("to", x[1])
			e.Set("user", x[2])
		} else if x := rePamSession.FindStringSubmatch(m); x != nil {
			e.Kind = "su"
			e.Set("to", x[2])
			e.Set("user", x[3])
		} else if strings.Contains(m, "authentication failure") {
			e.Kind = "su_fail"
			if x := rePamAuthFail2.FindStringSubmatch(m); x != nil {
				e.Set("user", x[2])
			}
		}
	case prog == "useradd" || prog == "adduser":
		if x := reNewUser.FindStringSubmatch(m); x != nil {
			e.Kind = "user_add"
			e.Set("user", strings.TrimSpace(x[1]))
			e.Set("uid", x[2])
		} else if x := reNewGroup.FindStringSubmatch(m); x != nil {
			e.Kind = "group_add"
			e.Set("group", strings.TrimSpace(x[1]))
		}
	case prog == "groupadd" || prog == "addgroup":
		if x := reNewGroup.FindStringSubmatch(m); x != nil {
			e.Kind = "group_add"
			e.Set("group", strings.TrimSpace(x[1]))
		}
	case prog == "usermod" || prog == "gpasswd":
		if x := reUserMod.FindStringSubmatch(m); x != nil {
			e.Kind = "user_mod"
			switch {
			case x[1] != "":
				e.Set("user", x[1])
				e.Set("group", x[2])
			case x[3] != "":
				e.Set("user", x[3])
			case x[4] != "":
				e.Set("user", x[4])
			case x[5] != "":
				e.Set("user", x[5])
			}
		}
	case prog == "userdel" || prog == "deluser":
		if x := reUserDel.FindStringSubmatch(m); x != nil {
			e.Kind = "user_del"
			e.Set("user", x[1])
		}
	case prog == "groupdel" || prog == "delgroup":
		if x := reGroupDel.FindStringSubmatch(m); x != nil {
			e.Kind = "group_del"
			g := x[1]
			if g == "" {
				g = x[2]
			}
			e.Set("group", g)
		}
	case prog == "passwd" || prog == "chpasswd" || prog == "chage":
		if x := rePasswd.FindStringSubmatch(m); x != nil {
			e.Kind = "passwd_change"
			e.Set("user", x[1])
		}
	}
	if e.Kind != "" {
		return
	}
	// Mensagens PAM genéricas (gdm, login, polkit...)
	if x := rePamAuthFail.FindStringSubmatch(m); x != nil {
		if x[1] == "sudo" || x[1] == "sudo-i" || strings.HasPrefix(x[1], "sudo-rs") || x[1] == "su" || x[1] == "su-l" || x[1] == "sshd" {
			return
		}
		e.Kind = "local_fail"
		e.Set("service", x[1])
		e.Set("user", x[3])
		if x[2] != "" {
			e.Set("ip", x[2])
		}
		return
	}
	if x := rePamSession.FindStringSubmatch(m); x != nil {
		e.Kind = "session_open"
		e.Set("service", x[1])
		e.Set("user", x[2])
	}
}

// ================================================================= kernel / dmesg

type kernel struct{ base }

func newKernel() Collector {
	return &kernel{base{"kernel", "kernel (kern.log / dmesg: OOM, segfault, erros de disco e hardware, USB)", "sistema"}}
}

func (k *kernel) paths(cfg *config.Config) []string {
	return cfg.SourcePaths(k.id, []string{"/var/log/kern.log"})
}

func (k *kernel) Requirements() []Requirement {
	return []Requirement{
		{Kind: "cmd", Name: "journalctl", Package: "systemd", Optional: true, Desc: "kernel de todos os boots via journal"},
		{Kind: "file", Name: "/var/log/kern.log", Package: "rsyslog", Optional: true, Desc: "kern.log"},
		{Kind: "cmd", Name: "dmesg", Package: "util-linux", Optional: true, Desc: "buffer do kernel (boot atual)"},
	}
}

func (k *kernel) WatchedFiles(cfg *config.Config) []string { return util.ExpandGlobs(k.paths(cfg)) }

func (k *kernel) mode(cfg *config.Config) string {
	m := cfg.SourceMode(k.id)
	if m == "arquivo" {
		return modeFor(cfg, k.id, k.paths(cfg), false)
	}
	if journalAvailable() && m != "arquivo" {
		return "journal"
	}
	if modeFor(cfg, k.id, k.paths(cfg), false) == "arquivo" {
		return "arquivo"
	}
	if util.CmdExists("dmesg") {
		return "dmesg"
	}
	return ""
}

func (k *kernel) Probe(cfg *config.Config) Probe {
	switch k.mode(cfg) {
	case "journal":
		return Probe{Available: true, Mode: "journal (_TRANSPORT=kernel, todos os boots)"}
	case "arquivo":
		return Probe{Available: true, Mode: "arquivo " + strings.Join(util.ExpandGlobs(k.paths(cfg)), ", ")}
	case "dmesg":
		return Probe{Available: true, Mode: "dmesg (somente boot atual)", Notes: []string{"sem histórico de boots anteriores"}}
	}
	return Probe{Available: false, Notes: []string{"nenhuma forma de ler o kernel"}}
}

func (k *kernel) Collect(ctx context.Context, c *Ctx) error {
	emit := func(e *model.Event) { parseKernel(e); c.Emit(e) }
	switch k.mode(c.Cfg) {
	case "journal":
		return readJournal(ctx, c, k.id, []string{"_TRANSPORT=kernel"}, emit)
	case "arquivo":
		return readSyslogFiles(ctx, c, k.id, k.paths(c.Cfg), emit)
	case "dmesg":
		return util.RunLines(ctx, func(line string) {
			// 2026-11-05T02:30:00,123456-03:00 mensagem
			sp := strings.SplitN(line, " ", 2)
			if len(sp) != 2 {
				return
			}
			t, ok := util.ParseISO(strings.Replace(sp[0], ",", ".", 1))
			if !ok || !c.InRange(t) {
				return
			}
			emit(&model.Event{Time: t, Source: k.id, Program: "kernel", Level: -1, Message: sp[1], Raw: line})
		}, "dmesg", "--time-format", "iso", "--nopager")
	}
	return nil
}

var (
	reOOM        = regexp.MustCompile(`(?:Out of memory: Killed process (\d+) \(([^)]+)\)|oom-kill:.*task=([^,]+),pid=(\d+)|Memory cgroup out of memory: Killed process (\d+) \(([^)]+)\))`)
	reSegfault   = regexp.MustCompile(`^(\S+?)\[(\d+)\]: (segfault at|general protection fault|trap invalid opcode|trap divide error)`)
	reKernelBug  = regexp.MustCompile(`(?i)(BUG: |kernel BUG at|Oops:|Kernel panic|general protection fault, |soft lockup|hard LOCKUP|blocked for more than \d+ seconds|RCU stall|WARNING: CPU: \d+ PID)`)
	reHWErr      = regexp.MustCompile(`(?i)(\[Hardware Error\]|Machine check|mce: |EDAC .*(?:CE|UE) |PCIe Bus Error|AER: (?:Corrected|Uncorrected|Multiple)|temperature above threshold|cpu clock throttled|thermal_zone.*critical|critical temperature reached|Thermal emergency|ACPI Error|firmware bug|DMAR:.*fault)`)
	reDiskErr    = regexp.MustCompile(`(?i)(I/O error|Buffer I/O error|blk_update_request|critical medium error|medium error|ata\d+(?:\.\d+)?: (?:failed command|exception Emask|error:|SError)|EXT4-fs (?:error|warning \(device .*\): ext4_.*error)|BTRFS (?:error|critical)|XFS \(.*\): (?:Corruption|metadata I/O error)|nvme\d+n?\d*:.*(?:timeout|I/O \d+ QID|controller is down|resetting controller|failed)|end_request: I/O error|sd \d+:\d+:\d+:\d+: \[sd\w+\] (?:Unhandled|tag#\d+ FAILED)|remount(?:ing)? (?:filesystem )?read-only)`)
	reUSBNew     = regexp.MustCompile(`^usb (\S+): New USB device found, idVendor=([0-9a-f]{4}), idProduct=([0-9a-f]{4})`)
	reUSBProd    = regexp.MustCompile(`^usb (\S+): Product: (.+)$`)
	reUSBDisc    = regexp.MustCompile(`^usb (\S+): USB disconnect`)
	reKMsgPrefix = regexp.MustCompile(`^\[\s*\d+\.\d+\]\s*`)
)

// parseKernel classifica mensagens do kernel.
func parseKernel(e *model.Event) {
	m := reKMsgPrefix.ReplaceAllString(e.Message, "")
	e.Message = m
	if strings.Contains(m, "[UFW ") || strings.Contains(m, `apparmor="`) {
		e.Set("skip_novel", "1")
		return
	}
	switch {
	case reOOM.MatchString(m):
		x := reOOM.FindStringSubmatch(m)
		e.Kind = "oom"
		proc := x[2]
		if proc == "" {
			proc = x[3]
		}
		if proc == "" {
			proc = x[6]
		}
		e.Set("proc", proc)
	case reSegfault.MatchString(m):
		x := reSegfault.FindStringSubmatch(m)
		e.Kind = "segfault"
		e.Set("proc", x[1])
	case reKernelBug.MatchString(m):
		e.Kind = "kernel_bug"
		e.Set("what", reKernelBug.FindString(m))
	case reHWErr.MatchString(m):
		e.Kind = "hw_error"
		e.Set("what", reHWErr.FindString(m))
	case reDiskErr.MatchString(m):
		e.Kind = "disk_error"
		e.Set("what", reDiskErr.FindString(m))
	case reUSBNew.MatchString(m):
		x := reUSBNew.FindStringSubmatch(m)
		e.Kind = "usb_new"
		e.Set("port", x[1])
		e.Set("id", x[2]+":"+x[3])
	case reUSBProd.MatchString(m):
		x := reUSBProd.FindStringSubmatch(m)
		e.Kind = "usb_product"
		e.Set("port", x[1])
		e.Set("product", x[2])
	case reUSBDisc.MatchString(m):
		e.Kind = "usb_disconnect"
	}
}

// ================================================================= UFW

type ufw struct{ base }

func newUFW() Collector {
	return &ufw{base{"ufw", "firewall UFW (bloqueios, varreduras de porta)", "seguranca"}}
}

func (u *ufw) paths(cfg *config.Config) []string {
	return cfg.SourcePaths(u.id, []string{"/var/log/ufw.log"})
}

func (u *ufw) Requirements() []Requirement {
	return []Requirement{
		{Kind: "cmd", Name: "ufw", Package: "ufw", Desc: "firewall UFW"},
		{Kind: "file", Name: "/var/log/ufw.log", Package: "rsyslog", Optional: true, Desc: "ufw.log (sem ele usa o journal)"},
	}
}

func (u *ufw) WatchedFiles(cfg *config.Config) []string { return util.ExpandGlobs(u.paths(cfg)) }

func (u *ufw) Probe(cfg *config.Config) Probe {
	if !util.CmdExists("ufw") && !util.AnyExists(u.paths(cfg)) {
		return Probe{Available: false, Notes: []string{"UFW não instalado"}}
	}
	p := Probe{Available: true}
	switch modeFor(cfg, u.id, u.paths(cfg), true) {
	case "arquivo":
		p.Mode = "arquivo " + strings.Join(util.ExpandGlobs(u.paths(cfg)), ", ")
	case "journal":
		p.Mode = "journal (mensagens [UFW do kernel)"
	default:
		return Probe{Available: false, Notes: []string{"sem ufw.log e sem journal"}}
	}
	if st := ufwStatus(); st == "inactive" {
		p.Notes = append(p.Notes, "UFW está INATIVO (sudo ufw enable)")
	}
	return p
}

func ufwStatus() string {
	if !util.CmdExists("ufw") {
		return ""
	}
	out, err := util.RunOutput(context.Background(), 10*time.Second, "ufw", "status")
	if err != nil {
		return ""
	}
	if strings.Contains(out, "Status: inactive") {
		return "inactive"
	}
	if strings.Contains(out, "Status: active") {
		return "active"
	}
	return ""
}

var reUFW = regexp.MustCompile(`\[UFW (\w+)\].*?SRC=(\S+) DST=(\S+).*?PROTO=(\S+)(?:.*?SPT=(\d+))?(?:.*?DPT=(\d+))?`)

func parseUFW(e *model.Event) bool {
	x := reUFW.FindStringSubmatch(e.Message)
	if x == nil {
		return false
	}
	e.Kind = "fw_" + strings.ToLower(x[1])
	e.Set("action", x[1])
	e.Set("src", x[2])
	e.Set("dst", x[3])
	e.Set("proto", x[4])
	e.Set("dpt", x[6])
	e.Set("skip_novel", "1")
	return true
}

func (u *ufw) Collect(ctx context.Context, c *Ctx) error {
	if !c.Learn {
		if ufwStatus() == "inactive" {
			c.Emit(&model.Event{Time: c.Now, Source: u.id, Kind: "fw_inactive", Snapshot: true, Message: "UFW inativo"})
		}
	}
	emit := func(e *model.Event) {
		if parseUFW(e) {
			c.Emit(e)
		}
	}
	if modeFor(c.Cfg, u.id, u.paths(c.Cfg), true) == "arquivo" {
		return readSyslogFiles(ctx, c, u.id, u.paths(c.Cfg), emit)
	}
	return readJournal(ctx, c, u.id, []string{"_TRANSPORT=kernel"}, func(e *model.Event) {
		if strings.Contains(e.Message, "[UFW ") {
			emit(e)
		}
	})
}

// ================================================================= AppArmor

type apparmor struct{ base }

func newAppArmor() Collector {
	return &apparmor{base{"apparmor", "AppArmor (negações de perfil)", "seguranca"}}
}

func (a *apparmor) Requirements() []Requirement {
	return []Requirement{
		{Kind: "dir", Name: "/sys/kernel/security/apparmor", Package: "apparmor", Desc: "AppArmor ativo no kernel"},
		{Kind: "cmd", Name: "aa-status", Package: "apparmor", Optional: true, Desc: "status dos perfis"},
	}
}

func (a *apparmor) Probe(cfg *config.Config) Probe {
	if !util.Exists("/sys/kernel/security/apparmor") && !util.CmdExists("aa-status") && !util.CmdExists("apparmor_status") {
		return Probe{Available: false, Notes: []string{"AppArmor não está ativo/instalado"}}
	}
	if util.Readable("/var/log/audit/audit.log") {
		return Probe{Available: true, Mode: "audit.log (apparmor=\"DENIED\")"}
	}
	if journalAvailable() {
		return Probe{Available: true, Mode: "journal (kernel/audit, apparmor=\"DENIED\")"}
	}
	if util.Readable("/var/log/kern.log") {
		return Probe{Available: true, Mode: "kern.log"}
	}
	return Probe{Available: false, Notes: []string{"sem fonte de leitura para mensagens AppArmor"}}
}

var reAA = regexp.MustCompile(`apparmor="(DENIED|ALLOWED|AUDIT)"\s+operation="([^"]*)".*?profile="([^"]*)"(?:.*?name="([^"]*)")?(?:.*?comm="([^"]*)")?`)

func parseAppArmor(e *model.Event) bool {
	x := reAA.FindStringSubmatch(e.Message)
	if x == nil || x[1] != "DENIED" {
		return false
	}
	e.Kind = "apparmor_denied"
	e.Set("op", x[2])
	e.Set("profile", x[3])
	e.Set("name", x[4])
	e.Set("comm", x[5])
	e.Set("skip_novel", "1")
	return true
}

func (a *apparmor) Collect(ctx context.Context, c *Ctx) error {
	emit := func(e *model.Event) {
		if parseAppArmor(e) {
			c.Emit(e)
		}
	}
	if util.Readable("/var/log/audit/audit.log") {
		return readAuditFiles(ctx, c, a.id, []string{"/var/log/audit/audit.log"}, emit)
	}
	if journalAvailable() {
		return readJournal(ctx, c, a.id, []string{"_TRANSPORT=kernel", "_TRANSPORT=audit"}, func(e *model.Event) {
			if strings.Contains(e.Message, "apparmor=") {
				emit(e)
			}
		})
	}
	return readSyslogFiles(ctx, c, a.id, []string{"/var/log/kern.log"}, emit)
}

// ================================================================= cron

type cron struct{ base }

func newCron() Collector {
	return &cron{base{"cron", "cron e timers do systemd (execuções e novos agendamentos)", "sistema"}}
}

func (cr *cron) Requirements() []Requirement {
	return []Requirement{
		{Kind: "cmd", Name: "cron", Package: "cron", Optional: true, Desc: "daemon cron"},
		{Kind: "cmd", Name: "systemctl", Package: "systemd", Optional: true, Desc: "lista de timers"},
	}
}

func (cr *cron) Probe(cfg *config.Config) Probe {
	var modes []string
	if journalAvailable() {
		modes = append(modes, "journal (cron.service)")
	} else if util.Readable("/var/log/syslog") {
		modes = append(modes, "syslog (CRON)")
	}
	modes = append(modes, "arquivos de crontab", "timers systemd")
	p := Probe{Available: true, Mode: strings.Join(modes, " + ")}
	if !util.CmdExists("cron") {
		p.Notes = append(p.Notes, "daemon cron não instalado (somente timers do systemd serão vistos)")
	}
	return p
}

var reCronCmd = regexp.MustCompile(`^\((\S+)\) CMD \((.*)\)\s*$`)

func parseCron(e *model.Event) {
	if x := reCronCmd.FindStringSubmatch(e.Message); x != nil {
		e.Kind = "cron_cmd"
		e.Set("user", x[1])
		e.Set("cmd", strings.TrimSpace(x[2]))
		e.Set("skip_novel", "1")
	}
}

func cronFiles(cfg *config.Config) []string {
	return util.ExpandGlobs(cfg.SourcePaths("cron", []string{"/etc/crontab", "/etc/cron.d/*", "/etc/cron.hourly/*",
		"/etc/cron.daily/*", "/etc/cron.weekly/*", "/etc/cron.monthly/*", "/var/spool/cron/crontabs/*", "/etc/anacrontab"}))
}

func (cr *cron) Collect(ctx context.Context, c *Ctx) error {
	emit := func(e *model.Event) { parseCron(e); c.Emit(e) }
	var err error
	if journalAvailable() {
		err = readJournal(ctx, c, cr.id, []string{"_SYSTEMD_UNIT=cron.service"}, emit)
	} else if util.Readable("/var/log/syslog") {
		err = readSyslogFiles(ctx, c, cr.id, []string{"/var/log/syslog"}, func(e *model.Event) {
			if strings.EqualFold(e.Program, "cron") {
				emit(e)
			}
		})
	}
	if c.Learn {
		return err
	}
	for _, f := range cronFiles(c.Cfg) {
		st, e2 := os.Stat(f)
		if e2 != nil || st.IsDir() || filepath.Base(f) == ".placeholder" {
			continue
		}
		h, e2 := util.SHA256File(f)
		if e2 != nil {
			continue
		}
		ev := &model.Event{Time: c.Now, Source: cr.id, Kind: "cron_file", Snapshot: true, Message: f}
		ev.Set("path", f)
		ev.Set("hash", h)
		c.Emit(ev)
	}
	if util.CmdExists("systemctl") {
		_ = util.RunLines(ctx, func(line string) {
			for _, f := range strings.Fields(line) {
				if strings.HasSuffix(f, ".timer") {
					ev := &model.Event{Time: c.Now, Source: cr.id, Kind: "timer", Snapshot: true, Message: f}
					ev.Set("unit", f)
					c.Emit(ev)
					break
				}
			}
		}, "systemctl", "list-timers", "--all", "--no-legend", "--plain", "--no-pager")
	}
	return err
}

// ================================================================= fail2ban

type fail2ban struct{ base }

func newFail2ban() Collector {
	return &fail2ban{base{"fail2ban", "fail2ban (banimentos)", "seguranca"}}
}

func (f *fail2ban) paths(cfg *config.Config) []string {
	return cfg.SourcePaths(f.id, []string{"/var/log/fail2ban.log"})
}

func (f *fail2ban) Requirements() []Requirement {
	return []Requirement{
		{Kind: "cmd", Name: "fail2ban-client", Package: "fail2ban", Desc: "fail2ban"},
		{Kind: "file", Name: "/var/log/fail2ban.log", Package: "fail2ban", Desc: "log do fail2ban"},
	}
}

func (f *fail2ban) WatchedFiles(cfg *config.Config) []string { return util.ExpandGlobs(f.paths(cfg)) }

func (f *fail2ban) Probe(cfg *config.Config) Probe {
	if !util.AnyExists(f.paths(cfg)) {
		return Probe{Available: false, Notes: []string{"fail2ban não instalado"}}
	}
	return Probe{Available: true, Mode: "arquivo " + strings.Join(util.ExpandGlobs(f.paths(cfg)), ", ")}
}

var reF2B = regexp.MustCompile(`^(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}),\d+\s+(\S+)\s+\[\d+\]:\s+(\w+)\s+\[([^\]]+)\]\s+(Ban|Unban|Found|Restore Ban|Increase Ban)\s+(\S+)`)
var reF2BGeneric = regexp.MustCompile(`^(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}),\d+\s+(\S+)\s+\[\d+\]:\s+(\w+)\s+(.*)$`)

func (f *fail2ban) Collect(ctx context.Context, c *Ctx) error {
	_, err := util.ScanLogFamily(ctx, f.paths(c.Cfg), c.Since, func(path, line string) {
		if x := reF2B.FindStringSubmatch(line); x != nil {
			t, ok := util.ParseISO(x[1])
			if !ok || !c.InRange(t) {
				return
			}
			e := &model.Event{Time: t, Source: f.id, Program: x[2], Level: levelFromWord(x[3]), Message: strings.SplitN(line, ": ", 2)[1], Raw: line}
			act := strings.ToLower(strings.ReplaceAll(x[5], " ", "_"))
			e.Kind = "f2b_" + act
			e.Set("jail", x[4])
			e.Set("ip", x[6])
			e.Set("skip_novel", "1")
			c.Emit(e)
			return
		}
		if x := reF2BGeneric.FindStringSubmatch(line); x != nil {
			t, ok := util.ParseISO(x[1])
			if !ok || !c.InRange(t) {
				return
			}
			c.Emit(&model.Event{Time: t, Source: f.id, Program: x[2], Level: levelFromWord(x[3]), Message: x[4], Raw: line})
		}
	})
	return err
}

// ================================================================= crash (apport)

type crash struct{ base }

func newCrash() Collector {
	return &crash{base{"crash", "relatórios de travamento (apport /var/crash)", "sistema"}}
}

func (cr *crash) Requirements() []Requirement {
	return []Requirement{{Kind: "dir", Name: "/var/crash", Package: "apport", Optional: true, Desc: "relatórios de crash do apport"}}
}

func (cr *crash) Probe(cfg *config.Config) Probe {
	dir := cfg.SourcePaths(cr.id, []string{"/var/crash"})[0]
	if !util.Exists(dir) {
		return Probe{Available: false, Notes: []string{dir + " inexistente (apport não instalado)"}}
	}
	return Probe{Available: true, Mode: "diretório " + dir}
}

func (cr *crash) Collect(ctx context.Context, c *Ctx) error {
	dir := c.Cfg.SourcePaths(cr.id, []string{"/var/crash"})[0]
	files, _ := filepath.Glob(filepath.Join(dir, "*.crash"))
	for _, f := range files {
		st, err := os.Stat(f)
		if err != nil || !c.InRange(st.ModTime()) {
			continue
		}
		e := &model.Event{Time: st.ModTime(), Source: cr.id, Kind: "app_crash", Message: "relatório de crash: " + filepath.Base(f), Level: 3}
		e.Set("file", f)
		e.Set("exe", crashExe(f))
		e.Set("skip_novel", "1")
		c.Emit(e)
	}
	return nil
}

func crashExe(f string) string {
	r, err := os.Open(f)
	if err != nil {
		return ""
	}
	defer r.Close()
	buf := make([]byte, 16*1024)
	n, _ := r.Read(buf)
	for _, l := range strings.Split(string(buf[:n]), "\n") {
		if strings.HasPrefix(l, "ExecutablePath: ") {
			return strings.TrimPrefix(l, "ExecutablePath: ")
		}
	}
	b := filepath.Base(f)
	b = strings.TrimSuffix(b, ".crash")
	return strings.ReplaceAll(strings.SplitN(b, ".", 2)[0], "_", "/")
}

// ================================================================= integridade

type integrity struct{ base }

func newIntegrity() Collector {
	return &integrity{base{"integridade", "integridade de arquivos críticos (contas, sudoers, SSH, PAM, preload)", "seguranca"}}
}

func (in *integrity) SnapshotOnly() bool { return true }

func (in *integrity) Requirements() []Requirement {
	return []Requirement{{Kind: "file", Name: "/etc/passwd", Package: "base-files", Desc: "arquivos de sistema"}}
}

func (in *integrity) Probe(cfg *config.Config) Probe {
	n := len(util.ExpandGlobs(cfg.Deteccao.ArquivosIntegridade))
	return Probe{Available: true, Mode: "hash SHA-256 de " + itoa(n) + " arquivos"}
}

func (in *integrity) Collect(ctx context.Context, c *Ctx) error {
	if c.Learn {
		return nil
	}
	for _, f := range util.ExpandGlobs(c.Cfg.Deteccao.ArquivosIntegridade) {
		st, err := os.Stat(f)
		if err != nil || st.IsDir() {
			continue
		}
		h, err := util.SHA256File(f)
		if err != nil {
			continue
		}
		e := &model.Event{Time: c.Now, Source: in.id, Kind: "file_hash", Snapshot: true, Message: f}
		e.Set("path", f)
		e.Set("hash", h)
		e.Set("size", itoa(int(st.Size())))
		e.Set("mtime", st.ModTime().Format(time.RFC3339))
		c.Emit(e)
	}
	// contas locais (detecção de novos usuários e UID 0 extra)
	if data, err := os.ReadFile("/etc/passwd"); err == nil {
		for _, l := range strings.Split(string(data), "\n") {
			p := strings.Split(l, ":")
			if len(p) < 7 {
				continue
			}
			e := &model.Event{Time: c.Now, Source: in.id, Kind: "account", Snapshot: true, Message: "conta " + p[0]}
			e.Set("user", p[0])
			e.Set("uid", p[2])
			e.Set("shell", p[6])
			c.Emit(e)
		}
	}
	// /etc/ld.so.preload não deveria existir em um Ubuntu padrão
	if data, err := os.ReadFile("/etc/ld.so.preload"); err == nil && strings.TrimSpace(string(data)) != "" {
		e := &model.Event{Time: c.Now, Source: in.id, Kind: "ld_preload", Snapshot: true,
			Message: "/etc/ld.so.preload contém: " + strings.TrimSpace(string(data))}
		c.Emit(e)
	}
	return nil
}

func shortHash(s string) string {
	h := sha256.Sum256([]byte(s))
	return hex.EncodeToString(h[:6])
}
