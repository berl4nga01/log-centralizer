package backup

import (
	"bufio"
	"crypto/aes"
	"crypto/cipher"
	"crypto/pbkdf2"
	"crypto/rand"
	"crypto/sha256"
	"encoding/binary"
	"errors"
	"fmt"
	"io"
	"os"
	"strings"
)

// Formato do arquivo criptografado (.enc):
//   "LCZENC01" | sal(16) | iterações(uint32) | prefixo do nonce(4)
//   blocos: flag(1) | tamanho(uint32) | texto cifrado AES-256-GCM
// flag=1 marca o último bloco (protege contra truncamento). A chave é derivada
// da senha com PBKDF2-SHA256.

const (
	encMagic   = "LCZENC01"
	encIter    = 600000
	encChunk   = 64 * 1024
	flagNormal = 0
	flagLast   = 1
)

// ReadPassphrase lê a senha do arquivo indicado.
func ReadPassphrase(path string) (string, error) {
	b, err := os.ReadFile(path)
	if err != nil {
		return "", fmt.Errorf("não foi possível ler o arquivo de senha %s: %w", path, err)
	}
	p := strings.TrimSpace(string(b))
	if len(p) < 12 {
		return "", errors.New("a senha de criptografia deve ter pelo menos 12 caracteres")
	}
	return p, nil
}

func deriveKey(pass string, salt []byte, iter int) ([]byte, error) {
	return pbkdf2.Key(sha256.New, pass, salt, iter, 32)
}

type encWriter struct {
	w      io.Writer
	aead   cipher.AEAD
	prefix [4]byte
	ctr    uint64
	buf    []byte
	closed bool
}

func newEncWriter(w io.Writer, pass string) (*encWriter, error) {
	salt := make([]byte, 16)
	if _, err := rand.Read(salt); err != nil {
		return nil, err
	}
	key, err := deriveKey(pass, salt, encIter)
	if err != nil {
		return nil, err
	}
	blk, err := aes.NewCipher(key)
	if err != nil {
		return nil, err
	}
	aead, err := cipher.NewGCM(blk)
	if err != nil {
		return nil, err
	}
	e := &encWriter{w: w, aead: aead, buf: make([]byte, 0, encChunk)}
	if _, err := rand.Read(e.prefix[:]); err != nil {
		return nil, err
	}
	hdr := make([]byte, 0, 32)
	hdr = append(hdr, encMagic...)
	hdr = append(hdr, salt...)
	hdr = binary.BigEndian.AppendUint32(hdr, encIter)
	hdr = append(hdr, e.prefix[:]...)
	if _, err := w.Write(hdr); err != nil {
		return nil, err
	}
	return e, nil
}

func (e *encWriter) nonce(flag byte) []byte {
	n := make([]byte, 12)
	copy(n, e.prefix[:])
	binary.BigEndian.PutUint64(n[4:], e.ctr<<8|uint64(flag))
	return n
}

func (e *encWriter) seal(flag byte) error {
	ct := e.aead.Seal(nil, e.nonce(flag), e.buf, []byte{flag})
	h := []byte{flag, 0, 0, 0, 0}
	binary.BigEndian.PutUint32(h[1:], uint32(len(ct)))
	if _, err := e.w.Write(h); err != nil {
		return err
	}
	if _, err := e.w.Write(ct); err != nil {
		return err
	}
	e.ctr++
	e.buf = e.buf[:0]
	return nil
}

func (e *encWriter) Write(p []byte) (int, error) {
	n := 0
	for len(p) > 0 {
		room := encChunk - len(e.buf)
		k := len(p)
		if k > room {
			k = room
		}
		e.buf = append(e.buf, p[:k]...)
		p = p[k:]
		n += k
		if len(e.buf) == encChunk {
			if err := e.seal(flagNormal); err != nil {
				return n, err
			}
		}
	}
	return n, nil
}

func (e *encWriter) Close() error {
	if e.closed {
		return nil
	}
	e.closed = true
	return e.seal(flagLast)
}

// Decrypt descriptografa um arquivo .enc para out.
func Decrypt(in, out, pass string) error {
	f, err := os.Open(in)
	if err != nil {
		return err
	}
	defer f.Close()
	r := bufio.NewReaderSize(f, 256*1024)
	hdr := make([]byte, 8+16+4+4)
	if _, err := io.ReadFull(r, hdr); err != nil {
		return errors.New("arquivo muito curto ou corrompido")
	}
	if string(hdr[:8]) != encMagic {
		return errors.New("o arquivo não é um backup criptografado do logcentralizer")
	}
	salt := hdr[8:24]
	iter := int(binary.BigEndian.Uint32(hdr[24:28]))
	var prefix [4]byte
	copy(prefix[:], hdr[28:32])
	key, err := deriveKey(pass, salt, iter)
	if err != nil {
		return err
	}
	blk, _ := aes.NewCipher(key)
	aead, _ := cipher.NewGCM(blk)
	o, err := os.OpenFile(out, os.O_CREATE|os.O_WRONLY|os.O_TRUNC, 0o600)
	if err != nil {
		return err
	}
	defer o.Close()
	var ctr uint64
	for {
		h := make([]byte, 5)
		if _, err := io.ReadFull(r, h); err != nil {
			return errors.New("arquivo truncado: o bloco final não foi encontrado")
		}
		flag := h[0]
		size := binary.BigEndian.Uint32(h[1:])
		if size > encChunk+64 {
			return errors.New("bloco inválido (arquivo corrompido)")
		}
		ct := make([]byte, size)
		if _, err := io.ReadFull(r, ct); err != nil {
			return errors.New("arquivo truncado")
		}
		n := make([]byte, 12)
		copy(n, prefix[:])
		binary.BigEndian.PutUint64(n[4:], ctr<<8|uint64(flag))
		pt, err := aead.Open(nil, n, ct, []byte{flag})
		if err != nil {
			return errors.New("senha incorreta ou arquivo adulterado")
		}
		if _, err := o.Write(pt); err != nil {
			return err
		}
		ctr++
		if flag == flagLast {
			break
		}
	}
	return o.Sync()
}
