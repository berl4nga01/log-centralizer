// Package collectors contém os coletores de cada fonte de log. Cada coletor
// implementa a interface Collector e é registrado em All(); para adicionar uma
// nova fonte basta criar um tipo novo e incluí-lo no registro (escalável).
package collectors

import (
	"context"
	"encoding/json"
	"fmt"
	"strconv"
	"strings"
	"time"

	"logcentralizer/internal/config"
	"logcentralizer/internal/model"
	"logcentralizer/internal/util"
)

// Requirement descreve uma ferramenta/arquivo que a fonte precisa.
type Requirement struct {
	Kind     string // cmd | file | dir
	Name     string
	Package  string // pacote apt que fornece
	Optional bool   // true = só melhora a coleta
	Desc     string
}

// Present verifica se o requisito está presente na máquina.
func (r Requirement) Present() bool {
	switch r.Kind {
	case "cmd":
		return util.CmdExists(r.Name)
	default:
		return util.AnyExists([]string{r.Name})
	}
}

// Probe é o resultado da verificação de disponibilidade de uma fonte.
type Probe struct {
	Available bool
	Mode      string   // descrição de como a fonte será lida
	Notes     []string // observações para o usuário
}

// Ctx é o contexto passado aos coletores em cada execução.
type Ctx struct {
	Cfg   *config.Config
	Since time.Time
	Until time.Time
	Learn bool // passada de aprendizado (sem fotografias do estado atual)
	Now   time.Time
	Emit  func(*model.Event)
	Debug func(format string, a ...any)
}

// InRange informa se t está na janela [Since, Until).
func (c *Ctx) InRange(t time.Time) bool {
	return !t.Before(c.Since) && t.Before(c.Until)
}

// Collector é a interface comum das fontes.
type Collector interface {
	ID() string
	Name() string
	Category() string
	Requirements() []Requirement
	Probe(cfg *config.Config) Probe
	Collect(ctx context.Context, c *Ctx) error
	// SnapshotOnly = a fonte só tira "fotografias" do estado atual (não tem histórico).
	SnapshotOnly() bool
	// WatchedFiles = arquivos principais de log monitorados contra truncamento.
	WatchedFiles(cfg *config.Config) []string
}

// base fornece implementações padrão.
type base struct {
	id, name, cat string
}

func (b base) ID() string                               { return b.id }
func (b base) Name() string                             { return b.name }
func (b base) Category() string                         { return b.cat }
func (b base) SnapshotOnly() bool                       { return false }
func (b base) WatchedFiles(cfg *config.Config) []string { return nil }

// All devolve todos os coletores registrados (ordem de exibição).
func All(cfg *config.Config) []Collector {
	list := []Collector{
		newJournald(),
		newSyslog(),
		newAuth(),
		newKernel(),
		newLogins(),
		newPackages(),
		newUFW(),
		newAudit(),
		newAppArmor(),
		newCron(),
		newFail2ban(),
		newWeb("nginx", "Nginx (access/error)", []string{"/var/log/nginx/access.log"}, []string{"/var/log/nginx/error.log"}, "nginx"),
		newWeb("apache", "Apache (access/error)", []string{"/var/log/apache2/access.log", "/var/log/apache2/other_vhosts_access.log"}, []string{"/var/log/apache2/error.log"}, "apache2"),
		newDocker(),
		newMySQL(),
		newPostgres(),
		newHardware(),
		newResources(),
		newProcesses(),
		newAccounting(),
		newIntegrity(),
		newCrash(),
	}
	for _, fp := range cfg.FontesPersonalizadas {
		list = append(list, newCustom(fp))
	}
	return list
}

// ---------------------------------------------------------------- journald

// journalEntry contém os campos usados do journalctl -o json.
type journalEntry struct {
	Realtime   string          `json:"__REALTIME_TIMESTAMP"`
	Message    json.RawMessage `json:"MESSAGE"`
	Priority   string          `json:"PRIORITY"`
	Unit       string          `json:"_SYSTEMD_UNIT"`
	Identifier string          `json:"SYSLOG_IDENTIFIER"`
	Comm       string          `json:"_COMM"`
	Transport  string          `json:"_TRANSPORT"`
	Facility   string          `json:"SYSLOG_FACILITY"`
	Hostname   string          `json:"_HOSTNAME"`
	PID        string          `json:"_PID"`
	UnitResult string          `json:"UNIT_RESULT"`
	UserUnit   string          `json:"_SYSTEMD_USER_UNIT"`
	CoreExe    string          `json:"COREDUMP_EXE"`
	ObjUnit    string          `json:"UNIT"`
}

func decodeJournalMessage(raw json.RawMessage) string {
	if len(raw) == 0 {
		return ""
	}
	if raw[0] == '"' {
		var s string
		_ = json.Unmarshal(raw, &s)
		return s
	}
	if raw[0] == '[' {
		var b []int
		if json.Unmarshal(raw, &b) == nil {
			bs := make([]byte, len(b))
			for i, v := range b {
				bs[i] = byte(v)
			}
			return strings.ToValidUTF8(string(bs), "?")
		}
	}
	return string(raw)
}

func (j *journalEntry) toEvent(source string) *model.Event {
	us, _ := strconv.ParseInt(j.Realtime, 10, 64)
	prog := j.Identifier
	if prog == "" {
		prog = j.Comm
	}
	lvl := -1
	if j.Priority != "" {
		lvl, _ = strconv.Atoi(j.Priority)
	}
	e := &model.Event{
		Time:    time.UnixMicro(us).Local(),
		Source:  source,
		Host:    j.Hostname,
		Program: prog,
		Level:   lvl,
		Message: decodeJournalMessage(j.Message),
	}
	if j.Unit != "" {
		e.Set("unit", j.Unit)
	}
	if j.ObjUnit != "" {
		e.Set("obj_unit", j.ObjUnit)
	}
	if j.PID != "" {
		e.Set("pid", j.PID)
	}
	if j.CoreExe != "" {
		e.Set("core_exe", j.CoreExe)
	}
	if j.Transport != "" {
		e.Set("transport", j.Transport)
	}
	if j.Facility != "" {
		e.Set("facility", j.Facility)
	}
	if j.UnitResult != "" {
		e.Set("unit_result", j.UnitResult)
	}
	return e
}

// journalAvailable informa se o journalctl existe e consegue ler.
func journalAvailable() bool { return util.CmdExists("journalctl") }

// readJournal executa journalctl em JSON com os filtros dados.
func readJournal(ctx context.Context, c *Ctx, source string, matches []string, fn func(*model.Event)) error {
	args := []string{"-o", "json", "--no-pager", "-q", "--all",
		"--since", fmt.Sprintf("@%d", c.Since.Unix()),
		"--until", fmt.Sprintf("@%d", c.Until.Unix()),
		"--output-fields=MESSAGE,PRIORITY,_SYSTEMD_UNIT,SYSLOG_IDENTIFIER,_COMM,_TRANSPORT,SYSLOG_FACILITY,_HOSTNAME,_PID,UNIT_RESULT,COREDUMP_EXE,UNIT"}
	args = append(args, matches...)
	var parseErr int
	err := util.RunLines(ctx, func(line string) {
		var j journalEntry
		if err := json.Unmarshal([]byte(line), &j); err != nil {
			parseErr++
			return
		}
		e := j.toEvent(source)
		if !c.InRange(e.Time) {
			return
		}
		fn(e)
	}, "journalctl", args...)
	if err != nil && c.Debug != nil {
		c.Debug("journalctl %v: %v", matches, err)
	}
	return err
}

// ---------------------------------------------------------------- arquivos syslog

// readSyslogFiles lê arquivos em formato syslog (com rotação) dentro da janela.
func readSyslogFiles(ctx context.Context, c *Ctx, source string, paths []string, fn func(*model.Event)) error {
	var last time.Time
	_, err := util.ScanLogFamily(ctx, paths, c.Since, func(path, line string) {
		sl, ok := util.ParseSyslog(line, c.Now)
		if !ok {
			return
		}
		last = sl.Time
		if !c.InRange(sl.Time) {
			return
		}
		e := &model.Event{Time: sl.Time, Source: source, Host: sl.Host, Program: sl.Program,
			Level: -1, Message: sl.Message, Raw: line}
		if sl.PID != "" {
			e.Set("pid", sl.PID)
		}
		fn(e)
	})
	_ = last
	return err
}

// modeFor decide entre arquivo e journal.
// Retorna "arquivo", "journal" ou "" (indisponível).
func modeFor(cfg *config.Config, id string, paths []string, journalOK bool) string {
	m := cfg.SourceMode(id)
	fileOK := false
	for _, p := range util.ExpandGlobs(paths) {
		if util.Readable(p) {
			fileOK = true
			break
		}
	}
	switch m {
	case "arquivo":
		if fileOK {
			return "arquivo"
		}
		return ""
	case "journal":
		if journalOK && journalAvailable() {
			return "journal"
		}
		return ""
	}
	if fileOK {
		return "arquivo"
	}
	if journalOK && journalAvailable() {
		return "journal"
	}
	return ""
}

// levelFromWord converte palavras de nível em prioridade syslog.
func levelFromWord(w string) int {
	switch strings.ToLower(strings.Trim(w, "[]: ")) {
	case "emerg", "emergency", "panic":
		return 0
	case "alert":
		return 1
	case "crit", "critical", "fatal":
		return 2
	case "err", "error", "erro":
		return 3
	case "warn", "warning", "aviso":
		return 4
	case "notice", "note":
		return 5
	case "info", "information", "informational", "system":
		return 6
	case "debug", "trace":
		return 7
	}
	return -1
}
