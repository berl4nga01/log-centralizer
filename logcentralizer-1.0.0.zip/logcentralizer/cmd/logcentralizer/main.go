// logcentralizer — centralizador de logs com linha de base e detecção de anomalias.
package main

import (
	"bufio"
	"context"
	"crypto/rand"
	"encoding/base64"
	"errors"
	"flag"
	"fmt"
	"os"
	"os/signal"
	"path/filepath"
	"sort"
	"strings"
	"syscall"
	"time"
	_ "time/tzdata" // fuso horário embutido (funciona mesmo sem o pacote tzdata)

	"logcentralizer/internal/analyzer"
	"logcentralizer/internal/backup"
	"logcentralizer/internal/collectors"
	"logcentralizer/internal/config"
	"logcentralizer/internal/report"
	"logcentralizer/internal/solutions"
	"logcentralizer/internal/store"
	"logcentralizer/internal/toolcheck"
	"logcentralizer/internal/util"
)

var version = "1.0.0"

const usage = `logcentralizer %s — centralizador de logs com linha de base e detecção de anomalias

USO
  sudo logcentralizer <comando> [opções]

COMANDOS
  analisar            Coleta todos os logs, compara com a linha de base, gera relatório e backup
      --fontes a,b        analisa apenas as fontes indicadas (veja 'fontes')
      --periodo 24h       força o período analisado (ex.: 6h, 3d) em vez de "desde a última análise"
      --sem-backup        não gera o backup nesta execução
      --sem-internet      não pesquisa soluções na internet (usa só a base local)
      --imprimir          mostra o relatório completo no terminal ao final
      --codigo-saida      sai com código 2 (ATENÇÃO) ou 3 (ANORMAL) quando houver anomalias
      --verbose           mostra detalhes da coleta
  verificar           Verifica se as ferramentas/arquivos de cada fonte estão instalados
      --instalar          oferece instalar os pacotes que faltam (apt)
      -y                  instala sem perguntar
  fontes              Lista as fontes de log e se estão disponíveis
  relatorio [arq]     Mostra o último relatório (ou o arquivo indicado)
      --lista             lista os relatórios salvos
  historico           Mostra o resumo das análises anteriores
      -n 20               quantidade de análises (padrão: relatorio.analises_no_historico)
  backup listar       Lista os backups
  backup verificar    Confere o SHA-256 de todos os backups
  backup criar        Cria um backup agora (sem análise)
  backup descriptografar <arquivo.enc> [--saida arquivo.tar.gz]
  linha-de-base status    Mostra o estado da linha de base (o "habitual")
  linha-de-base resetar   Apaga a linha de base (o aprendizado recomeça na próxima análise)
  config init [--forcar]  Cria /etc/logcentralizer/config.json com os valores padrão
  config mostrar          Mostra a configuração efetiva
  config validar          Valida o arquivo de configuração
  config sensibilidade baixa|media|alta
  config criptografia ativar|desativar   (gera a senha dos backups automaticamente)
  config brave-chave <CHAVE>|remover     (chave da Brave Search API)
  versao              Mostra a versão
  ajuda               Mostra esta ajuda

OPÇÃO GLOBAL
  --config <arquivo>  usa outro arquivo de configuração (padrão: /etc/logcentralizer/config.json)

Documentação completa: TUTORIAL.md
`

func main() {
	args := os.Args[1:]
	cfgPath := config.DefaultPath
	var rest []string
	for i := 0; i < len(args); i++ {
		if args[i] == "--config" && i+1 < len(args) {
			cfgPath = args[i+1]
			i++
			continue
		}
		if strings.HasPrefix(args[i], "--config=") {
			cfgPath = strings.TrimPrefix(args[i], "--config=")
			continue
		}
		rest = append(rest, args[i])
	}
	if len(rest) == 0 {
		fmt.Printf(usage, version)
		os.Exit(0)
	}
	cmd, sub := rest[0], rest[1:]
	var err error
	code := 0
	switch cmd {
	case "ajuda", "help", "-h", "--help":
		fmt.Printf(usage, version)
	case "versao", "version", "--version":
		fmt.Println("logcentralizer", version)
	case "analisar", "analyze":
		code, err = cmdAnalyze(cfgPath, sub)
	case "verificar", "check":
		err = cmdCheck(cfgPath, sub)
	case "fontes", "sources":
		err = cmdSources(cfgPath)
	case "relatorio", "report":
		err = cmdReport(cfgPath, sub)
	case "historico", "history":
		err = cmdHistory(cfgPath, sub)
	case "backup":
		err = cmdBackup(cfgPath, sub)
	case "linha-de-base", "baseline":
		err = cmdBaseline(cfgPath, sub)
	case "config":
		err = cmdConfig(cfgPath, sub)
	default:
		err = fmt.Errorf("comando desconhecido: %s (use 'logcentralizer ajuda')", cmd)
	}
	if err != nil {
		fmt.Fprintln(os.Stderr, "erro:", err)
		os.Exit(1)
	}
	os.Exit(code)
}

func requireRoot() error {
	if os.Geteuid() != 0 {
		return errors.New("este comando precisa ser executado como root (use: sudo logcentralizer ...)")
	}
	return nil
}

func loadConfig(path string) (*config.Config, error) {
	c, err := config.Load(path)
	if err != nil {
		return nil, err
	}
	return c, nil
}

// splitArgs separa flags de argumentos posicionais (permite flags depois dos argumentos).
func splitArgs(fs *flag.FlagSet, args []string) ([]string, error) {
	var pos, flags []string
	for i := 0; i < len(args); i++ {
		a := args[i]
		if strings.HasPrefix(a, "-") {
			flags = append(flags, a)
			name := strings.TrimLeft(a, "-")
			if !strings.Contains(name, "=") {
				if f := fs.Lookup(name); f != nil {
					if bf, ok := f.Value.(interface{ IsBoolFlag() bool }); !ok || !bf.IsBoolFlag() {
						if i+1 < len(args) {
							flags = append(flags, args[i+1])
							i++
						}
					}
				}
			}
			continue
		}
		pos = append(pos, a)
	}
	if err := fs.Parse(flags); err != nil {
		return nil, err
	}
	return pos, nil
}

func lock() (func(), error) {
	p := "/run/logcentralizer.lock"
	if !util.Exists("/run") {
		p = filepath.Join(os.TempDir(), "logcentralizer.lock")
	}
	f, err := os.OpenFile(p, os.O_CREATE|os.O_RDWR, 0o600)
	if err != nil {
		return func() {}, nil
	}
	if err := syscall.Flock(int(f.Fd()), syscall.LOCK_EX|syscall.LOCK_NB); err != nil {
		f.Close()
		return nil, errors.New("já existe uma análise em andamento (arquivo de trava " + p + ")")
	}
	return func() { syscall.Flock(int(f.Fd()), syscall.LOCK_UN); f.Close() }, nil
}

// ---------------------------------------------------------------- analisar

func cmdAnalyze(cfgPath string, args []string) (int, error) {
	fs := flag.NewFlagSet("analisar", flag.ContinueOnError)
	only := fs.String("fontes", "", "")
	periodo := fs.String("periodo", "", "")
	noBackup := fs.Bool("sem-backup", false, "")
	noWeb := fs.Bool("sem-internet", false, "")
	printAll := fs.Bool("imprimir", false, "")
	exitCode := fs.Bool("codigo-saida", false, "")
	verbose := fs.Bool("verbose", false, "")
	if _, err := splitArgs(fs, args); err != nil {
		return 0, err
	}
	if err := requireRoot(); err != nil {
		return 0, err
	}
	cfg, err := loadConfig(cfgPath)
	if err != nil {
		return 0, err
	}
	unlock, err := lock()
	if err != nil {
		return 0, err
	}
	defer unlock()

	ctx, cancel := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
	defer cancel()

	if err := os.MkdirAll(cfg.DiretorioDados, 0o700); err != nil {
		return 0, err
	}
	base, err := store.LoadBaseline(cfg.DiretorioDados)
	if err != nil {
		return 0, fmt.Errorf("linha de base corrompida (%v); use 'logcentralizer linha-de-base resetar'", err)
	}
	opt := analyzer.Options{Verbose: *verbose, Out: os.Stdout}
	if *only != "" {
		for _, s := range strings.Split(*only, ",") {
			opt.OnlySources = append(opt.OnlySources, strings.TrimSpace(s))
		}
	}
	if *periodo != "" {
		d, err := parseDuration(*periodo)
		if err != nil {
			return 0, err
		}
		opt.Lookback = d
	}
	fmt.Printf("logcentralizer %s — análise em %s\n", version, cfg.NomeHost)
	an := analyzer.New(cfg, base, opt)
	res, err := an.Run(ctx)
	if err != nil {
		return 0, err
	}
	if ctx.Err() != nil {
		return 0, errors.New("análise interrompida")
	}

	// soluções: base local + internet
	cache := store.LoadSearchCache(cfg.DiretorioDados)
	web := cfg.BuscaWeb.Ativo && !*noWeb
	if web {
		fmt.Println("• Pesquisando soluções na internet para as anomalias mais graves...")
	}
	s := solutions.Enrich(ctx, cfg, res.Anomalies, cache, web, func(q string) {
		if *verbose {
			fmt.Println("  [busca]", q)
		}
	})
	_ = cache.Save(time.Duration(cfg.BuscaWeb.CacheDias+1) * 24 * time.Hour)

	// grava a linha de base antes do backup (o backup inclui o estado)
	if err := base.Save(cfg.DiretorioDados); err != nil {
		fmt.Fprintln(os.Stderr, "aviso: não foi possível gravar a linha de base:", err)
	}
	hist, _ := store.LoadHistory(cfg.DiretorioDados)
	stamp := res.Start
	reportPath := report.UniquePath(filepath.Join(cfg.DiretorioRelatorios, "relatorio_"+stamp.Format("20060102_150405")+".txt"))

	var binfo *backup.Info
	var berr string
	if cfg.Backup.Ativo && !*noBackup {
		fmt.Println("• Criando backup de todos os logs...")
		binfo, err = backup.Create(ctx, cfg, backup.Meta{Host: cfg.NomeHost, Since: res.Since, Until: res.Until,
			Verdict: res.Verdict, Report: reportPath, Anomaly: len(res.Anomalies)}, stamp)
		if err != nil {
			berr = err.Error()
			fmt.Fprintln(os.Stderr, "aviso: backup falhou:", err)
		}
	}

	entry := store.HistoryEntry{Time: stamp, Since: res.Since, Until: res.Until, DurationSec: res.Duration.Seconds(),
		Events: res.TotalEvents, BySource: map[string]int64{}, Severities: res.SeverityCounts(), Verdict: res.Verdict,
		Top: report.HistoryTop(res.Anomalies), Report: reportPath, Learning: res.Learning, Sensitivity: cfg.Deteccao.Sensibilidade}
	for _, st := range res.Sources {
		if st.Enabled && st.Available {
			entry.BySource[st.ID] = st.Events
		}
	}
	if binfo != nil {
		entry.Backup = binfo.Path
	}
	hist = append(hist, entry)

	text := report.Render(report.Input{Cfg: cfg, Res: res, History: hist, Backup: binfo, BackupErr: berr,
		Tools: toolcheck.Check(cfg), WebUsed: s.Used(), WebEnabled: web, WebErrors: s.Errors, Version: version})
	if _, err := report.Save(cfg.DiretorioRelatorios, stamp, text); err != nil {
		return 0, fmt.Errorf("não foi possível gravar o relatório: %w", err)
	}
	report.Prune(cfg.DiretorioRelatorios, cfg.Relatorio.RetencaoRelatoriosDias, stamp)
	if err := store.SaveHistory(cfg.DiretorioDados, hist, cfg.Relatorio.HistoricoMaximoRegistros); err != nil {
		fmt.Fprintln(os.Stderr, "aviso: não foi possível gravar o histórico:", err)
	}

	if *printAll {
		fmt.Println()
		fmt.Print(text)
	} else {
		printSummary(res, reportPath, binfo)
	}
	if *exitCode {
		switch {
		case strings.HasPrefix(res.Verdict, "ANORMAL"):
			return 3, nil
		case strings.HasPrefix(res.Verdict, "ATENÇÃO"):
			return 2, nil
		}
	}
	return 0, nil
}

func printSummary(res *analyzer.Result, reportPath string, b *backup.Info) {
	sc := res.SeverityCounts()
	fmt.Println()
	fmt.Println(strings.Repeat("=", 70))
	fmt.Printf(" VEREDITO: %s\n", res.Verdict)
	fmt.Printf(" Eventos analisados: %d | Anomalias: CRÍTICA %d, ALTA %d, MÉDIA %d, BAIXA %d\n",
		res.TotalEvents, sc["CRITICA"], sc["ALTA"], sc["MEDIA"], sc["BAIXA"])
	if res.Learning {
		fmt.Printf(" Modo aprendizado: linha de base com %d/%d horas (regras de novidade/volume desligadas)\n", res.BaseHoursBefore, res.MinHours)
	}
	fmt.Println(strings.Repeat("=", 70))
	n := 0
	for _, a := range res.Anomalies {
		if a.Severity.String() == "INFO" {
			continue
		}
		if n >= 10 {
			fmt.Printf("  ... e mais %d no relatório\n", len(res.Anomalies)-n)
			break
		}
		fmt.Printf("  [%-7s] %s\n", a.Severity, util.Truncate(a.Title, 85))
		n++
	}
	if n == 0 {
		fmt.Println("  Nenhuma anomalia relevante: comportamento dentro do habitual.")
	}
	fmt.Println()
	fmt.Println(" Relatório completo:", reportPath)
	if b != nil {
		fmt.Printf(" Backup: %s (%s)\n", b.Path, util.HumanBytes(b.Size))
	}
	fmt.Println(" Ver relatório: sudo logcentralizer relatorio")
}

func parseDuration(s string) (time.Duration, error) {
	if strings.HasSuffix(s, "d") {
		var n int
		if _, err := fmt.Sscanf(strings.TrimSuffix(s, "d"), "%d", &n); err != nil || n <= 0 {
			return 0, fmt.Errorf("período inválido: %s", s)
		}
		return time.Duration(n) * 24 * time.Hour, nil
	}
	d, err := time.ParseDuration(s)
	if err != nil || d <= 0 {
		return 0, fmt.Errorf("período inválido: %s (exemplos: 30m, 6h, 2d)", s)
	}
	return d, nil
}

// ---------------------------------------------------------------- verificar / fontes

func cmdCheck(cfgPath string, args []string) error {
	fs := flag.NewFlagSet("verificar", flag.ContinueOnError)
	install := fs.Bool("instalar", false, "")
	yes := fs.Bool("y", false, "")
	if _, err := splitArgs(fs, args); err != nil {
		return err
	}
	if err := requireRoot(); err != nil {
		return err
	}
	cfg, err := loadConfig(cfgPath)
	if err != nil {
		return err
	}
	states := toolcheck.Check(cfg)
	toolcheck.Print(os.Stdout, states)
	if !*install {
		return nil
	}
	rec, opt := toolcheck.MissingPackages(states)
	var pk []string
	if len(rec) > 0 {
		if *yes || ask(fmt.Sprintf("Instalar os pacotes recomendados (%s)? [s/N] ", strings.Join(rec, " "))) {
			pk = append(pk, rec...)
		}
	}
	if len(opt) > 0 {
		if *yes || ask(fmt.Sprintf("Instalar também os opcionais (%s)? [s/N] ", strings.Join(opt, " "))) {
			pk = append(pk, opt...)
		}
	}
	if len(pk) == 0 {
		fmt.Println("Nada a instalar.")
		return nil
	}
	if err := toolcheck.Install(pk, *yes); err != nil {
		return err
	}
	fmt.Println("\nPacotes instalados. Dicas pós-instalação:")
	fmt.Println("  • UFW:      sudo ufw enable && sudo ufw logging on")
	fmt.Println("  • auditd:   sudo systemctl enable --now auditd")
	fmt.Println("  • acct:     sudo systemctl enable --now acct")
	fmt.Println("  • fail2ban: sudo systemctl enable --now fail2ban")
	return nil
}

func ask(q string) bool {
	fmt.Print(q)
	r := bufio.NewReader(os.Stdin)
	l, _ := r.ReadString('\n')
	l = strings.ToLower(strings.TrimSpace(l))
	return l == "s" || l == "sim" || l == "y" || l == "yes"
}

func cmdSources(cfgPath string) error {
	if err := requireRoot(); err != nil {
		return err
	}
	cfg, err := loadConfig(cfgPath)
	if err != nil {
		return err
	}
	fmt.Printf("%-14s %-10s %-10s %s\n", "ID", "CATEGORIA", "STATUS", "DESCRIÇÃO / LEITURA")
	fmt.Println(strings.Repeat("-", 100))
	for _, c := range collectors.All(cfg) {
		status := "ok"
		p := c.Probe(cfg)
		if !cfg.SourceEnabled(c.ID()) {
			status = "desativada"
		} else if !p.Available {
			status = "ausente"
		}
		fmt.Printf("%-14s %-10s %-10s %s\n", c.ID(), c.Category(), status, c.Name())
		if p.Available && p.Mode != "" {
			fmt.Printf("%-36s → %s\n", "", p.Mode)
		}
		for _, n := range p.Notes {
			fmt.Printf("%-36s ! %s\n", "", n)
		}
	}
	return nil
}

// ---------------------------------------------------------------- relatório / histórico

func cmdReport(cfgPath string, args []string) error {
	fs := flag.NewFlagSet("relatorio", flag.ContinueOnError)
	list := fs.Bool("lista", false, "")
	pos, err := splitArgs(fs, args)
	if err != nil {
		return err
	}
	if err := requireRoot(); err != nil {
		return err
	}
	cfg, err := loadConfig(cfgPath)
	if err != nil {
		return err
	}
	if *list {
		files, _ := filepath.Glob(filepath.Join(cfg.DiretorioRelatorios, "relatorio_*.txt"))
		sort.Sort(sort.Reverse(sort.StringSlice(files)))
		for _, f := range files {
			st, _ := os.Stat(f)
			fmt.Printf("%s  %8s  %s\n", st.ModTime().Format("02/01/2006 15:04"), util.HumanBytes(st.Size()), f)
		}
		if len(files) == 0 {
			fmt.Println("Nenhum relatório ainda. Execute: sudo logcentralizer analisar")
		}
		return nil
	}
	p := filepath.Join(cfg.DiretorioRelatorios, "ultimo_relatorio.txt")
	if len(pos) > 0 {
		p = pos[0]
		if !util.Exists(p) {
			p = filepath.Join(cfg.DiretorioRelatorios, pos[0])
		}
	}
	data, err := os.ReadFile(p)
	if err != nil {
		return fmt.Errorf("relatório não encontrado (%v). Execute: sudo logcentralizer analisar", err)
	}
	os.Stdout.Write(data)
	return nil
}

func cmdHistory(cfgPath string, args []string) error {
	fs := flag.NewFlagSet("historico", flag.ContinueOnError)
	n := fs.Int("n", 0, "")
	if _, err := splitArgs(fs, args); err != nil {
		return err
	}
	if err := requireRoot(); err != nil {
		return err
	}
	cfg, err := loadConfig(cfgPath)
	if err != nil {
		return err
	}
	h, err := store.LoadHistory(cfg.DiretorioDados)
	if err != nil {
		return err
	}
	if len(h) == 0 {
		fmt.Println("Nenhuma análise registrada ainda.")
		return nil
	}
	k := *n
	if k <= 0 {
		k = cfg.Relatorio.AnalisesNoHistorico
	}
	if len(h) > k {
		h = h[len(h)-k:]
	}
	fmt.Printf("%-16s %-25s %9s %5s %5s %5s %6s  %s\n", "Data", "Período", "Eventos", "CRIT", "ALTA", "MÉD", "BAIXA", "Veredito")
	fmt.Println(strings.Repeat("-", 100))
	for _, x := range h {
		per := x.Since.Format("02/01 15:04") + "→" + x.Until.Format("02/01 15:04")
		fmt.Printf("%-16s %-25s %9d %5d %5d %5d %6d  %s\n", x.Time.Format("02/01/06 15:04"), per, x.Events,
			x.Severities["CRITICA"], x.Severities["ALTA"], x.Severities["MEDIA"], x.Severities["BAIXA"], x.Verdict)
		for _, t := range x.Top {
			fmt.Printf("%18s%s\n", "", util.Truncate(t, 80))
		}
	}
	return nil
}

// ---------------------------------------------------------------- backup

func cmdBackup(cfgPath string, args []string) error {
	if err := requireRoot(); err != nil {
		return err
	}
	cfg, err := loadConfig(cfgPath)
	if err != nil {
		return err
	}
	if len(args) == 0 {
		args = []string{"listar"}
	}
	switch args[0] {
	case "listar", "list":
		l := backup.List(cfg.Backup.Diretorio)
		if len(l) == 0 {
			fmt.Println("Nenhum backup em", cfg.Backup.Diretorio)
			return nil
		}
		var total int64
		for _, e := range l {
			total += e.Size
			fmt.Printf("%s  %9s  %s\n", e.ModTime.Format("02/01/2006 15:04"), util.HumanBytes(e.Size), e.Path)
		}
		pct, free := backup.FreePercent(cfg.Backup.Diretorio)
		fmt.Printf("\n%d backups, %s no total. Espaço livre no destino: %.1f%% (%s)\n", len(l), util.HumanBytes(total), pct, util.HumanBytes(free))
	case "verificar", "verify":
		bad := 0
		for _, r := range backup.Verify(cfg.Backup.Diretorio) {
			mark := "OK  "
			if !r.OK {
				mark = "FALHA"
				bad++
			}
			fmt.Printf("[%s] %s — %s\n", mark, filepath.Base(r.Path), r.Msg)
		}
		if bad > 0 {
			return fmt.Errorf("%d backup(s) com problema", bad)
		}
	case "criar", "create":
		now := time.Now()
		info, err := backup.Create(context.Background(), cfg, backup.Meta{Host: cfg.NomeHost, Verdict: "(backup manual, sem análise)"}, now)
		if err != nil {
			return err
		}
		fmt.Printf("Backup criado: %s (%s, %d arquivos)\nSHA-256: %s\n", info.Path, util.HumanBytes(info.Size), info.Files, info.SHA256)
	case "descriptografar", "decrypt":
		fs := flag.NewFlagSet("descriptografar", flag.ContinueOnError)
		out := fs.String("saida", "", "")
		pos, err := splitArgs(fs, args[1:])
		if err != nil {
			return err
		}
		if len(pos) == 0 {
			return errors.New("informe o arquivo .enc")
		}
		in := pos[0]
		o := *out
		if o == "" {
			o = strings.TrimSuffix(in, ".enc")
			if o == in {
				o = in + ".tar.gz"
			}
		}
		pass, err := backup.ReadPassphrase(cfg.Backup.Criptografia.ArquivoSenha)
		if err != nil {
			return err
		}
		if err := backup.Decrypt(in, o, pass); err != nil {
			os.Remove(o)
			return err
		}
		fmt.Println("Arquivo descriptografado:", o)
	default:
		return fmt.Errorf("subcomando de backup desconhecido: %s", args[0])
	}
	return nil
}

// ---------------------------------------------------------------- linha de base

func cmdBaseline(cfgPath string, args []string) error {
	if err := requireRoot(); err != nil {
		return err
	}
	cfg, err := loadConfig(cfgPath)
	if err != nil {
		return err
	}
	if len(args) == 0 {
		args = []string{"status"}
	}
	switch args[0] {
	case "status":
		b, err := store.LoadBaseline(cfg.DiretorioDados)
		if err != nil {
			return err
		}
		if b.Runs == 0 {
			fmt.Println("Linha de base vazia: será construída na primeira análise.")
			return nil
		}
		hours := len(b.CoveredHoursSince(time.Now().AddDate(0, 0, -cfg.LinhaDeBase.Dias)))
		fmt.Printf("Criada em ............: %s\n", b.Created.Format("02/01/2006 15:04"))
		fmt.Printf("Última análise .......: %s\n", b.LastRun.Format("02/01/2006 15:04"))
		fmt.Printf("Execuções ............: %d\n", b.Runs)
		fmt.Printf("Horas de atividade ...: %d (janela %d dias; mínimo %d)\n", hours, cfg.LinhaDeBase.Dias, cfg.LinhaDeBase.HorasMinimas)
		fmt.Printf("Modelos de erro ......: %d\n", len(b.Templates))
		fmt.Println("Entidades conhecidas:")
		var cats []string
		for k := range b.Entities {
			cats = append(cats, k)
		}
		sort.Strings(cats)
		for _, k := range cats {
			fmt.Printf("  %-16s %d\n", k, len(b.Entities[k]))
		}
		fmt.Println("Média de eventos por hora de atividade, por fonte:")
		keys := b.CoveredHoursSince(time.Now().AddDate(0, 0, -cfg.LinhaDeBase.Dias))
		var srcs []string
		for s := range b.Hours {
			srcs = append(srcs, s)
		}
		sort.Strings(srcs)
		for _, s := range srcs {
			var sum int
			for _, k := range keys {
				sum += b.Hours[s][k]
			}
			if len(keys) > 0 {
				fmt.Printf("  %-16s %.1f\n", s, float64(sum)/float64(len(keys)))
			}
		}
	case "resetar", "reset":
		p := filepath.Join(cfg.DiretorioDados, "linha_de_base.json")
		if !util.Exists(p) {
			fmt.Println("Não há linha de base para apagar.")
			return nil
		}
		if len(args) < 2 || args[1] != "-y" {
			if !ask("Apagar a linha de base? O aprendizado do comportamento habitual recomeçará. [s/N] ") {
				return nil
			}
		}
		bk := p + ".antiga_" + time.Now().Format("20060102_150405")
		if err := os.Rename(p, bk); err != nil {
			return err
		}
		fmt.Println("Linha de base apagada (cópia guardada em " + bk + ").")
	default:
		return fmt.Errorf("subcomando desconhecido: %s", args[0])
	}
	return nil
}

// ---------------------------------------------------------------- config

func cmdConfig(cfgPath string, args []string) error {
	if len(args) == 0 {
		args = []string{"mostrar"}
	}
	switch args[0] {
	case "init":
		if err := requireRoot(); err != nil {
			return err
		}
		force := len(args) > 1 && (args[1] == "--forcar" || args[1] == "--force")
		if util.Exists(cfgPath) && !force {
			return fmt.Errorf("%s já existe (use 'config init --forcar' para sobrescrever)", cfgPath)
		}
		if util.Exists(cfgPath) {
			_ = os.Rename(cfgPath, cfgPath+".bak_"+time.Now().Format("20060102_150405"))
		}
		c := config.Default()
		_ = c.Prepare()
		c.NomeHost = ""
		if err := c.Save(cfgPath); err != nil {
			return err
		}
		fmt.Println("Configuração criada em", cfgPath)
	case "mostrar", "show":
		if err := requireRoot(); err != nil {
			return err
		}
		c, err := loadConfig(cfgPath)
		if err != nil {
			return err
		}
		if c.BuscaWeb.BraveChaveAPI != "" {
			c.BuscaWeb.BraveChaveAPI = "****" + c.BuscaWeb.BraveChaveAPI[max(0, len(c.BuscaWeb.BraveChaveAPI)-4):]
		}
		tmp := filepath.Join(os.TempDir(), fmt.Sprintf("lcz_cfg_%d.json", os.Getpid()))
		if err := c.Save(tmp); err != nil {
			return err
		}
		data, _ := os.ReadFile(tmp)
		os.Remove(tmp)
		os.Stdout.Write(data)
	case "validar", "validate":
		if err := requireRoot(); err != nil {
			return err
		}
		if !util.Exists(cfgPath) {
			return fmt.Errorf("%s não existe (crie com: sudo logcentralizer config init)", cfgPath)
		}
		if _, err := loadConfig(cfgPath); err != nil {
			return err
		}
		fmt.Println("Configuração válida:", cfgPath)
	case "caminho", "path":
		fmt.Println(cfgPath)
	case "criptografia", "sensibilidade", "brave-chave":
		if err := requireRoot(); err != nil {
			return err
		}
		if !util.Exists(cfgPath) {
			return fmt.Errorf("%s não existe (crie com: sudo logcentralizer config init)", cfgPath)
		}
		c, err := loadConfig(cfgPath)
		if err != nil {
			return err
		}
		if len(args) < 2 {
			return fmt.Errorf("uso: config %s <valor>", args[0])
		}
		v := args[1]
		switch args[0] {
		case "criptografia":
			switch v {
			case "ativar":
				kf := c.Backup.Criptografia.ArquivoSenha
				if !util.Exists(kf) {
					b := make([]byte, 32)
					if _, err := rand.Read(b); err != nil {
						return err
					}
					if err := os.MkdirAll(filepath.Dir(kf), 0o700); err != nil {
						return err
					}
					if err := os.WriteFile(kf, []byte(base64.StdEncoding.EncodeToString(b)+"\n"), 0o600); err != nil {
						return err
					}
					fmt.Println("Senha aleatória criada em", kf)
				}
				c.Backup.Criptografia.Ativo = true
				fmt.Println("Criptografia dos backups ATIVADA (AES-256-GCM).")
				fmt.Println("IMPORTANTE: guarde uma cópia de", kf, "fora desta máquina; sem ela os backups não podem ser abertos.")
			case "desativar":
				c.Backup.Criptografia.Ativo = false
				fmt.Println("Criptografia dos backups desativada (backups antigos continuam criptografados).")
			default:
				return errors.New("use: config criptografia ativar|desativar")
			}
		case "sensibilidade":
			switch v {
			case "baixa", "media", "alta":
				c.Deteccao.Sensibilidade = v
				fmt.Println("Sensibilidade definida como", v)
			default:
				return errors.New("use: config sensibilidade baixa|media|alta")
			}
		case "brave-chave":
			if v == "remover" {
				c.BuscaWeb.BraveChaveAPI = ""
				fmt.Println("Chave da Brave Search removida (será usado o DuckDuckGo).")
			} else {
				c.BuscaWeb.BraveChaveAPI = strings.TrimSpace(v)
				if !config.Contains(c.BuscaWeb.Provedores, "brave") {
					c.BuscaWeb.Provedores = append([]string{"brave"}, c.BuscaWeb.Provedores...)
				}
				fmt.Println("Chave da Brave Search gravada. Ela será usada antes do DuckDuckGo.")
			}
		}
		if err := c.Save(cfgPath); err != nil {
			return err
		}
	default:
		return fmt.Errorf("subcomando de config desconhecido: %s", args[0])
	}
	return nil
}
