package collectors

import (
	"testing"
	"time"

	"logcentralizer/internal/model"
	"logcentralizer/internal/util"
)

func ev(prog, msg string) *model.Event { return &model.Event{Program: prog, Message: msg, Level: -1} }

func TestParseAuth(t *testing.T) {
	cases := []struct {
		prog, msg, kind, user, ip string
	}{
		{"sshd", "Failed password for invalid user admin from 203.0.113.9 port 4242 ssh2", "ssh_fail", "admin", "203.0.113.9"},
		{"sshd", "Failed password for root from 10.0.0.5 port 1 ssh2", "ssh_fail", "root", "10.0.0.5"},
		{"sshd", "Invalid user oracle from 198.51.100.4 port 5555", "ssh_fail", "oracle", "198.51.100.4"},
		{"sshd", "Accepted publickey for joao from 192.168.1.50 port 5123 ssh2: ED25519 SHA256:x", "ssh_ok", "joao", "192.168.1.50"},
		{"sshd", "Connection closed by authenticating user root 1.2.3.4 port 22 [preauth]", "ssh_fail", "root", "1.2.3.4"},
		{"sudo", "    joao : TTY=pts/0 ; PWD=/home/joao ; USER=root ; COMMAND=/usr/bin/apt install vim", "sudo", "joao", ""},
		{"sudo", "joao : 3 incorrect password attempts ; TTY=pts/0 ; PWD=/home/joao ; USER=root ; COMMAND=/bin/ls", "sudo_fail", "joao", ""},
		{"sudo", "  maria : user NOT in sudoers ; TTY=pts/1 ; PWD=/ ; USER=root ; COMMAND=/bin/sh", "sudo_denied", "maria", ""},
		{"useradd", "new user: name=evil, UID=0, GID=0, home=/root, shell=/bin/bash", "user_add", "evil", ""},
		{"usermod", "add 'ana' to group 'sudo'", "user_mod", "ana", ""},
		{"passwd", "pam_unix(passwd:chauthtok): password changed for joao", "passwd_change", "joao", ""},
		{"gdm-password]", "pam_unix(gdm-password:session): session opened for user joao(uid=1000) by joao(uid=0)", "session_open", "joao", ""},
		{"gdm-password]", "pam_unix(gdm-password:auth): authentication failure; logname=joao uid=0 euid=0 tty=/dev/tty1 ruser= rhost=  user=joao", "local_fail", "joao", ""},
		{"su", "pam_unix(su-l:session): session opened for user root(uid=0) by joao(uid=1000)", "su", "joao", ""},
	}
	for _, c := range cases {
		e := ev(c.prog, c.msg)
		parseAuth(e)
		if e.Kind != c.kind || e.Get("user") != c.user || e.Get("ip") != c.ip {
			t.Errorf("%q: kind=%q user=%q ip=%q; esperado %q %q %q", c.msg, e.Kind, e.Get("user"), e.Get("ip"), c.kind, c.user, c.ip)
		}
	}
	e := ev("sudo", "    joao : TTY=pts/0 ; PWD=/home/joao ; USER=root ; COMMAND=/usr/bin/apt install vim")
	parseAuth(e)
	if e.Get("cmd") != "/usr/bin/apt install vim" {
		t.Errorf("cmd = %q", e.Get("cmd"))
	}
}

func TestParseKernel(t *testing.T) {
	cases := map[string]string{
		"Out of memory: Killed process 1234 (firefox) total-vm:1kB":                      "oom",
		"[ 12.3] chrome[999]: segfault at 0 ip 0000 sp 0000 error 4 in libc.so.6":        "segfault",
		"EXT4-fs error (device nvme0n1p2): ext4_lookup:1855: inode #1: comm x: bad":      "disk_error",
		"blk_update_request: I/O error, dev sda, sector 123":                             "disk_error",
		"mce: [Hardware Error]: Machine check events logged":                             "hw_error",
		"INFO: task kworker/0:1:12 blocked for more than 120 seconds.":                   "kernel_bug",
		"usb 1-2: New USB device found, idVendor=046d, idProduct=c52b, bcdDevice=12.11":  "usb_new",
		"pcieport 0000:00:1c.0: AER: Corrected error message received from 0000:02:00.0": "hw_error",
		"wlp2s0: associated": "",
	}
	for msg, kind := range cases {
		e := ev("kernel", msg)
		parseKernel(e)
		if e.Kind != kind {
			t.Errorf("%q: kind=%q esperado %q", msg, e.Kind, kind)
		}
	}
}

func TestParseSystemd(t *testing.T) {
	e := ev("systemd", "nginx.service: Failed with result 'exit-code'.")
	parseSystemd(e)
	if e.Kind != "unit_failed" || e.Get("unit") != "nginx.service" {
		t.Fatalf("got %q %q", e.Kind, e.Get("unit"))
	}
	e = ev("systemd", "app.service: Scheduled restart job, restart counter is at 12.")
	parseSystemd(e)
	if e.Kind != "unit_restart" || e.Get("counter") != "12" {
		t.Fatalf("got %q %q", e.Kind, e.Get("counter"))
	}
	e = ev("systemd-coredump", "Process 4242 (gedit) of user 1000 dumped core.")
	parseSystemd(e)
	if e.Kind != "core_dump" || e.Get("proc") != "gedit" {
		t.Fatalf("got %q %q", e.Kind, e.Get("proc"))
	}
}

func TestUFWAndAppArmor(t *testing.T) {
	e := ev("kernel", "[UFW BLOCK] IN=eth0 OUT= MAC=00 SRC=45.33.32.156 DST=10.0.0.2 LEN=44 TOS=0x00 PREC=0x00 TTL=50 ID=1 PROTO=TCP SPT=61000 DPT=8080 WINDOW=1024 RES=0x00 SYN URGP=0")
	if !parseUFW(e) || e.Kind != "fw_block" || e.Get("src") != "45.33.32.156" || e.Get("dpt") != "8080" {
		t.Fatalf("ufw: %+v", e.F)
	}
	a := ev("kernel", `audit: type=1400 audit(1.2:3): apparmor="DENIED" operation="open" class="file" profile="snap.firefox.firefox" name="/etc/shadow" pid=1 comm="firefox" requested_mask="r"`)
	if !parseAppArmor(a) || a.Get("profile") != "snap.firefox.firefox" || a.Get("op") != "open" || a.Get("name") != "/etc/shadow" {
		t.Fatalf("apparmor: %+v", a.F)
	}
}

func TestSyslogFormats(t *testing.T) {
	now := time.Date(2026, 11, 5, 3, 0, 0, 0, time.Local)
	s, ok := util.ParseSyslog("2026-11-05T02:10:11.123456-03:00 desktop sshd[123]: Accepted password for x from 1.1.1.1 port 1 ssh2", now)
	if !ok || s.Program != "sshd" || s.PID != "123" || s.Host != "desktop" {
		t.Fatalf("iso: %+v", s)
	}
	s, ok = util.ParseSyslog("Nov  5 02:10:11 desktop kernel: [  1.0] hello", now)
	if !ok || s.Program != "kernel" || s.Time.Day() != 5 || s.Time.Hour() != 2 {
		t.Fatalf("bsd: %+v", s)
	}
	// virada de ano: dezembro visto em janeiro
	s, _ = util.ParseSyslog("Dec 31 23:59:59 h cron[1]: x", time.Date(2027, 1, 1, 0, 5, 0, 0, time.Local))
	if s.Time.Year() != 2026 {
		t.Fatalf("ano = %d", s.Time.Year())
	}
}

func TestDecodeAddr(t *testing.T) {
	if a, p := decodeAddr("0100007F:0277"); a != "127.0.0.1" || p != 631 {
		t.Fatalf("%s %d", a, p)
	}
	if a, p := decodeAddr("00000000000000000000000000000000:0016"); a != "::" || p != 22 {
		t.Fatalf("%s %d", a, p)
	}
	if a, _ := decodeAddr("00000000000000000000000001000000:0016"); a != "::1" {
		t.Fatalf("%s", a)
	}
}

func TestJournalMessageBytes(t *testing.T) {
	if s := decodeJournalMessage([]byte(`[104,105]`)); s != "hi" {
		t.Fatal(s)
	}
	if s := decodeJournalMessage([]byte(`"ola"`)); s != "ola" {
		t.Fatal(s)
	}
}
