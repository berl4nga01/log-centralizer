package solutions

import (
	"testing"

	"logcentralizer/internal/model"
)

const ddgHTML = `<div class="result results_links results_links_deep web-result ">
<div class="links_main links_deep result__body">
<h2 class="result__title">
<a rel="nofollow" class="result__a" href="//duckduckgo.com/l/?uddg=https%3A%2F%2Faskubuntu.com%2Fquestions%2F123%2Fssh&amp;rut=abc">How to stop <b>SSH</b> brute force</a>
</h2>
<a class="result__snippet" href="//duckduckgo.com/l/?uddg=x">Use <b>fail2ban</b> and disable password logins.</a>
</div></div>
<div class="result results_links results_links_deep web-result ">
<a rel="nofollow" class="result__a" href="https://wiki.archlinux.org/title/Fail2ban">Fail2ban - ArchWiki</a>
<a class="result__snippet" href="https://wiki.archlinux.org/title/Fail2ban">Fail2ban scans log files.</a>
</div>`

const liteHTML = `<table><tr><td>1.&nbsp;</td><td><a rel="nofollow" href="https://help.ubuntu.com/community/UFW" class='result-link'>UFW - Community Help Wiki</a></td></tr>
<tr><td>&nbsp;</td><td class='result-snippet'>Uncomplicated <b>Firewall</b> ...</td></tr></table>`

func TestParseDDG(t *testing.T) {
	r := ParseDDG(ddgHTML, 5)
	if len(r) != 2 {
		t.Fatalf("esperado 2 resultados, veio %d: %+v", len(r), r)
	}
	if r[0].URL != "https://askubuntu.com/questions/123/ssh" || r[0].Title != "How to stop SSH brute force" || r[0].Snippet == "" {
		t.Fatalf("resultado 0 incorreto: %+v", r[0])
	}
	l := ParseDDG(liteHTML, 5)
	if len(l) != 1 || l[0].URL != "https://help.ubuntu.com/community/UFW" || l[0].Snippet != "Uncomplicated Firewall ..." {
		t.Fatalf("lite incorreto: %+v", l)
	}
}

func TestBuildQuery(t *testing.T) {
	a := &model.Anomaly{Rule: "servico_falhou", Entity: "nginx.service"}
	_, q, _ := Lookup(a.Rule)
	if got := buildQuery(a, q); got != "ubuntu systemd service failed how to fix nginx.service" {
		t.Fatal(got)
	}
	k := &model.Anomaly{Rule: "kernel_erro", Entity: "BUG: soft lockup - CPU#<n> stuck"}
	_, q, _ = Lookup(k.Rule)
	if got := buildQuery(k, q); got == "" || containsAny(got, "<", ">") {
		t.Fatal(got)
	}
}

func containsAny(s string, chars ...string) bool {
	for _, c := range chars {
		for i := range s {
			if s[i:i+1] == c {
				return true
			}
		}
	}
	return false
}

func TestKBCoversRules(t *testing.T) {
	// regras emitidas pelo analisador que precisam ter solução local
	rules := []string{"volume_pico", "fonte_silenciosa", "log_truncado", "log_removido", "erro_novo",
		"ssh_forca_bruta", "ssh_sucesso_apos_forca_bruta", "ssh_login_root", "login_fora_horario",
		"login_novo_usuario", "login_novo_ip", "login_falhas_repetidas", "sudo_novo_usuario",
		"sudo_novo_comando", "comando_suspeito", "sudo_falhas", "sudo_nao_autorizado", "su_falhas",
		"su_novo", "usuario_criado", "grupo_criado", "usuario_privilegio", "usuario_modificado",
		"usuario_removido", "senha_alterada", "usuario_uid0", "conta_sistema_login", "servico_falhou",
		"servico_reinicio_loop", "core_dump", "crash_aplicacao", "oom", "segfault", "kernel_erro",
		"hardware_erro", "disco_io_erro", "usb_novo_dispositivo", "firewall_varredura", "firewall_inativo",
		"fail2ban_banimento", "apparmor_negacao", "auditd_anomalia", "auditd_falhas",
		"auditd_config_alterada", "auditd_chave", "cron_novo_comando", "cron_novo_arquivo",
		"cron_arquivo_alterado", "timer_novo", "pacote_fora_janela", "pacote_suspeito",
		"pacote_seguranca_removido", "web_404_ip", "web_5xx", "web_scanner", "docker_container_falhou",
		"docker_oom", "docker_reinicios", "docker_imagem_nova", "db_falhas_autenticacao",
		"db_falha_critica", "processo_sem_arquivo", "processo_local_suspeito", "processo_binario_apagado",
		"processo_cpu_alta", "processo_memoria_alta", "processo_root_novo", "processos_zumbis",
		"porta_nova", "integridade_arquivo_novo", "integridade_arquivo_alterado", "chave_ssh_alterada",
		"ld_preload", "temperatura_alta", "smart_falha", "smart_desgaste", "smart_setores",
		"memoria_ecc_erro", "bateria_degradada", "disco_cheio", "inodes_cheio", "memoria_baixa",
		"swap_alto", "carga_alta"}
	for _, r := range rules {
		if _, _, ok := Lookup(r); !ok {
			t.Errorf("regra sem solução local: %s", r)
		}
	}
}
