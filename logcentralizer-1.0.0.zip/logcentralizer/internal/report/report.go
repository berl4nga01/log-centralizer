// Package report gera o relatório em texto (TXT, em português) de cada análise.
package report

import (
	"fmt"
	"os"
	"path/filepath"
	"sort"
	"strings"
	"time"

	"logcentralizer/internal/analyzer"
	"logcentralizer/internal/backup"
	"logcentralizer/internal/config"
	"logcentralizer/internal/model"
	"logcentralizer/internal/store"
	"logcentralizer/internal/toolcheck"
	"logcentralizer/internal/util"
)

// Input reúne tudo o que o relatório precisa.
type Input struct {
	Cfg        *config.Config
	Res        *analyzer.Result
	History    []store.HistoryEntry // já incluindo a execução atual
	Backup     *backup.Info
	BackupErr  string
	Tools      []toolcheck.SourceState
	WebUsed    int
	WebEnabled bool
	WebErrors  []string
	Version    string
}

type writer struct {
	b strings.Builder
	w int
}

func (w *writer) line(s string)             { w.b.WriteString(s + "\n") }
func (w *writer) f(format string, a ...any) { w.line(fmt.Sprintf(format, a...)) }
func (w *writer) blank()                    { w.b.WriteString("\n") }
func (w *writer) rule(ch string)            { w.line(strings.Repeat(ch, w.w)) }
func (w *writer) title(s string)            { w.blank(); w.rule("="); w.line(" " + s); w.rule("=") }
func (w *writer) sub(s string)              { w.blank(); w.line(s); w.line(strings.Repeat("-", len([]rune(s)))) }

// wrap quebra texto em linhas com recuo.
func (w *writer) wrap(prefix, text string) {
	width := w.w - len([]rune(prefix))
	if width < 30 {
		width = 30
	}
	first := true
	for _, para := range strings.Split(text, "\n") {
		words := strings.Fields(para)
		cur := ""
		for _, word := range words {
			if len([]rune(cur))+len([]rune(word))+1 > width && cur != "" {
				w.emitWrapped(prefix, cur, &first)
				cur = word
			} else if cur == "" {
				cur = word
			} else {
				cur += " " + word
			}
		}
		if cur != "" {
			w.emitWrapped(prefix, cur, &first)
		}
	}
}

func (w *writer) emitWrapped(prefix, s string, first *bool) {
	if *first {
		w.line(prefix + s)
		*first = false
		return
	}
	w.line(strings.Repeat(" ", len([]rune(prefix))) + s)
}

func dur(d time.Duration) string {
	if d < time.Second {
		return d.Round(time.Millisecond).String()
	}
	return d.Round(time.Second).String()
}

func ts(t time.Time) string {
	if t.IsZero() {
		return "-"
	}
	return t.Format("02/01/2006 15:04:05")
}

// Render gera o texto do relatório.
func Render(in Input) string {
	cfg, r := in.Cfg, in.Res
	w := &writer{w: cfg.Relatorio.LarguraLinha}
	w.rule("#")
	w.line(" LOGCENTRALIZER — RELATÓRIO DE ANÁLISE DE LOGS")
	w.rule("#")
	w.f(" Host ................: %s", r.Host)
	w.f(" Gerado em ...........: %s", ts(r.Start))
	w.f(" Período analisado ...: %s  →  %s", ts(r.Since), ts(r.Until))
	w.f(" Duração da análise ..: %s", dur(r.Duration))
	w.f(" Sensibilidade .......: %s (z-score %.1f, mínimo %d eventos, fator %.1fx)", r.Sensitivity, r.SensParams.ZScore, r.SensParams.MinimoEventos, r.SensParams.FatorMultiplicador)
	w.f(" Linha de base .......: %d horas de atividade nos últimos %d dias (mínimo para comparação: %d)", r.BaseHoursAfter, cfg.LinhaDeBase.Dias, r.MinHours)
	w.f(" Versão ..............: logcentralizer %s", in.Version)

	// ------------------------------------------------------------------ 1. veredito
	sc := r.SeverityCounts()
	w.title("1. VEREDITO")
	w.blank()
	w.f("   >>> %s <<<", r.Verdict)
	w.blank()
	w.f("   Anomalias: CRÍTICA %d | ALTA %d | MÉDIA %d | BAIXA %d | INFO %d",
		sc["CRITICA"], sc["ALTA"], sc["MEDIA"], sc["BAIXA"], sc["INFO"])
	w.f("   Eventos analisados: %d em %d horas de atividade", r.TotalEvents, r.CurrentHours)
	if r.Bootstrap {
		w.blank()
		w.wrap("   ", fmt.Sprintf("Primeira execução: a linha de base foi construída a partir de %d eventos históricos (desde %s).",
			r.BootstrapEvents, ts(r.BootstrapSince)))
	}
	if r.Learning {
		w.blank()
		w.wrap("   ! ", fmt.Sprintf("MODO APRENDIZADO: a linha de base ainda tem %d de %d horas mínimas. Nesta análise as regras de "+
			"novidade (IP/usuário/porta/erro nunca vistos) e de pico de volume ficam desligadas; valem apenas as regras de "+
			"limite e assinatura (força bruta, OOM, disco cheio, erros de hardware, etc.). Execute novamente nos próximos dias.",
			r.BaseHoursBefore, r.MinHours))
	}
	w.blank()
	w.wrap("   Como ler: ", "NORMAL = nada fora do habitual; ATENÇÃO = há anomalias de severidade média para conferir; "+
		"ANORMAL = há anomalias altas/críticas que devem ser tratadas agora. Cada anomalia abaixo traz o motivo "+
		"(comparação com a linha de base), evidências e soluções sugeridas.")

	// ------------------------------------------------------------------ 2. anomalias
	var shown []*model.Anomaly
	hidden := 0
	for _, a := range r.Anomalies {
		if a.Severity == model.Info && !cfg.Relatorio.MostrarInfo {
			hidden++
			continue
		}
		shown = append(shown, a)
	}
	w.title(fmt.Sprintf("2. ANOMALIAS DETECTADAS (%d)", len(shown)))
	if len(shown) == 0 {
		w.blank()
		w.line("   Nenhuma anomalia relevante neste período. O comportamento está dentro do padrão habitual.")
	}
	max := cfg.Relatorio.MaxAnomaliasDetalhadas
	for i, a := range shown {
		if max > 0 && i >= max {
			w.blank()
			w.f("   ... e mais %d anomalias (resumo):", len(shown)-max)
			for _, b := range shown[max:] {
				w.f("     [%s] %s (%dx)", b.Severity, util.Truncate(b.Title, w.w-20), b.Count)
			}
			break
		}
		w.blank()
		w.rule("-")
		w.wrap(fmt.Sprintf(" #%d [%s] ", i+1, a.Severity), a.Title)
		w.rule("-")
		w.f("   Regra ..........: %s", a.Rule)
		w.f("   Fonte(s) .......: %s", strings.Join(a.Sources, ", "))
		if !a.First.IsZero() {
			if a.First.Equal(a.Last) {
				w.f("   Quando .........: %s", ts(a.First))
			} else {
				w.f("   Quando .........: %s  →  %s", ts(a.First), ts(a.Last))
			}
		}
		w.f("   Ocorrências ....: %d", a.Count)
		w.wrap("   Por que é anomalia: ", a.Description)
		if len(a.Evidence) > 0 {
			w.line("   Evidências:")
			for _, e := range a.Evidence {
				w.wrap("     > ", e)
			}
		}
		if a.Solution != nil {
			w.wrap("   Solução sugerida: ", a.Solution.Title+" — "+a.Solution.Explanation)
			for j, s := range a.Solution.Steps {
				w.wrap(fmt.Sprintf("     %d. ", j+1), s)
			}
			if len(a.Solution.References) > 0 {
				w.line("   Referências:")
				for _, ref := range a.Solution.References {
					w.line("     - " + ref)
				}
			}
		}
		if len(a.Web) > 0 {
			w.wrap("   Pesquisa na internet (", a.WebQuery+"):")
			for _, s := range a.Web {
				w.wrap("     • ", s.Title+" ["+s.Engine+"]")
				w.line("       " + s.URL)
				if s.Snippet != "" {
					w.wrap("       ", util.Truncate(s.Snippet, 220))
				}
			}
		} else if a.WebError != "" {
			w.wrap("   Pesquisa na internet: ", "não realizada — "+a.WebError)
		}
	}
	if hidden > 0 {
		w.blank()
		w.f("   (%d observações de nível INFO ocultas; ative relatorio.mostrar_info para exibi-las)", hidden)
	}

	// ------------------------------------------------------------------ 3. fontes
	w.title("3. FONTES MONITORADAS (atual × habitual)")
	w.blank()
	w.f("   %s %s %s %s %s %s", util.Pad("Fonte", 14), util.Pad("Status", 10), util.PadLeft("Eventos", 9), util.PadLeft("Atual/h", 9), util.PadLeft("Hábito/h", 9), util.PadLeft("Variação", 9))
	w.f("   %s", strings.Repeat("-", 65))
	for _, s := range r.Sources {
		status := "ok"
		switch {
		case !s.Enabled:
			status = "desativ."
		case !s.Available:
			status = "ausente"
		case s.Error != "":
			status = "ERRO"
		}
		cur, hab, varr := "-", "-", "-"
		if s.Available && s.Enabled && !s.Snapshot {
			cur = fmt.Sprintf("%.1f", s.CurPerHour)
			if s.BaseHours > 0 {
				hab = fmt.Sprintf("%.1f", s.BaseMeanPerHour)
				if s.BaseMeanPerHour > 0 {
					varr = fmt.Sprintf("%+.0f%%", (s.CurPerHour/s.BaseMeanPerHour-1)*100)
				} else if s.CurPerHour > 0 {
					varr = "novo"
				}
			}
		}
		ev := "-"
		if s.Available && s.Enabled {
			ev = fmt.Sprint(s.Events)
			if s.Snapshot {
				cur = "foto"
			}
		}
		w.f("   %s %s %s %s %s %s", util.Pad(s.ID, 14), util.Pad(status, 10), util.PadLeft(ev, 9), util.PadLeft(cur, 9), util.PadLeft(hab, 9), util.PadLeft(varr, 9))
	}
	w.blank()
	w.line("   Detalhes de leitura:")
	for _, s := range r.Sources {
		if !s.Enabled {
			continue
		}
		if s.Available {
			w.wrap("   • "+s.ID+": ", s.Mode+fmt.Sprintf(" (%s)", dur(s.Duration)))
		} else {
			w.wrap("   • "+s.ID+": ", "indisponível — "+strings.Join(s.Notes, "; "))
			continue
		}
		if s.Error != "" {
			w.wrap("       erro: ", s.Error)
		}
		for _, n := range s.Notes {
			w.wrap("       obs: ", n)
		}
		if s.Ignored > 0 {
			w.f("       %d eventos ignorados pela lista branca", s.Ignored)
		}
	}

	// ------------------------------------------------------------------ 4. estado atual
	if len(r.Snapshot) > 0 {
		w.title("4. ESTADO ATUAL DA MÁQUINA (fotografia)")
		w.blank()
		for _, s := range r.Snapshot {
			w.wrap("   • ", s)
		}
	}

	// ------------------------------------------------------------------ 5. ferramentas
	w.title("5. FERRAMENTAS DE MONITORAMENTO")
	rec, opt := toolcheck.MissingPackages(in.Tools)
	w.blank()
	if len(rec) == 0 && len(opt) == 0 {
		w.line("   Todas as ferramentas recomendadas estão instaladas.")
	} else {
		if len(rec) > 0 {
			w.wrap("   Recomendado instalar: ", "sudo apt install "+strings.Join(rec, " "))
		}
		if len(opt) > 0 {
			w.wrap("   Opcional: ", "sudo apt install "+strings.Join(opt, " "))
		}
		w.line("   (ou: sudo logcentralizer verificar --instalar)")
	}
	if in.WebEnabled {
		w.f("   Pesquisa web: %d consulta(s) realizada(s); provedores: %s", in.WebUsed, strings.Join(cfg.BuscaWeb.Provedores, ", "))
		if cfg.BuscaWeb.BraveChaveAPI == "" && config.Contains(cfg.BuscaWeb.Provedores, "brave") {
			w.line("   (Brave Search sem chave configurada: usando DuckDuckGo)")
		}
	} else {
		w.line("   Pesquisa web: desativada nesta execução (somente base local de soluções)")
	}

	// ------------------------------------------------------------------ 6. histórico
	n := cfg.Relatorio.AnalisesNoHistorico
	hist := in.History
	if len(hist) > n {
		hist = hist[len(hist)-n:]
	}
	w.title(fmt.Sprintf("6. HISTÓRICO DAS ÚLTIMAS %d ANÁLISES", len(hist)))
	w.blank()
	w.f("   %s %s %s %s %s %s %s %s", util.Pad("Data", 16), util.PadLeft("Eventos", 9), util.PadLeft("CRIT", 5), util.PadLeft("ALTA", 5), util.PadLeft("MÉD", 5), util.PadLeft("BAIXA", 6), "  ", "Veredito")
	w.f("   %s", strings.Repeat("-", 75))
	for _, h := range hist {
		mark := " "
		if h.Learning {
			mark = "*"
		}
		w.f("   %s %s %s %s %s %s %s %s", util.Pad(h.Time.Format("02/01/06 15:04"), 16), util.PadLeft(fmt.Sprint(h.Events), 9),
			util.PadLeft(fmt.Sprint(h.Severities["CRITICA"]), 5), util.PadLeft(fmt.Sprint(h.Severities["ALTA"]), 5),
			util.PadLeft(fmt.Sprint(h.Severities["MEDIA"]), 5), util.PadLeft(fmt.Sprint(h.Severities["BAIXA"]), 6), mark+" ", h.Verdict)
	}
	w.line("   (* = análise em modo aprendizado)")
	w.blank()
	for _, l := range trend(hist) {
		w.wrap("   ", l)
	}
	if len(hist) > 1 {
		w.blank()
		w.line("   Anomalias recorrentes no histórico (aparecem em mais de uma análise):")
		rec := recurring(hist)
		if len(rec) == 0 {
			w.line("     nenhuma")
		}
		for _, x := range rec {
			w.wrap("     • ", x)
		}
	}

	// ------------------------------------------------------------------ 7. backup
	w.title("7. BACKUP DOS LOGS")
	w.blank()
	switch {
	case in.Backup != nil:
		b := in.Backup
		w.f("   Arquivo .....: %s", b.Path)
		w.f("   Tamanho .....: %s (%d arquivos de log copiados)", util.HumanBytes(b.Size), b.Files)
		w.f("   SHA-256 .....: %s", b.SHA256)
		w.f("   Criptografado: %v", map[bool]string{true: "sim (AES-256-GCM)", false: "não"}[b.Encrypted])
		if b.Journal != "" {
			w.f("   Journal .....: %s", b.Journal)
		}
		w.f("   Duração .....: %s", dur(b.Duration))
		if cfg.Backup.RetencaoDias == 0 && cfg.Backup.MaxBackups == 0 {
			w.line("   Retenção ....: manter sempre (cada backup é uma recapitulação geral de todos os logs)")
		} else {
			w.f("   Retenção ....: %d dias / máximo %d backups (0 = sem limite)", cfg.Backup.RetencaoDias, cfg.Backup.MaxBackups)
		}
		if len(b.Removed) > 0 {
			w.f("   Removidos pela retenção: %s", strings.Join(b.Removed, ", "))
		}
		if len(b.Skipped) > 0 {
			w.f("   Ignorados (%d):", len(b.Skipped))
			for i, s := range b.Skipped {
				if i >= 10 {
					w.f("     ... e mais %d", len(b.Skipped)-10)
					break
				}
				w.wrap("     - ", s)
			}
		}
		if pct, free := backup.FreePercent(cfg.Backup.Diretorio); pct < 25 {
			w.wrap("   ! ", fmt.Sprintf("Espaço livre no destino dos backups: %.1f%% (%s). Considere mover os backups antigos.", pct, util.HumanBytes(free)))
		}
	case in.BackupErr != "":
		w.wrap("   ", "Backup NÃO realizado: "+in.BackupErr)
	default:
		w.line("   Backup desativado nesta execução.")
	}

	// ------------------------------------------------------------------ 8. linha de base
	w.title("8. LINHA DE BASE (o que é considerado habitual)")
	w.blank()
	w.f("   Execuções registradas: %d", r.Runs)
	w.f("   Horas de atividade conhecidas: %d (janela de %d dias)", r.BaseHoursAfter, cfg.LinhaDeBase.Dias)
	w.f("   Modelos de mensagens de erro conhecidos: %d", r.Templates)
	var cats []string
	for k := range r.EntityCounts {
		cats = append(cats, k)
	}
	sort.Strings(cats)
	var parts []string
	for _, k := range cats {
		parts = append(parts, fmt.Sprintf("%s=%d", k, r.EntityCounts[k]))
	}
	w.wrap("   Entidades conhecidas: ", strings.Join(parts, ", "))
	w.f("   Horário de login habitual: %s", cfg.Deteccao.HorarioLogin.Describe())
	w.f("   Janela de manutenção de pacotes: %s", cfg.Deteccao.JanelaManutencaoPacotes.Describe())
	w.blank()
	w.rule("#")
	w.line(" Fim do relatório. Configuração: /etc/logcentralizer/config.json | Ajuda: logcentralizer ajuda")
	w.rule("#")
	return w.b.String()
}

func trend(h []store.HistoryEntry) []string {
	if len(h) < 2 {
		return []string{"Tendência: ainda não há análises anteriores suficientes para comparar."}
	}
	cur, prev := h[len(h)-1], h[:len(h)-1]
	var avgEv float64
	var avgAn float64
	for _, x := range prev {
		avgEv += float64(x.Events)
		avgAn += float64(x.Severities["CRITICA"] + x.Severities["ALTA"] + x.Severities["MEDIA"])
	}
	avgEv /= float64(len(prev))
	avgAn /= float64(len(prev))
	curAn := float64(cur.Severities["CRITICA"] + cur.Severities["ALTA"] + cur.Severities["MEDIA"])
	var out []string
	if avgEv > 0 {
		out = append(out, fmt.Sprintf("Tendência de volume: esta análise teve %d eventos; média das anteriores %.0f (%+.0f%%). "+
			"Observação: períodos analisados podem ter durações diferentes.", cur.Events, avgEv, (float64(cur.Events)/avgEv-1)*100))
	}
	switch {
	case curAn > avgAn*1.5 && curAn-avgAn >= 2:
		out = append(out, fmt.Sprintf("Tendência de anomalias (média+): PIOROU — %.0f nesta análise contra média de %.1f.", curAn, avgAn))
	case curAn < avgAn*0.5 && avgAn-curAn >= 2:
		out = append(out, fmt.Sprintf("Tendência de anomalias (média+): MELHOROU — %.0f nesta análise contra média de %.1f.", curAn, avgAn))
	default:
		out = append(out, fmt.Sprintf("Tendência de anomalias (média+): ESTÁVEL — %.0f nesta análise, média de %.1f.", curAn, avgAn))
	}
	return out
}

func recurring(h []store.HistoryEntry) []string {
	cnt := map[string]int{}
	for _, x := range h {
		seen := map[string]bool{}
		for _, t := range x.Top {
			if !seen[t] {
				cnt[t]++
				seen[t] = true
			}
		}
	}
	type kv struct {
		k string
		v int
	}
	var l []kv
	for k, v := range cnt {
		if v > 1 {
			l = append(l, kv{k, v})
		}
	}
	sort.Slice(l, func(i, j int) bool {
		if l[i].v != l[j].v {
			return l[i].v > l[j].v
		}
		return l[i].k < l[j].k
	})
	var out []string
	for i, x := range l {
		if i >= 10 {
			break
		}
		out = append(out, fmt.Sprintf("%s — em %d de %d análises", x.k, x.v, len(h)))
	}
	return out
}

// Save grava o relatório e devolve o caminho.
func Save(dir string, now time.Time, text string) (string, error) {
	if err := os.MkdirAll(dir, 0o750); err != nil {
		return "", err
	}
	p := UniquePath(filepath.Join(dir, "relatorio_"+now.Format("20060102_150405")+".txt"))
	if err := os.WriteFile(p, []byte(text), 0o640); err != nil {
		return "", err
	}
	latest := filepath.Join(dir, "ultimo_relatorio.txt")
	os.Remove(latest)
	_ = os.Symlink(filepath.Base(p), latest)
	return p, nil
}

// Prune remove relatórios antigos (retencao_relatorios_dias > 0).
func Prune(dir string, days int, now time.Time) {
	if days <= 0 {
		return
	}
	files, _ := filepath.Glob(filepath.Join(dir, "relatorio_*.txt"))
	for _, f := range files {
		if st, err := os.Stat(f); err == nil && now.Sub(st.ModTime()) > time.Duration(days)*24*time.Hour {
			os.Remove(f)
		}
	}
}

// HistoryTop devolve as principais anomalias (títulos genéricos por regra+entidade).
func HistoryTop(list []*model.Anomaly) []string {
	var out []string
	for _, a := range list {
		if a.Severity < model.Medium {
			continue
		}
		out = append(out, "["+a.Severity.String()+"] "+util.Truncate(a.Title, 90))
		if len(out) >= 15 {
			break
		}
	}
	return out
}

// UniquePath acrescenta um sufixo se o arquivo já existir.
func UniquePath(p string) string {
	if !util.Exists(p) {
		return p
	}
	ext := filepath.Ext(p)
	b := strings.TrimSuffix(p, ext)
	for i := 2; ; i++ {
		c := fmt.Sprintf("%s_%d%s", b, i, ext)
		if !util.Exists(c) {
			return c
		}
	}
}
