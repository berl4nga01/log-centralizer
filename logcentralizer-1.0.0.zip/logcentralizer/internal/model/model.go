// Package model define as estruturas de dados compartilhadas por todo o logcentralizer.
package model

import (
	"strings"
	"time"
)

// Severity representa a gravidade de uma anomalia.
type Severity int

const (
	Info Severity = iota
	Low
	Medium
	High
	Critical
)

var severityNames = []string{"INFO", "BAIXA", "MEDIA", "ALTA", "CRITICA"}

func (s Severity) String() string {
	if s < Info || s > Critical {
		return "?"
	}
	return severityNames[s]
}

// ParseSeverity converte texto (com ou sem acento) em Severity.
func ParseSeverity(v string) (Severity, bool) {
	v = strings.ToUpper(strings.TrimSpace(v))
	v = strings.NewReplacer("É", "E", "Í", "I").Replace(v)
	for i, n := range severityNames {
		if n == v {
			return Severity(i), true
		}
	}
	switch v {
	case "LOW":
		return Low, true
	case "MEDIUM":
		return Medium, true
	case "HIGH":
		return High, true
	case "CRITICAL":
		return Critical, true
	}
	return Info, false
}

// Event é um evento normalizado vindo de qualquer fonte de log.
type Event struct {
	Time     time.Time
	Source   string // id do coletor
	Host     string
	Program  string
	Level    int // prioridade syslog 0..7, -1 = desconhecida
	Message  string
	Kind     string            // tipo semântico do evento (ex.: ssh_falha)
	F        map[string]string // campos extraídos
	Snapshot bool              // evento de "fotografia" do estado atual (não entra na contagem por hora)
	Raw      string            // linha original (para evidências)
}

// Get retorna um campo do evento (vazio se não existir).
func (e *Event) Get(k string) string {
	if e.F == nil {
		return ""
	}
	return e.F[k]
}

// Set define um campo no evento.
func (e *Event) Set(k, v string) {
	if e.F == nil {
		e.F = map[string]string{}
	}
	e.F[k] = v
}

// Evidence devolve uma linha curta legível do evento.
func (e *Event) Evidence() string {
	if e.Raw != "" {
		return truncate(e.Raw, 300)
	}
	ts := ""
	if !e.Time.IsZero() {
		ts = e.Time.Format("2006-01-02 15:04:05") + " "
	}
	p := ""
	if e.Program != "" {
		p = e.Program + ": "
	}
	return truncate(ts+p+e.Message, 300)
}

func truncate(s string, n int) string {
	r := []rune(s)
	if len(r) <= n {
		return s
	}
	return string(r[:n]) + "…"
}

// Solution é uma sugestão de correção da base local.
type Solution struct {
	Title       string   `json:"titulo"`
	Explanation string   `json:"explicacao"`
	Steps       []string `json:"passos"`
	References  []string `json:"referencias"`
}

// SearchResult é um resultado de pesquisa na internet.
type SearchResult struct {
	Title   string `json:"titulo"`
	URL     string `json:"url"`
	Snippet string `json:"resumo"`
	Engine  string `json:"motor"`
}

// Anomaly é um desvio do padrão detectado.
type Anomaly struct {
	Key         string         `json:"chave"`
	Rule        string         `json:"regra"`
	Title       string         `json:"titulo"`
	Severity    Severity       `json:"-"`
	SeverityStr string         `json:"severidade"`
	Sources     []string       `json:"fontes"`
	First       time.Time      `json:"primeira"`
	Last        time.Time      `json:"ultima"`
	Count       int            `json:"ocorrencias"`
	Description string         `json:"descricao"`
	Evidence    []string       `json:"evidencias"`
	Entity      string         `json:"entidade"`
	SearchHint  string         `json:"dica_busca"`
	Solution    *Solution      `json:"solucao,omitempty"`
	Web         []SearchResult `json:"pesquisa_web,omitempty"`
	WebQuery    string         `json:"consulta_web,omitempty"`
	WebError    string         `json:"erro_web,omitempty"`
}

// AddSource adiciona uma fonte à anomalia sem duplicar.
func (a *Anomaly) AddSource(s string) {
	for _, x := range a.Sources {
		if x == s {
			return
		}
	}
	a.Sources = append(a.Sources, s)
}
