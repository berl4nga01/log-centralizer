// Package solutions contém a base local de soluções para cada tipo de anomalia e
// a pesquisa de soluções na internet (Brave Search API e DuckDuckGo).
package solutions

import "logcentralizer/internal/model"

func man(sec, name string) string {
	return "https://manpages.ubuntu.com/manpages/resolute/man" + sec + "/" + name + "." + sec + ".html"
}

type entry struct {
	sol   model.Solution
	query string // termos (em inglês) para a pesquisa na internet
}

var (
	refUSN      = "https://ubuntu.com/security/notices"
	refSSHD     = man("5", "sshd_config")
	refJournal  = man("1", "journalctl")
	refSystemd  = man("1", "systemctl")
	refSudoers  = man("5", "sudoers")
	refUFW      = man("8", "ufw")
	refF2B      = "https://github.com/fail2ban/fail2ban"
	refSmart    = man("8", "smartctl")
	refAudit    = man("8", "auditd")
	refAuditRul = man("8", "auditctl")
	refAA       = man("7", "apparmor")
	refCron     = man("5", "crontab")
	refApt      = man("8", "apt")
	refRKH      = man("8", "rkhunter")
	refLast     = man("1", "last")
	refUseradd  = man("8", "useradd")
	refVM       = "https://docs.kernel.org/admin-guide/sysctl/vm.html"
	refDocker   = "https://docs.docker.com/engine/containers/start-containers-automatically/"
	refNginx    = "https://nginx.org/en/docs/"
	refMySQL    = "https://dev.mysql.com/doc/refman/8.4/en/error-log.html"
	refPG       = "https://www.postgresql.org/docs/current/client-authentication.html"
	refLogrot   = man("8", "logrotate")
	refSS       = man("8", "ss")
	refDu       = man("1", "du")
)

var kb = map[string]entry{
	// ------------------------------------------------------------ volume / integridade de logs
	"volume_pico": {model.Solution{
		Title:       "Investigar o pico de eventos",
		Explanation: "Um volume muito acima do habitual normalmente vem de um serviço em erro repetitivo, de um ataque (força bruta, varredura) ou de uma mudança recente (atualização, novo programa).",
		Steps: []string{
			"Veja as mensagens mais frequentes da hora do pico: sudo journalctl --since 'AAAA-MM-DD HH:00' --until 'AAAA-MM-DD HH:59' -o cat | sort | uniq -c | sort -rn | head -30",
			"Identifique o programa responsável (coluna do identificador) e consulte as outras anomalias do relatório da mesma fonte.",
			"Se for um serviço em loop de erro, corrija a causa ou pare-o: sudo systemctl status <serviço>",
			"Se o aumento for legítimo (novo uso da máquina), ele será incorporado à linha de base nas próximas análises; ajuste 'deteccao.sensibilidade' se houver muitos falsos positivos.",
		},
		References: []string{refJournal},
	}, "journalctl sudden increase log messages troubleshooting"},
	"fonte_silenciosa": {model.Solution{
		Title:       "Verificar se o serviço de log está funcionando",
		Explanation: "Uma fonte que sempre registrava eventos e parou pode indicar serviço de log parado, rotação quebrada, disco cheio ou alguém apagando/redirecionando os logs.",
		Steps: []string{
			"Verifique os serviços de log: systemctl status systemd-journald rsyslog",
			"Confira espaço em disco: df -h /var/log",
			"Teste a gravação: logger 'teste logcentralizer' && sudo tail -n 3 /var/log/syslog (ou journalctl -n 3)",
			"Revise a configuração de rotação: sudo logrotate -d /etc/logrotate.conf",
			"Se nada explicar o silêncio, trate como possível ocultação de rastros e revise acessos administrativos recentes.",
		},
		References: []string{refJournal, refLogrot},
	}, "rsyslog stopped logging troubleshooting"},
	"log_truncado": {model.Solution{
		Title:       "Tratar como possível adulteração de log",
		Explanation: "O arquivo diminuiu sem ter sido rotacionado (mesmo inode). Ferramentas legítimas não costumam fazer isso; é uma técnica comum para apagar rastros de invasão.",
		Steps: []string{
			"Compare com o backup mais recente gerado pelo logcentralizer (em /var/backups/logcentralizer) para ver o que foi removido.",
			"Verifique quem tinha acesso root no período: sudo last -x; sudo journalctl _COMM=sudo --since -2d",
			"Procure rootkits: sudo apt install rkhunter chkrootkit && sudo rkhunter --check --sk",
			"Considere enviar logs para outra máquina (rsyslog remoto) e tornar o journal persistente.",
		},
		References: []string{refRKH, refLogrot},
	}, "linux log file truncated tampering detection"},
	"log_removido": {model.Solution{
		Title:       "Verificar remoção do arquivo de log",
		Explanation: "Um arquivo de log monitorado deixou de existir. Pode ser desinstalação de um serviço, mudança de configuração ou remoção intencional para esconder atividade.",
		Steps: []string{
			"Confira se o pacote foi removido: grep -i remove /var/log/apt/history.log | tail",
			"Recupere o conteúdo a partir do último backup do logcentralizer.",
			"Se não houver explicação, investigue acessos root recentes e rode rkhunter/chkrootkit.",
		},
		References: []string{refRKH},
	}, "linux log file deleted forensic investigation"},
	"erro_novo": {model.Solution{
		Title:       "Analisar a mensagem de erro inédita",
		Explanation: "Mensagens de erro nunca vistas costumam aparecer após atualizações, mudanças de configuração ou falhas novas de hardware/software.",
		Steps: []string{
			"Veja o contexto completo: sudo journalctl -p err --since today",
			"Verifique se coincide com atualização recente: tail -n 40 /var/log/apt/history.log",
			"Pesquise a mensagem exata (links abaixo) e verifique avisos de segurança do Ubuntu.",
			"Se for ruído conhecido e inofensivo, adicione um padrão em 'lista_branca.padroes_regex'.",
		},
		References: []string{refJournal, refUSN},
	}, ""},

	// ------------------------------------------------------------ SSH / logins
	"ssh_forca_bruta": {model.Solution{
		Title:       "Conter o ataque de força bruta SSH",
		Explanation: "Muitas falhas de senha vindas de um mesmo IP indicam tentativa automatizada de adivinhar senhas.",
		Steps: []string{
			"Bloqueie o IP imediatamente: sudo ufw deny from <IP>",
			"Instale e ative o fail2ban: sudo apt install fail2ban && sudo systemctl enable --now fail2ban",
			"Desative login por senha e use apenas chaves: em /etc/ssh/sshd_config.d/99-hardening.conf defina 'PasswordAuthentication no' e 'PermitRootLogin no', depois sudo systemctl reload ssh",
			"Se o SSH não for necessário no desktop, desative-o: sudo systemctl disable --now ssh",
			"Restrinja o SSH à rede local: sudo ufw allow from 192.168.0.0/16 to any port 22 proto tcp",
		},
		References: []string{refSSHD, refF2B, refUFW},
	}, "ssh brute force attack protection fail2ban"},
	"ssh_sucesso_apos_forca_bruta": {model.Solution{
		Title:       "Responder a possível comprometimento da conta",
		Explanation: "Um login bem-sucedido depois de várias falhas do mesmo IP sugere que a senha foi descoberta.",
		Steps: []string{
			"Encerre sessões suspeitas: who -a; sudo pkill -KILL -t <tty>",
			"Bloqueie o IP: sudo ufw deny from <IP>",
			"Troque a senha da conta afetada: sudo passwd <usuário>",
			"Revise chaves SSH: cat ~<usuário>/.ssh/authorized_keys e remova as desconhecidas",
			"Procure persistência: crontab -l -u <usuário>; ls -la /etc/cron.*; systemctl list-timers; ls /etc/systemd/system",
			"Desative autenticação por senha no SSH e considere reinstalar a máquina se houver sinais de uso root.",
		},
		References: []string{refSSHD, refLast, refRKH},
	}, "ssh account compromised after brute force what to do"},
	"ssh_login_root": {model.Solution{
		Title:       "Proibir login root via SSH",
		Explanation: "Entrar diretamente como root elimina a rastreabilidade de quem fez o quê e expõe a conta mais poderosa.",
		Steps: []string{
			"Defina 'PermitRootLogin no' em /etc/ssh/sshd_config.d/99-hardening.conf",
			"Recarregue: sudo sshd -t && sudo systemctl reload ssh",
			"Use contas pessoais + sudo para administração.",
		},
		References: []string{refSSHD},
	}, "disable ssh root login PermitRootLogin"},
	"login_fora_horario": {model.Solution{
		Title:       "Confirmar o login fora do horário",
		Explanation: "Logins fora da rotina configurada podem ser legítimos (trabalho extra) ou uso indevido da conta.",
		Steps: []string{
			"Confirme com o dono da conta se o acesso foi dele.",
			"Veja detalhes da sessão: last -F <usuário> | head",
			"Se o horário habitual mudou, ajuste 'deteccao.horario_login' na configuração.",
		},
		References: []string{refLast},
	}, "linux audit login time unusual hours"},
	"login_novo_usuario": {model.Solution{
		Title:       "Validar a nova conta com login",
		Explanation: "Uma conta que nunca tinha feito login passou a ser usada.",
		Steps: []string{
			"Verifique se a conta é conhecida: getent passwd <usuário>; id <usuário>",
			"Veja quando foi criada: sudo grep -E 'useradd|new user' /var/log/auth.log*",
			"Se não reconhecer a conta, bloqueie: sudo usermod -L <usuário> && sudo chage -E0 <usuário>",
		},
		References: []string{refUseradd, refLast},
	}, "linux unknown user account login investigation"},
	"login_novo_ip": {model.Solution{
		Title:       "Verificar a origem do novo login",
		Explanation: "O login veio de um endereço que nunca havia sido usado.",
		Steps: []string{
			"Confirme com o usuário se ele acessou de outro local/rede.",
			"Veja a reputação do IP em serviços como AbuseIPDB.",
			"Se não reconhecer: troque a senha, revise ~/.ssh/authorized_keys e bloqueie o IP (sudo ufw deny from <IP>).",
			"Para limitar origens, use 'AllowUsers usuario@192.168.1.*' no sshd_config.",
		},
		References: []string{refSSHD, refLast},
	}, "ssh login from unknown ip address what to check"},
	"login_falhas_repetidas": {model.Solution{
		Title:       "Avaliar falhas repetidas de login",
		Explanation: "Muitas senhas erradas seguidas podem ser esquecimento, teclado/layout errado ou tentativa de adivinhação física/remota.",
		Steps: []string{
			"Veja as tentativas: sudo journalctl -g 'authentication failure' --since today",
			"Se não foi o dono da conta, troque a senha e ative bloqueio automático com pam_faillock (/etc/security/faillock.conf).",
			"Consulte falhas registradas: sudo faillock --user <usuário>",
		},
		References: []string{man("8", "faillock"), man("5", "faillock.conf")},
	}, "pam_faillock ubuntu lock account after failed logins"},

	// ------------------------------------------------------------ sudo / su / contas
	"sudo_novo_usuario": {model.Solution{
		Title:       "Revisar quem pode usar sudo",
		Explanation: "Um usuário que nunca usou sudo passou a executar comandos como root.",
		Steps: []string{
			"Liste quem tem sudo: getent group sudo admin",
			"Revise as regras: sudo cat /etc/sudoers; sudo ls -l /etc/sudoers.d/",
			"Remova privilégios indevidos: sudo gpasswd -d <usuário> sudo",
		},
		References: []string{refSudoers},
	}, "audit sudo users ubuntu"},
	"sudo_novo_comando": {model.Solution{
		Title:       "Confirmar o comando executado como root",
		Explanation: "Comando administrativo inédito para este usuário. Normalmente é manutenção legítima.",
		Steps: []string{
			"Confira o histórico completo: sudo journalctl _COMM=sudo --since -1d",
			"Se não reconhecer o comando, trate como incidente: troque a senha do usuário e revise o que o comando alterou.",
		},
		References: []string{refSudoers},
	}, "sudo command audit log ubuntu"},
	"comando_suspeito": {model.Solution{
		Title:       "Verificar a ferramenta sensível",
		Explanation: "Ferramentas de rede, varredura, quebra de senha, módulos de kernel ou imutabilidade de arquivos são usadas por administradores, mas também por invasores.",
		Steps: []string{
			"Descubra quem executou e de onde: ps -o user,pid,ppid,lstart,cmd -C <comando>",
			"Veja conexões do processo: sudo ss -tupan | grep <pid>",
			"Se não for uso seu, encerre (sudo kill <pid>), preserve evidências (cópia de /proc/<pid>/exe) e investigue a origem.",
			"Ajuste a lista em 'deteccao.comandos_suspeitos' ou 'lista_branca.processos' para usos habituais.",
		},
		References: []string{refSS, refRKH},
	}, "linux detect suspicious process netcat reverse shell"},
	"sudo_falhas": {model.Solution{
		Title:       "Investigar falhas de senha no sudo",
		Explanation: "Várias senhas erradas no sudo podem indicar alguém tentando obter privilégios com uma sessão aberta.",
		Steps: []string{
			"Veja os detalhes: sudo journalctl _COMM=sudo -g 'incorrect password|authentication failure'",
			"Bloqueie a tela ao se ausentar e verifique se há sessões abertas desconhecidas (who).",
			"Considere reduzir 'passwd_tries' e 'timestamp_timeout' no sudoers.",
		},
		References: []string{refSudoers},
	}, "sudo incorrect password attempts security"},
	"sudo_nao_autorizado": {model.Solution{
		Title:       "Investigar tentativa de escalada de privilégio",
		Explanation: "Um usuário sem permissão tentou usar sudo.",
		Steps: []string{
			"Confirme se o usuário deveria ter acesso administrativo.",
			"Se não, investigue a conta (sessões, processos, arquivos recentes): sudo find /home/<usuário> -mtime -2 -ls",
			"Considere bloquear a conta até esclarecer: sudo usermod -L <usuário>",
		},
		References: []string{refSudoers},
	}, "user is not in the sudoers file incident reported security"},
	"su_falhas": {model.Solution{
		Title:       "Avaliar tentativas de su",
		Explanation: "Tentativas de troca de usuário com senha errada.",
		Steps: []string{
			"Veja os detalhes: sudo journalctl _COMM=su --since -1d",
			"Restrinja o su ao grupo sudo descomentando 'auth required pam_wheel.so group=sudo' em /etc/pam.d/su",
		},
		References: []string{man("8", "pam_wheel")},
	}, "restrict su command pam_wheel ubuntu"},
	"su_novo": {model.Solution{
		Title:       "Confirmar a troca de usuário",
		Explanation: "Combinação de usuários com su nunca vista antes.",
		Steps:       []string{"Confirme com o responsável se a troca de usuário foi intencional.", "Veja a sessão: sudo journalctl _COMM=su --since -1d"},
		References:  []string{man("1", "su")},
	}, "su session opened for user audit"},
	"usuario_criado": {model.Solution{
		Title:       "Validar a conta criada",
		Explanation: "Criação de contas é comum em invasões para manter acesso.",
		Steps: []string{
			"Veja a conta: getent passwd <usuário>; sudo chage -l <usuário>; id <usuário>",
			"Descubra quem criou: sudo journalctl _COMM=useradd _COMM=adduser; sudo journalctl _COMM=sudo -g useradd",
			"Se não for legítima: sudo usermod -L <usuário> && sudo deluser --remove-home <usuário> (após coletar evidências).",
		},
		References: []string{refUseradd},
	}, "linux detect unauthorized user account created"},
	"grupo_criado": {model.Solution{
		Title:       "Validar o novo grupo",
		Explanation: "Pacotes costumam criar grupos de sistema; grupos criados manualmente devem ser conhecidos.",
		Steps:       []string{"Veja o grupo e membros: getent group <grupo>", "Verifique se coincide com instalação de pacote: tail /var/log/apt/history.log"},
		References:  []string{man("8", "groupadd")},
	}, "linux new group created audit"},
	"usuario_privilegio": {model.Solution{
		Title:       "Revisar concessão de privilégios",
		Explanation: "Membros de sudo/adm/docker/lxd/disk podem obter acesso equivalente a root.",
		Steps: []string{
			"Confirme a necessidade: getent group <grupo>",
			"Remova se indevido: sudo gpasswd -d <usuário> <grupo>",
			"Atenção: grupos docker e lxd permitem virar root trivialmente.",
		},
		References: []string{man("8", "gpasswd"), refSudoers},
	}, "docker group privilege escalation linux security"},
	"usuario_modificado": {model.Solution{
		Title:       "Conferir alteração da conta",
		Explanation: "A conta mudou de grupos, UID, bloqueio ou atributos.",
		Steps:       []string{"Veja o estado atual: id <usuário>; getent passwd <usuário>", "Compare com o backup de /etc/passwd e /etc/group no último backup."},
		References:  []string{man("8", "usermod")},
	}, "linux usermod audit changes"},
	"usuario_removido": {model.Solution{
		Title:       "Confirmar a remoção",
		Explanation: "Contas e grupos removidos devem corresponder a uma decisão administrativa.",
		Steps:       []string{"Veja quem executou: sudo journalctl _COMM=userdel _COMM=deluser _COMM=sudo --since -2d"},
		References:  []string{man("8", "userdel")},
	}, "linux userdel audit"},
	"senha_alterada": {model.Solution{
		Title:       "Confirmar a troca de senha",
		Explanation: "Trocas de senha não solicitadas podem indicar tomada de conta.",
		Steps:       []string{"Confirme com o dono da conta.", "Veja a política: sudo chage -l <usuário>"},
		References:  []string{man("1", "passwd")},
	}, "linux password changed unexpectedly"},
	"usuario_uid0": {model.Solution{
		Title:       "Remover conta clandestina com UID 0",
		Explanation: "Qualquer conta com UID 0 tem poder total; só o root deveria ter.",
		Steps: []string{
			"Liste: awk -F: '$3==0' /etc/passwd",
			"Bloqueie imediatamente: sudo usermod -L <conta> e altere o shell para /usr/sbin/nologin",
			"Trate como invasão confirmada: preserve evidências, verifique rootkits e planeje reinstalação.",
		},
		References: []string{refRKH},
	}, "linux backdoor account uid 0 detection"},
	"conta_sistema_login": {model.Solution{
		Title:       "Bloquear login de conta de serviço",
		Explanation: "Contas de sistema não deveriam ter shell nem login interativo.",
		Steps:       []string{"Veja o shell: getent passwd <conta>", "Desative login: sudo usermod -s /usr/sbin/nologin <conta> && sudo usermod -L <conta>"},
		References:  []string{refLast},
	}, "linux system account interactive login security"},

	// ------------------------------------------------------------ serviços / processos
	"servico_falhou": {model.Solution{
		Title:       "Diagnosticar o serviço com falha",
		Explanation: "A unidade systemd terminou em erro.",
		Steps: []string{
			"Veja o estado e as últimas linhas: systemctl status <unidade>",
			"Leia o log completo: sudo journalctl -u <unidade> -b --no-pager | tail -50",
			"Teste a configuração do serviço (ex.: nginx -t, sshd -t) e reinicie: sudo systemctl restart <unidade>",
			"Se o serviço não é necessário: sudo systemctl disable --now <unidade> ; para limpar o estado: sudo systemctl reset-failed",
		},
		References: []string{refSystemd, refJournal},
	}, "systemd service failed how to fix"},
	"servico_reinicio_loop": {model.Solution{
		Title:       "Interromper o loop de reinício",
		Explanation: "O serviço cai logo depois de iniciar e o systemd tenta de novo continuamente.",
		Steps: []string{
			"Veja a causa da primeira falha: sudo journalctl -u <unidade> -b | head -80",
			"Pare o loop enquanto investiga: sudo systemctl stop <unidade>",
			"Corrija configuração/dependências e reinicie; ajuste Restart=/StartLimitBurst= se necessário.",
		},
		References: []string{refSystemd, man("5", "systemd.service")},
	}, "systemd service restart loop start request repeated too quickly"},
	"core_dump": {model.Solution{
		Title:       "Analisar o travamento do processo",
		Explanation: "O programa terminou de forma anormal; pode ser bug, biblioteca incompatível, memória defeituosa ou exploração de vulnerabilidade.",
		Steps: []string{
			"Liste e inspecione: coredumpctl list; coredumpctl info <PID>",
			"Atualize o sistema: sudo apt update && sudo apt full-upgrade",
			"Se o mesmo programa trava com frequência, reporte o bug (ubuntu-bug <pacote>).",
		},
		References: []string{man("1", "coredumpctl")},
	}, "coredumpctl analyze crash ubuntu"},
	"crash_aplicacao": {model.Solution{
		Title:       "Ver o relatório do apport",
		Explanation: "Uma aplicação travou e o apport guardou um relatório.",
		Steps:       []string{"Abra o relatório: ls -l /var/crash", "Envie o relatório: ubuntu-bug /var/crash/<arquivo>.crash", "Depois apague o arquivo para não reaparecer."},
		References:  []string{man("1", "apport-cli")},
	}, "ubuntu apport crash report fix"},
	"oom": {model.Solution{
		Title:       "Resolver falta de memória",
		Explanation: "A memória RAM + swap acabou e o kernel precisou matar processos.",
		Steps: []string{
			"Veja o que estava consumindo: sudo journalctl -k -g 'Out of memory' -b",
			"Monitore o uso: free -h; ps aux --sort=-%mem | head",
			"Aumente o swap (ex.: sudo fallocate -l 4G /swapfile2 && sudo chmod 600 /swapfile2 && sudo mkswap /swapfile2 && sudo swapon /swapfile2) ou adicione RAM",
			"Considere o systemd-oomd (já ativo no Ubuntu desktop) e limites de memória por serviço (MemoryMax=).",
		},
		References: []string{refVM, man("8", "systemd-oomd")},
	}, "linux out of memory killed process fix"},
	"segfault": {model.Solution{
		Title:       "Investigar falhas de segmentação",
		Explanation: "Segfaults isolados são bugs; repetidos em vários programas podem indicar memória RAM defeituosa.",
		Steps: []string{
			"Atualize o programa/sistema: sudo apt update && sudo apt full-upgrade",
			"Se vários programas diferentes falham, teste a memória (memtest86+ no menu do GRUB).",
			"Verifique core dumps: coredumpctl list",
		},
		References: []string{man("1", "coredumpctl")},
	}, "segfault at error kernel log linux"},
	"kernel_erro": {model.Solution{
		Title:       "Tratar erro grave do kernel",
		Explanation: "BUG/Oops/lockup indicam problema em driver, hardware ou no próprio kernel.",
		Steps: []string{
			"Leia o rastro completo: sudo journalctl -k -b -1 (boot anterior) ou -b (atual)",
			"Atualize o kernel e firmware: sudo apt full-upgrade; sudo fwupdmgr refresh && sudo fwupdmgr update",
			"Se começou após atualização, inicie o kernel anterior pelo GRUB (Opções avançadas).",
			"Verifique temperatura e memória (memtest86+).",
		},
		References: []string{refJournal, "https://docs.kernel.org/admin-guide/bug-hunting.html"},
	}, "kernel BUG oops call trace ubuntu"},
	"hardware_erro": {model.Solution{
		Title:       "Diagnosticar erro de hardware",
		Explanation: "MCE, PCIe/AER, ECC, ACPI e alertas térmicos apontam para componente físico, firmware ou driver.",
		Steps: []string{
			"Instale o rasdaemon para registrar erros de hardware: sudo apt install rasdaemon && sudo ras-mc-ctl --summary",
			"Atualize BIOS/UEFI e firmware: sudo fwupdmgr update",
			"Verifique temperaturas e limpeza/ventilação.",
			"Para AER de PCIe recorrente, identifique o dispositivo (lspci -vv) e teste outro slot/cabo.",
		},
		References: []string{"https://docs.kernel.org/admin-guide/ras.html", "https://docs.kernel.org/PCI/pcieaer-howto.html"},
	}, "linux hardware error mce aer troubleshooting"},
	"disco_io_erro": {model.Solution{
		Title:       "Proteger os dados do disco com erro",
		Explanation: "Erros de E/S ou corrupção de sistema de arquivos podem levar à perda de dados.",
		Steps: []string{
			"FAÇA BACKUP AGORA dos dados importantes.",
			"Verifique a saúde do disco: sudo smartctl -a /dev/<disco>",
			"Agende verificação do sistema de arquivos no próximo boot: sudo touch /forcefsck (ou fsck a partir de um pendrive live)",
			"Verifique cabos/conexões (SATA) e substitua o disco se o SMART mostrar defeitos.",
		},
		References: []string{refSmart, man("8", "fsck")},
	}, "linux I/O error disk failing what to do"},
	"usb_novo_dispositivo": {model.Solution{
		Title:       "Confirmar o dispositivo USB",
		Explanation: "Dispositivos USB desconhecidos podem se passar por teclado (BadUSB) ou trazer malware.",
		Steps: []string{
			"Identifique: lsusb; sudo journalctl -k -g usb --since -1h",
			"Se não reconhecer, desconecte e examine o dispositivo.",
			"Para controlar dispositivos permitidos, considere o USBGuard: sudo apt install usbguard",
		},
		References: []string{"https://usbguard.github.io/"},
	}, "usbguard ubuntu block unknown usb devices"},

	// ------------------------------------------------------------ firewall / fail2ban / MAC
	"firewall_varredura": {model.Solution{
		Title:       "Responder à varredura de portas",
		Explanation: "Um IP sondou muitas portas em pouco tempo: reconhecimento antes de um ataque.",
		Steps: []string{
			"O UFW já bloqueou os pacotes; para bloquear totalmente: sudo ufw deny from <IP>",
			"Confira que só as portas necessárias estão abertas: sudo ufw status verbose; sudo ss -tulpn",
			"Se a origem é da sua rede local, identifique o dispositivo (roteador/DHCP) — pode estar infectado.",
		},
		References: []string{refUFW, refSS},
	}, "detect port scan ufw block ip"},
	"firewall_inativo": {model.Solution{
		Title:       "Ativar o firewall",
		Explanation: "Sem firewall, qualquer serviço que escute na rede fica exposto.",
		Steps:       []string{"sudo ufw default deny incoming", "sudo ufw default allow outgoing", "sudo ufw enable", "sudo ufw logging on   # para alimentar o logcentralizer"},
		References:  []string{refUFW},
	}, "ubuntu enable ufw firewall"},
	"fail2ban_banimento": {model.Solution{
		Title:       "Acompanhar os banimentos do fail2ban",
		Explanation: "O fail2ban está bloqueando ataques; muitos banimentos indicam que o serviço está muito exposto.",
		Steps: []string{
			"Veja o estado: sudo fail2ban-client status sshd",
			"Aumente bantime/findtime em /etc/fail2ban/jail.local se os ataques persistirem.",
			"Reduza a exposição: feche a porta no roteador ou restrinja por IP.",
		},
		References: []string{refF2B},
	}, "fail2ban increase bantime recidive jail"},
	"apparmor_negacao": {model.Solution{
		Title:       "Analisar a negação do AppArmor",
		Explanation: "O AppArmor impediu um programa de fazer algo fora do perfil — pode ser perfil desatualizado ou comportamento malicioso contido.",
		Steps: []string{
			"Veja as negações: sudo journalctl -k -g 'apparmor=\"DENIED\"' --since today",
			"Verifique perfis: sudo aa-status",
			"Se a ação é legítima, ajuste o perfil com aa-logprof (pacote apparmor-utils); se não, investigue o processo.",
		},
		References: []string{refAA, man("8", "aa-status")},
	}, "apparmor denied operation fix profile aa-logprof"},
	"auditd_anomalia": {model.Solution{
		Title:       "Investigar anomalia da auditoria",
		Explanation: "O kernel marcou um comportamento anômalo (ANOM_PROMISCUOUS, ANOM_ABEND, ANOM_LOGIN_FAILURES etc.).",
		Steps:       []string{"Veja os eventos: sudo ausearch -m ANOM_PROMISCUOUS,ANOM_ABEND,ANOM_LOGIN_FAILURES -ts today -i", "Relatório: sudo aureport --summary"},
		References:  []string{refAudit, man("8", "ausearch")},
	}, "auditd ANOM_PROMISCUOUS ANOM_ABEND meaning"},
	"auditd_falhas": {model.Solution{
		Title:       "Analisar falhas registradas pelo auditd",
		Explanation: "A auditoria registrou várias autenticações falhas.",
		Steps:       []string{"Relatório de autenticação: sudo aureport -au --failed -ts today"},
		References:  []string{man("8", "aureport")},
	}, "aureport failed authentication"},
	"auditd_config_alterada": {model.Solution{
		Title:       "Verificar alteração das regras de auditoria",
		Explanation: "Mudanças nas regras de auditoria podem ser usadas para cegar o monitoramento.",
		Steps:       []string{"Regras atuais: sudo auditctl -l", "Torne as regras imutáveis até o próximo boot adicionando '-e 2' ao final de /etc/audit/rules.d/audit.rules"},
		References:  []string{refAuditRul},
	}, "auditctl immutable rules -e 2"},
	"auditd_chave": {model.Solution{
		Title:       "Revisar o evento auditado",
		Explanation: "Uma regra de auditoria configurada como sensível foi acionada.",
		Steps:       []string{"sudo ausearch -k <chave> -ts today -i"},
		References:  []string{man("8", "ausearch")},
	}, "ausearch key audit rule"},

	// ------------------------------------------------------------ cron / pacotes
	"cron_novo_comando": {model.Solution{
		Title:       "Validar a nova tarefa agendada",
		Explanation: "Malware usa cron para se manter ativo após reinícios.",
		Steps: []string{
			"Liste agendamentos: sudo ls -la /etc/cron.* /var/spool/cron/crontabs; sudo crontab -l -u <usuário>",
			"Remova entradas desconhecidas (crontab -e -u <usuário>) e investigue o script chamado.",
		},
		References: []string{refCron},
	}, "linux malicious cron job persistence detection"},
	"cron_novo_arquivo": {model.Solution{
		Title:       "Validar o novo arquivo de cron",
		Explanation: "Pacotes instalam arquivos em /etc/cron.*; arquivos fora de instalação de pacotes devem ser checados.",
		Steps:       []string{"Veja o conteúdo e o pacote dono: cat <arquivo>; dpkg -S <arquivo>", "Se 'dpkg -S' não encontrar dono, investigue a origem."},
		References:  []string{refCron},
	}, "linux cron.d persistence check"},
	"cron_arquivo_alterado": {model.Solution{
		Title:       "Conferir alteração do cron",
		Explanation: "O conteúdo de um arquivo de agendamento mudou.",
		Steps:       []string{"Compare com a versão do último backup do logcentralizer.", "Verifique integridade de pacotes: sudo dpkg --verify"},
		References:  []string{refCron},
	}, "detect crontab modification linux"},
	"timer_novo": {model.Solution{
		Title:       "Validar o novo timer do systemd",
		Explanation: "Timers do systemd também servem para persistência.",
		Steps:       []string{"systemctl list-timers --all", "systemctl cat <timer> e o .service correspondente", "Se desconhecido: sudo systemctl disable --now <timer>"},
		References:  []string{man("5", "systemd.timer")},
	}, "systemd timer persistence malware"},
	"pacote_fora_janela": {model.Solution{
		Title:       "Confirmar a instalação de pacotes",
		Explanation: "Instalações/remoções fora da janela combinada merecem confirmação.",
		Steps:       []string{"Veja o histórico: less /var/log/apt/history.log", "Se legítimo, ajuste 'deteccao.janela_manutencao_pacotes'."},
		References:  []string{refApt},
	}, "apt history log audit installed packages"},
	"pacote_suspeito": {model.Solution{
		Title:       "Confirmar a ferramenta instalada",
		Explanation: "Ferramentas ofensivas são comuns em invasões (movimentação lateral, quebra de senhas).",
		Steps:       []string{"Quem instalou: grep -A3 -B3 <pacote> /var/log/apt/history.log", "Se não for seu: sudo apt purge <pacote> e investigue a conta que instalou."},
		References:  []string{refApt},
	}, "linux attacker installed nmap hydra detection"},
	"pacote_seguranca_removido": {model.Solution{
		Title:       "Restaurar a ferramenta de segurança",
		Explanation: "Remover auditoria, firewall ou logs é passo típico para ocultar uma invasão.",
		Steps:       []string{"Reinstale: sudo apt install <pacote>", "Descubra quem removeu: grep -B2 -A4 <pacote> /var/log/apt/history.log", "Investigue a máquina se a remoção não foi sua."},
		References:  []string{refApt},
	}, "attacker disable logging auditd removed detection"},

	// ------------------------------------------------------------ web / docker / bancos
	"web_404_ip": {model.Solution{
		Title:       "Bloquear varredura de diretórios",
		Explanation: "Muitos 404 de um mesmo IP indicam ferramenta procurando arquivos/painéis.",
		Steps:       []string{"Bloqueie: sudo ufw deny from <IP>", "Use fail2ban com filtros nginx-botsearch/apache-noscript."},
		References:  []string{refF2B, refNginx},
	}, "fail2ban nginx-botsearch block scanners"},
	"web_5xx": {model.Solution{
		Title:       "Corrigir erros internos do servidor web",
		Explanation: "Respostas 5xx indicam falha na aplicação, no PHP-FPM/backend ou sobrecarga.",
		Steps:       []string{"Veja o error.log do servidor (/var/log/nginx/error.log ou /var/log/apache2/error.log)", "Verifique o backend (systemctl status php*-fpm etc.) e recursos (memória/disco)."},
		References:  []string{refNginx},
	}, "nginx 502 bad gateway 500 errors troubleshooting"},
	"web_scanner": {model.Solution{
		Title:       "Conter ataque/varredura web",
		Explanation: "Requisições com assinaturas de exploit (path traversal, SQLi, Log4Shell, WordPress) indicam ataque automatizado.",
		Steps:       []string{"Bloqueie o IP: sudo ufw deny from <IP>", "Mantenha a aplicação atualizada e remova painéis desnecessários.", "Considere fail2ban ou um WAF (ModSecurity)."},
		References:  []string{refF2B, refNginx},
	}, "block web vulnerability scanners nginx fail2ban"},
	"docker_container_falhou": {model.Solution{
		Title:       "Diagnosticar o container",
		Explanation: "O container terminou com código de erro.",
		Steps:       []string{"docker logs --tail 100 <container>", "docker inspect <container> --format '{{.State}}'", "Corrija e defina política de reinício adequada (--restart unless-stopped)."},
		References:  []string{refDocker},
	}, "docker container exited with code troubleshooting"},
	"docker_oom": {model.Solution{
		Title:       "Ajustar memória do container",
		Explanation: "O container excedeu o limite de memória.",
		Steps:       []string{"docker stats", "Aumente o limite (--memory) ou corrija o vazamento na aplicação."},
		References:  []string{"https://docs.docker.com/engine/containers/resource_constraints/"},
	}, "docker container OOMKilled fix"},
	"docker_reinicios": {model.Solution{
		Title:       "Interromper reinícios do container",
		Explanation: "O container entra em loop de reinício.",
		Steps:       []string{"docker logs <container>", "docker update --restart=no <container> enquanto investiga"},
		References:  []string{refDocker},
	}, "docker container restarting loop"},
	"docker_imagem_nova": {model.Solution{
		Title:       "Validar a imagem do container",
		Explanation: "Imagens desconhecidas podem conter mineradores ou backdoors.",
		Steps:       []string{"docker image inspect <imagem>", "Prefira imagens oficiais/verificadas e fixe versões."},
		References:  []string{"https://docs.docker.com/docker-hub/repos/manage/trusted-content/official-images/"},
	}, "docker malicious image cryptominer detection"},
	"db_falhas_autenticacao": {model.Solution{
		Title:       "Proteger o acesso ao banco de dados",
		Explanation: "Logins recusados em massa indicam tentativa de adivinhação de senha.",
		Steps:       []string{"Garanta que o banco só escuta localmente (bind-address=127.0.0.1 / listen_addresses='localhost').", "Use senhas fortes e restrinja usuários por host.", "Bloqueie IPs atacantes no UFW."},
		References:  []string{refMySQL, refPG},
	}, "database brute force access denied for user protect"},
	"db_falha_critica": {model.Solution{
		Title:       "Recuperar o banco de dados",
		Explanation: "Travamentos, corrupção ou recuperação após desligamento anormal podem levar à perda de dados.",
		Steps:       []string{"Leia o log de erro completo do banco.", "Faça backup (mysqldump/pg_dump) antes de qualquer reparo.", "Verifique disco e memória do servidor."},
		References:  []string{refMySQL, "https://www.postgresql.org/docs/current/backup.html"},
	}, "mysql crash recovery InnoDB error log"},

	// ------------------------------------------------------------ processos / rede
	"processo_sem_arquivo": {model.Solution{
		Title:       "Tratar como malware em memória",
		Explanation: "Processos rodando de memfd não têm arquivo em disco: técnica clássica de malware fileless.",
		Steps: []string{
			"Preserve evidências: sudo cp /proc/<pid>/exe /root/evidencia.bin; sudo cat /proc/<pid>/cmdline",
			"Veja conexões: sudo ss -tupan | grep <pid>",
			"Encerre: sudo kill -9 <pid>; desconecte a máquina da rede se necessário.",
			"Investigue a origem (processo pai: ps -o ppid= -p <pid>) e considere reinstalação.",
		},
		References: []string{refSS, refRKH},
	}, "linux fileless malware memfd detection"},
	"processo_local_suspeito": {model.Solution{
		Title:       "Investigar processo em diretório temporário",
		Explanation: "Diretórios graváveis por todos são o local preferido de malware.",
		Steps:       []string{"Detalhes: ps -o user,pid,ppid,lstart,cmd -p <pid>; ls -la <caminho>", "Conexões: sudo ss -tupan | grep <pid>", "Encerre e analise o arquivo (sha256sum, VirusTotal). Considere montar /tmp com noexec."},
		References:  []string{refSS},
	}, "linux process running from /tmp malware"},
	"processo_binario_apagado": {model.Solution{
		Title:       "Verificar processo com binário apagado",
		Explanation: "Após atualizações é normal (reinicie o programa); fora de diretórios do sistema é suspeito.",
		Steps:       []string{"Liste processos que precisam reiniciar: sudo apt install needrestart && sudo needrestart -r l", "Se o caminho não for do sistema: copie /proc/<pid>/exe para análise e encerre o processo."},
		References:  []string{man("8", "needrestart")},
	}, "linux process exe deleted detection"},
	"processo_cpu_alta": {model.Solution{
		Title:       "Verificar consumo de CPU",
		Explanation: "CPU alta contínua pode ser travamento, carga legítima ou mineração de criptomoedas.",
		Steps:       []string{"top -o %CPU (ou htop)", "Verifique se o executável é conhecido: dpkg -S <caminho>", "Mineradores costumam se conectar a pools: sudo ss -tupan | grep <pid>"},
		References:  []string{man("1", "top")},
	}, "linux detect cryptominer high cpu process"},
	"processo_memoria_alta": {model.Solution{
		Title:       "Verificar consumo de memória",
		Explanation: "Um processo ocupa grande parte da RAM (possível vazamento).",
		Steps:       []string{"ps aux --sort=-%mem | head", "Reinicie o programa ou limite sua memória (systemd MemoryMax=)."},
		References:  []string{man("5", "systemd.resource-control")},
	}, "linux process memory leak troubleshooting"},
	"processo_root_novo": {model.Solution{
		Title:       "Validar o novo programa root",
		Explanation: "Programa nunca visto rodando como root.",
		Steps:       []string{"Pacote dono: dpkg -S <caminho> (ou snap list)", "Se não pertencer a nenhum pacote, investigue a origem do arquivo."},
		References:  []string{refApt},
	}, "linux unknown process running as root"},
	"processos_zumbis": {model.Solution{
		Title:       "Limpar processos zumbis",
		Explanation: "O processo pai não está recolhendo filhos encerrados.",
		Steps:       []string{"Encontre o pai: ps -eo pid,ppid,stat,cmd | awk '$3 ~ /Z/'", "Reinicie o processo pai."},
		References:  []string{man("1", "ps")},
	}, "linux too many zombie processes fix"},
	"porta_nova": {model.Solution{
		Title:       "Validar a nova porta aberta",
		Explanation: "Um programa passou a aceitar conexões. Pode ser um serviço recém-instalado ou um backdoor.",
		Steps:       []string{"Veja quem escuta: sudo ss -tulpn | grep :<porta>", "Pacote dono do executável: dpkg -S <executável>", "Se não for necessário, pare o serviço e bloqueie a porta no UFW."},
		References:  []string{refSS, refUFW},
	}, "linux unknown listening port check"},

	// ------------------------------------------------------------ integridade
	"integridade_arquivo_novo": {model.Solution{
		Title:       "Validar o novo arquivo de configuração",
		Explanation: "Arquivos sensíveis novos (sudoers.d, sshd_config.d, unidades systemd) mudam o comportamento de segurança.",
		Steps:       []string{"Veja o conteúdo e o dono: cat <arquivo>; dpkg -S <arquivo>", "Remova se não reconhecer, após guardar uma cópia."},
		References:  []string{refSudoers, refSSHD},
	}, "linux detect configuration file tampering"},
	"integridade_arquivo_alterado": {model.Solution{
		Title:       "Conferir a alteração do arquivo crítico",
		Explanation: "O conteúdo de um arquivo sensível mudou.",
		Steps: []string{
			"Compare com o último backup: tar -xzf <backup> -C /tmp/restauro e diff -u /tmp/restauro/<caminho> <caminho>",
			"Para arquivos de pacotes: sudo dpkg --verify; debsums -c (pacote debsums)",
			"Mudanças em /etc/shadow são normais após troca de senha.",
		},
		References: []string{man("1", "debsums")},
	}, "linux file integrity monitoring aide"},
	"chave_ssh_alterada": {model.Solution{
		Title:       "Revisar chaves SSH autorizadas",
		Explanation: "Adicionar uma chave em authorized_keys é a forma mais comum de manter acesso a uma máquina invadida.",
		Steps:       []string{"Veja as chaves: cat <arquivo>", "Remova as desconhecidas e verifique quem alterou (journalctl, last).", "Proteja: chmod 600 ~/.ssh/authorized_keys"},
		References:  []string{man("8", "sshd")},
	}, "ssh authorized_keys backdoor detection"},
	"ld_preload": {model.Solution{
		Title:       "Remover pré-carregamento suspeito",
		Explanation: "/etc/ld.so.preload injeta bibliotecas em todos os programas — técnica de rootkits de usuário.",
		Steps:       []string{"Veja o conteúdo e a biblioteca: cat /etc/ld.so.preload; ls -la <biblioteca>; dpkg -S <biblioteca>", "Se desconhecida: mova o arquivo, reinicie e rode rkhunter/chkrootkit.", "Considere a máquina comprometida."},
		References:  []string{refRKH, man("8", "ld.so")},
	}, "ld.so.preload rootkit detection removal"},

	// ------------------------------------------------------------ hardware / recursos
	"temperatura_alta": {model.Solution{
		Title:       "Reduzir a temperatura",
		Explanation: "Temperatura alta causa lentidão (throttling), travamentos e reduz a vida útil do hardware.",
		Steps:       []string{"Veja os sensores: sensors (pacote lm-sensors)", "Limpe poeira, verifique ventoinhas e pasta térmica.", "Verifique processos com CPU alta (top).", "Em notebooks, use superfície rígida e considere o thermald (sudo apt install thermald)."},
		References:  []string{man("1", "sensors")},
	}, "linux cpu temperature too high fix"},
	"smart_falha": {model.Solution{
		Title:       "Substituir o disco em falha",
		Explanation: "O disco reportou falha pelo SMART.",
		Steps:       []string{"FAÇA BACKUP IMEDIATAMENTE.", "Detalhes: sudo smartctl -a <disco>", "Substitua o disco; ative monitoramento contínuo com smartd (/etc/smartd.conf)."},
		References:  []string{refSmart, man("8", "smartd")},
	}, "smartctl SMART overall-health FAILED replace disk"},
	"smart_desgaste": {model.Solution{
		Title:       "Planejar troca do SSD",
		Explanation: "O SSD consumiu quase toda a vida útil estimada.",
		Steps:       []string{"Mantenha backups atualizados.", "Planeje a substituição.", "sudo smartctl -a <disco> | grep -i 'percentage used'"},
		References:  []string{refSmart},
	}, "nvme percentage used wear level replace"},
	"smart_setores": {model.Solution{
		Title:       "Acompanhar defeitos do disco",
		Explanation: "Setores realocados/pendentes/incorrigíveis são defeitos físicos; se crescem, o disco está degradando.",
		Steps:       []string{"Backup imediato.", "Teste longo: sudo smartctl -t long <disco>; depois sudo smartctl -a <disco>", "Se os números aumentarem entre análises, substitua o disco."},
		References:  []string{refSmart},
	}, "smart reallocated sector count pending sectors meaning"},
	"memoria_ecc_erro": {model.Solution{
		Title:       "Testar e substituir a memória",
		Explanation: "Erros de memória ECC indicam módulo de RAM degradado.",
		Steps:       []string{"Detalhes: sudo ras-mc-ctl --errors (pacote rasdaemon)", "Identifique o módulo (DIMM) e substitua; teste com memtest86+."},
		References:  []string{"https://docs.kernel.org/admin-guide/ras.html"},
	}, "edac corrected errors increasing replace dimm"},
	"bateria_degradada": {model.Solution{
		Title:       "Avaliar a bateria",
		Explanation: "A bateria retém bem menos carga que a original.",
		Steps:       []string{"upower -i $(upower -e | grep BAT)", "Considere a substituição; evite manter 100% o tempo todo (limite de carga na BIOS/GNOME)."},
		References:  []string{man("1", "upower")},
	}, "laptop battery health linux capacity"},
	"disco_cheio": {model.Solution{
		Title:       "Liberar espaço em disco",
		Explanation: "Disco cheio impede gravação de logs e trava aplicações.",
		Steps: []string{
			"Descubra o que ocupa: sudo du -xh --max-depth=1 <ponto> | sort -h | tail",
			"Limpe pacotes e caches: sudo apt autoremove --purge && sudo apt clean",
			"Reduza o journal: sudo journalctl --vacuum-size=500M",
			"Snaps antigos: snap list --all | awk '/disabled/{print $1, $3}' (e remova com sudo snap remove <nome> --revision=<rev>)",
			"Backups do logcentralizer ficam em /var/backups/logcentralizer — ajuste 'backup.retencao_dias' ou mova-os para outro disco.",
		},
		References: []string{refDu, refJournal},
	}, "ubuntu disk full free up space"},
	"inodes_cheio": {model.Solution{
		Title:       "Liberar inodes",
		Explanation: "Milhões de arquivos pequenos esgotaram os inodes.",
		Steps:       []string{"Encontre o diretório: sudo du --inodes -x <ponto> | sort -n | tail", "Apague caches/sessões antigos (ex.: /var/lib/php/sessions, caches de aplicações)."},
		References:  []string{refDu},
	}, "linux no space left on device inodes full"},
	"memoria_baixa": {model.Solution{
		Title:       "Liberar memória",
		Explanation: "Pouca memória disponível causa lentidão e OOM.",
		Steps:       []string{"ps aux --sort=-%mem | head", "Feche programas pesados, aumente swap ou RAM."},
		References:  []string{refVM},
	}, "linux low available memory troubleshooting"},
	"swap_alto": {model.Solution{
		Title:       "Reduzir uso de swap",
		Explanation: "Uso intenso de swap deixa o sistema lento.",
		Steps:       []string{"free -h; vmstat 1 5", "Identifique processos (smem ou ps) e considere mais RAM."},
		References:  []string{refVM},
	}, "linux high swap usage fix"},
	"carga_alta": {model.Solution{
		Title:       "Investigar carga alta",
		Explanation: "Mais tarefas na fila do que os processadores conseguem atender.",
		Steps:       []string{"top / htop para ver processos", "Verifique E/S de disco travada: vmstat 1 5 (coluna wa) e iotop"},
		References:  []string{man("1", "uptime")},
	}, "linux high load average troubleshooting"},
}

// Lookup devolve a solução local de uma regra.
func Lookup(rule string) (*model.Solution, string, bool) {
	e, ok := kb[rule]
	if !ok {
		return nil, "", false
	}
	s := e.sol
	return &s, e.query, true
}

// Rules devolve as regras conhecidas (para documentação).
func Rules() []string {
	out := make([]string, 0, len(kb))
	for k := range kb {
		out = append(out, k)
	}
	return out
}
