// simulador gera logs sintéticos (14 dias de uso normal de um desktop e, no modo
// "ataque", as últimas horas com incidentes) para testar o logcentralizer sem
// mexer nos logs reais do sistema.
//
//	logcentralizer-simulador -dir /tmp/lcz-teste -modo normal
//	logcentralizer-simulador -dir /tmp/lcz-teste -modo ataque
package main

import (
	"flag"
	"fmt"
	"math/rand"
	"os"
	"path/filepath"
	"sort"
	"strings"
	"time"
	_ "time/tzdata"
)

type line struct {
	t time.Time
	s string
}

type logs map[string][]line

func (l logs) add(file string, t time.Time, s string) { l[file] = append(l[file], line{t, s}) }

func iso(t time.Time) string { return t.Format("2006-01-02T15:04:05.000000-07:00") }
func bsd(t time.Time) string { return t.Format("Jan _2 15:04:05") }

func sys(t time.Time, prog, msg string) string { return iso(t) + " desktop " + prog + ": " + msg }

func main() {
	dir := flag.String("dir", "/tmp/lcz-teste", "diretório onde os logs simulados serão criados")
	modo := flag.String("modo", "normal", "normal | ataque")
	dias := flag.Int("dias", 14, "dias de histórico normal")
	flag.Parse()
	now := time.Now()
	r := rand.New(rand.NewSource(42))
	L := logs{}
	end := now.Add(-4 * time.Hour)
	switch *modo {
	case "normal":
		start := now.AddDate(0, 0, -*dias)
		for d := start.Truncate(time.Hour); d.Before(end); d = d.Add(time.Hour) {
			normalHour(L, r, d, end)
		}
		writeAll(*dir, L, false)
		// arquivo que será "adulterado" no modo ataque
		mysql := filepath.Join(*dir, "mysql/error.log")
		os.MkdirAll(filepath.Dir(mysql), 0o755)
		var b strings.Builder
		for d := start; d.Before(end); d = d.Add(2 * time.Hour) {
			b.WriteString(d.UTC().Format("2006-01-02T15:04:05.000000Z") + " 0 [System] [MY-010931] [Server] /usr/sbin/mysqld: ready for connections.\n")
		}
		os.WriteFile(mysql, []byte(b.String()), 0o640)
		fmt.Printf("Logs normais de %d dias gerados em %s (até %s)\n", *dias, *dir, end.Format("02/01 15:04"))
	case "ataque":
		attack(L, r, now)
		writeAll(*dir, L, true)
		fmt.Printf("Incidentes simulados adicionados em %s (entre %s e %s)\n", *dir,
			now.Add(-3*time.Hour).Format("15:04"), now.Add(-10*time.Minute).Format("15:04"))
	default:
		fmt.Fprintln(os.Stderr, "modo inválido")
		os.Exit(1)
	}
}

func at(base time.Time, r *rand.Rand) time.Time {
	return base.Add(time.Duration(r.Intn(3600)) * time.Second)
}

func normalHour(L logs, r *rand.Rand, h time.Time, end time.Time) {
	hr := h.Hour()
	if hr < 8 || hr > 22 { // desktop desligado de madrugada
		return
	}
	add := func(f string, t time.Time, s string) {
		if t.Before(end) {
			L.add(f, t, s)
		}
	}
	progs := []struct{ p, m string }{
		{"systemd[1]", "Started session-%d.scope - Session %d of User joao."},
		{"NetworkManager[812]", "<info>  [%d.%d] device (wlp2s0): state change: activated"},
		{"gnome-shell[2201]", "Window manager warning: Overlay changed %d %d"},
		{"systemd[1]", "Starting packagekit.service - PackageKit Daemon... %d %d"},
		{"dbus-daemon[700]", "[system] Activating via systemd: service name='org.freedesktop.%d' unit='x%d'"},
	}
	for i := 0; i < 25+r.Intn(10); i++ {
		p := progs[r.Intn(len(progs))]
		add("syslog", at(h, r), sys(at(h, r), p.p, fmt.Sprintf(p.m, r.Intn(99), r.Intn(99))))
	}
	if r.Intn(3) == 0 { // erro conhecido e habitual
		add("syslog", at(h, r), sys(at(h, r), "gnome-shell[2201]", "JS ERROR: TypeError: this._settings is null"))
	}
	// autenticação
	if hr == 8 {
		t := h.Add(5 * time.Minute)
		add("auth.log", t, sys(t, "gdm-password]", "pam_unix(gdm-password:session): session opened for user joao(uid=1000) by joao(uid=0)"))
	}
	if r.Intn(4) == 0 {
		t := at(h, r)
		add("auth.log", t, sys(t, "sshd[3100]", "Accepted publickey for joao from 192.168.1.50 port 51234 ssh2: ED25519 SHA256:abc"))
	}
	if r.Intn(6) == 0 {
		t := at(h, r)
		add("auth.log", t, sys(t, "sudo", "    joao : TTY=pts/0 ; PWD=/home/joao ; USER=root ; COMMAND=/usr/bin/apt update"))
	}
	if r.Intn(8) == 0 {
		t := at(h, r)
		add("auth.log", t, sys(t, "sudo", "    joao : TTY=pts/1 ; PWD=/home/joao ; USER=root ; COMMAND=/usr/bin/systemctl restart cups"))
	}
	if r.Intn(30) == 0 {
		t := at(h, r)
		add("auth.log", t, sys(t, "sshd[3200]", "Failed password for joao from 192.168.1.50 port 50000 ssh2"))
	}
	for i := 0; i < 3; i++ {
		t := at(h, r)
		add("auth.log", t, sys(t, "systemd-logind[650]", fmt.Sprintf("New session %d of user joao.", r.Intn(500))))
	}
	// kernel
	for i := 0; i < 4+r.Intn(4); i++ {
		t := at(h, r)
		add("kern.log", t, bsd(t)+" desktop kernel: [12345.678901] wlp2s0: Limiting TX power to 20 dBm "+fmt.Sprint(r.Intn(9)))
	}
	if hr == 9 {
		t := h.Add(10 * time.Minute)
		add("kern.log", t, bsd(t)+" desktop kernel: [ 100.000000] usb 1-2: New USB device found, idVendor=046d, idProduct=c52b, bcdDevice=12.11")
	}
	// firewall: ruído de internet
	for i := 0; i < 3+r.Intn(4); i++ {
		t := at(h, r)
		src := fmt.Sprintf("%d.%d.%d.%d", 80+r.Intn(100), r.Intn(255), r.Intn(255), 1+r.Intn(250))
		dpt := []int{23, 445, 3389, 22}[r.Intn(4)]
		add("ufw.log", t, bsd(t)+fmt.Sprintf(" desktop kernel: [UFW BLOCK] IN=wlp2s0 OUT= MAC=aa SRC=%s DST=192.168.1.10 LEN=44 TOS=0x00 PREC=0x00 TTL=50 ID=1 PROTO=TCP SPT=%d DPT=%d WINDOW=1024 RES=0x00 SYN URGP=0", src, 40000+r.Intn(9999), dpt))
	}
	// nginx (servidor de desenvolvimento local)
	for i := 0; i < 15+r.Intn(10); i++ {
		t := at(h, r)
		path := []string{"/", "/index.html", "/api/status", "/static/app.js"}[r.Intn(4)]
		add("nginx/access.log", t, fmt.Sprintf(`192.168.1.%d - - [%s] "GET %s HTTP/1.1" 200 %d "-" "Mozilla/5.0 (X11; Linux x86_64)"`,
			20+r.Intn(5), t.Format("02/Jan/2006:15:04:05 -0700"), path, 500+r.Intn(5000)))
	}
	// apt: atualização a cada 3 dias às 10h
	if hr == 10 && h.YearDay()%3 == 0 {
		t := h.Add(2 * time.Minute)
		add("apt/history.log", t, "\nStart-Date: "+t.Format("2006-01-02  15:04:05")+"\nCommandline: apt upgrade -y\nRequested-By: joao (1000)\nUpgrade: libc6:amd64 (2.41-1, 2.41-2), firefox:amd64 (1:1.0, 1:1.1)\nEnd-Date: "+t.Add(time.Minute).Format("2006-01-02  15:04:05")+"\n")
		add("dpkg.log", t, t.Format("2006-01-02 15:04:05")+" upgrade libc6:amd64 2.41-1 2.41-2")
	}
	// auditd
	if r.Intn(3) == 0 {
		t := at(h, r)
		add("audit/audit.log", t, fmt.Sprintf(`type=USER_LOGIN msg=audit(%d.%03d:%d): pid=3100 uid=0 auid=1000 ses=3 msg='op=login id=1000 exe="/usr/sbin/sshd" hostname=? addr=192.168.1.50 terminal=sshd res=success'`, t.Unix(), r.Intn(999), r.Intn(99999)))
	}
}

func attack(L logs, r *rand.Rand, now time.Time) {
	t0 := now.Add(-3 * time.Hour)
	// 1) força bruta SSH seguida de sucesso
	bf := t0.Add(10 * time.Minute)
	for i := 0; i < 60; i++ {
		t := bf.Add(time.Duration(i*8) * time.Second)
		u := []string{"root", "admin", "test", "joao"}[i%4]
		L.add("auth.log", t, sys(t, "sshd[4100]", "Failed password for "+map[bool]string{true: "invalid user ", false: ""}[u == "admin" || u == "test"]+u+" from 203.0.113.77 port "+fmt.Sprint(40000+i)+" ssh2"))
	}
	t := bf.Add(9 * time.Minute)
	L.add("auth.log", t, sys(t, "sshd[4101]", "Accepted password for joao from 203.0.113.77 port 41999 ssh2"))
	// 2) login root de IP novo
	t = t0.Add(30 * time.Minute)
	L.add("auth.log", t, sys(t, "sshd[4200]", "Accepted password for root from 198.51.100.23 port 52000 ssh2"))
	// 3) criação de conta UID 0, privilégio sudo, sudo não autorizado
	t = t0.Add(35 * time.Minute)
	L.add("auth.log", t, sys(t, "useradd[4300]", "new user: name=backdoor, UID=0, GID=0, home=/root, shell=/bin/bash, from=/dev/pts/2"))
	L.add("auth.log", t.Add(time.Minute), sys(t.Add(time.Minute), "usermod[4301]", "add 'visitante' to group 'sudo'"))
	L.add("auth.log", t.Add(2*time.Minute), sys(t.Add(2*time.Minute), "sudo", "visitante : TTY=pts/3 ; PWD=/tmp ; USER=root ; COMMAND=/usr/bin/nc -lvnp 4444"))
	L.add("auth.log", t.Add(3*time.Minute), sys(t.Add(3*time.Minute), "sudo", "  estagiario : user NOT in sudoers ; TTY=pts/4 ; PWD=/home/estagiario ; USER=root ; COMMAND=/bin/bash"))
	// 4) varredura de portas
	t = t0.Add(50 * time.Minute)
	for p := 1; p <= 120; p++ {
		tt := t.Add(time.Duration(p) * 500 * time.Millisecond)
		L.add("ufw.log", tt, bsd(tt)+fmt.Sprintf(" desktop kernel: [UFW BLOCK] IN=wlp2s0 OUT= MAC=aa SRC=45.33.32.156 DST=192.168.1.10 LEN=44 TOS=0x00 PREC=0x00 TTL=50 ID=1 PROTO=TCP SPT=61000 DPT=%d WINDOW=1024 RES=0x00 SYN URGP=0", p*7))
	}
	// 5) serviço em loop + pico de volume no syslog + erro novo
	t = t0.Add(70 * time.Minute)
	for i := 0; i < 600; i++ {
		tt := t.Add(time.Duration(i*5) * time.Second)
		L.add("syslog", tt, sys(tt, "minhaapi[9000]", "panic: runtime error: invalid memory address or nil pointer dereference"))
		if i%10 == 0 {
			L.add("syslog", tt, sys(tt, "systemd[1]", fmt.Sprintf("minhaapi.service: Scheduled restart job, restart counter is at %d.", i/10+1)))
			L.add("syslog", tt, sys(tt, "systemd[1]", "minhaapi.service: Failed with result 'exit-code'."))
		}
	}
	// 6) kernel: OOM, erro de disco, segfault, USB desconhecido
	t = t0.Add(80 * time.Minute)
	L.add("kern.log", t, bsd(t)+" desktop kernel: [99999.1] Out of memory: Killed process 7777 (chrome) total-vm:9000000kB, anon-rss:7000000kB")
	L.add("kern.log", t.Add(time.Minute), bsd(t.Add(time.Minute))+" desktop kernel: [99999.2] EXT4-fs error (device sda2): ext4_find_entry:1455: inode #2: comm ls: reading directory lblock 0")
	L.add("kern.log", t.Add(2*time.Minute), bsd(t.Add(2*time.Minute))+" desktop kernel: [99999.3] blender[8888]: segfault at 0 ip 00007f sp 00007ffd error 4 in libc.so.6")
	L.add("kern.log", t.Add(3*time.Minute), bsd(t.Add(3*time.Minute))+" desktop kernel: [99999.4] usb 1-4: New USB device found, idVendor=16c0, idProduct=0486, bcdDevice=1.00")
	L.add("kern.log", t.Add(3*time.Minute), bsd(t.Add(3*time.Minute))+" desktop kernel: [99999.5] usb 1-4: Product: Teensyduino Keyboard")
	// 7) pacotes de madrugada: ferramenta ofensiva instalada, auditd removido
	t = time.Date(now.Year(), now.Month(), now.Day(), 3, 0, 0, 0, time.Local)
	if t.After(now) || t.Before(t0) {
		t = t0.Add(90 * time.Minute)
	}
	L.add("apt/history.log", t, "\nStart-Date: "+t.Format("2006-01-02  15:04:05")+"\nCommandline: apt install nmap\nRequested-By: visitante (1001)\nInstall: nmap:amd64 (7.95-1), libpcap0.8t64:amd64 (1.10, automatic)\nEnd-Date: "+t.Add(time.Minute).Format("2006-01-02  15:04:05")+"\n")
	t2 := t.Add(5 * time.Minute)
	L.add("apt/history.log", t2, "\nStart-Date: "+t2.Format("2006-01-02  15:04:05")+"\nCommandline: apt purge auditd\nRequested-By: visitante (1001)\nPurge: auditd:amd64 (1:4.0-1)\nEnd-Date: "+t2.Add(time.Minute).Format("2006-01-02  15:04:05")+"\n")
	// 8) varredura web + erros 5xx
	t = t0.Add(100 * time.Minute)
	paths := []string{"/wp-login.php", "/.env", "/../../etc/passwd", "/phpmyadmin/index.php", "/.git/config", "/cgi-bin/luci", "/?id=1%20UNION%20SELECT%201,2"}
	for i := 0; i < 160; i++ {
		tt := t.Add(time.Duration(i) * 2 * time.Second)
		L.add("nginx/access.log", tt, fmt.Sprintf(`185.220.101.4 - - [%s] "GET %s HTTP/1.1" 404 153 "-" "sqlmap/1.8"`, tt.Format("02/Jan/2006:15:04:05 -0700"), paths[i%len(paths)]))
	}
	for i := 0; i < 70; i++ {
		tt := t.Add(time.Duration(i) * 5 * time.Second)
		L.add("nginx/access.log", tt, fmt.Sprintf(`192.168.1.21 - - [%s] "POST /api/pedido HTTP/1.1" 502 157 "-" "Mozilla/5.0"`, tt.Format("02/Jan/2006:15:04:05 -0700")))
	}
	// 9) fail2ban
	for i := 0; i < 3; i++ {
		tt := t0.Add(time.Duration(20+i) * time.Minute)
		L.add("fail2ban.log", tt, tt.Format("2006-01-02 15:04:05")+",123 fail2ban.actions        [990]: NOTICE  [sshd] Ban 203.0.113."+fmt.Sprint(77+i))
	}
	// 10) auditd: interface em modo promíscuo
	tt := t0.Add(110 * time.Minute)
	L.add("audit/audit.log", tt, fmt.Sprintf(`type=ANOM_PROMISCUOUS msg=audit(%d.100:9999): dev=wlp2s0 prom=256 old_prom=0 auid=1001 uid=0 gid=0 ses=7`, tt.Unix()))
	// 11) banco de dados: falhas de login (o arquivo é reescrito -> "log truncado")
	var b strings.Builder
	for i := 0; i < 25; i++ {
		x := t0.Add(time.Duration(120+i) * time.Minute)
		b.WriteString(x.UTC().Format("2006-01-02T15:04:05.000000Z") + " 31 [Note] [MY-010926] [Server] Access denied for user 'root'@'203.0.113.77' (using password: YES)\n")
	}
	os.WriteFile(filepath.Join(flag.Lookup("dir").Value.String(), "mysql/error.log"), []byte(b.String()), 0o640)
}

func writeAll(dir string, L logs, appendMode bool) {
	for f, ls := range L {
		sort.SliceStable(ls, func(i, j int) bool { return ls[i].t.Before(ls[j].t) })
		p := filepath.Join(dir, f)
		os.MkdirAll(filepath.Dir(p), 0o755)
		flags := os.O_CREATE | os.O_WRONLY | os.O_TRUNC
		if appendMode {
			flags = os.O_CREATE | os.O_WRONLY | os.O_APPEND
		}
		fh, err := os.OpenFile(p, flags, 0o640)
		if err != nil {
			fmt.Fprintln(os.Stderr, err)
			continue
		}
		for _, l := range ls {
			s := l.s
			if strings.HasPrefix(s, "\n") && !appendMode && fhEmpty(fh) {
				s = strings.TrimPrefix(s, "\n")
			}
			fh.WriteString(s)
			if !strings.HasSuffix(s, "\n") {
				fh.WriteString("\n")
			}
		}
		fh.Close()
	}
}

func fhEmpty(f *os.File) bool {
	st, err := f.Stat()
	return err == nil && st.Size() == 0
}
