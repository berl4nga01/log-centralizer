// Package config carrega, valida e grava a configuração do logcentralizer (JSON).
package config

import (
	"encoding/json"
	"fmt"
	"net"
	"os"
	"path/filepath"
	"regexp"
	"strings"
	"time"

	"logcentralizer/internal/model"
)

const DefaultPath = "/etc/logcentralizer/config.json"

type Config struct {
	NomeHost             string               `json:"nome_host"`
	DiretorioDados       string               `json:"diretorio_dados"`
	DiretorioRelatorios  string               `json:"diretorio_relatorios"`
	Analise              Analise              `json:"analise"`
	LinhaDeBase          LinhaDeBase          `json:"linha_de_base"`
	Deteccao             Deteccao             `json:"deteccao"`
	ListaBranca          ListaBranca          `json:"lista_branca"`
	Fontes               map[string]*Fonte    `json:"fontes"`
	FontesPersonalizadas []FontePersonalizada `json:"fontes_personalizadas"`
	BuscaWeb             BuscaWeb             `json:"busca_web"`
	Backup               Backup               `json:"backup"`
	Relatorio            Relatorio            `json:"relatorio"`

	nomeHostOriginal string
	compiledIgnore   []*regexp.Regexp
	whiteNets        []*net.IPNet
}

type Analise struct {
	JanelaInicialHoras     int `json:"janela_inicial_horas"`
	RetroativoMaximoDias   int `json:"retroativo_maximo_dias"`
	TimeoutFonteSegundos   int `json:"timeout_fonte_segundos"`
	MaxAmostrasPorAnomalia int `json:"max_amostras_por_anomalia"`
}

type LinhaDeBase struct {
	Dias                  int  `json:"dias"`
	HorasMinimas          int  `json:"horas_minimas"`
	RetencaoEntidadesDias int  `json:"retencao_entidades_dias"`
	AprenderComAnomalias  bool `json:"aprender_com_anomalias"`
	MaxModelosPorFonte    int  `json:"max_modelos_por_fonte"`
}

type Sensibilidade struct {
	ZScore             float64 `json:"zscore"`
	MinimoEventos      int     `json:"minimo_eventos"`
	FatorMultiplicador float64 `json:"fator_multiplicador"`
}

type Janela struct {
	Falhas        int `json:"falhas"`
	JanelaMinutos int `json:"janela_minutos"`
}

type Horario struct {
	Inicio     string `json:"inicio"`
	Fim        string `json:"fim"`
	DiasSemana []int  `json:"dias_semana"` // 0=domingo ... 6=sábado
}

type Varredura struct {
	PortasDistintas int `json:"portas_distintas"`
	JanelaMinutos   int `json:"janela_minutos"`
}

type Web struct {
	Erros5xxPorHora     int `json:"erros_5xx_por_hora"`
	Requisicoes404PorIP int `json:"requisicoes_404_por_ip"`
	AssinaturasScanner  int `json:"assinaturas_scanner_por_ip"`
}

type Limites struct {
	DiscoPercentual             float64 `json:"disco_percentual"`
	InodesPercentual            float64 `json:"inodes_percentual"`
	MemoriaLivrePercentualMin   float64 `json:"memoria_livre_percentual_minima"`
	SwapPercentual              float64 `json:"swap_percentual"`
	TemperaturaCelsius          float64 `json:"temperatura_celsius"`
	CPUProcessoPercentual       float64 `json:"cpu_processo_percentual"`
	MemoriaProcessoPercentual   float64 `json:"memoria_processo_percentual"`
	CargaPorCPU                 float64 `json:"carga_por_cpu"`
	Zumbis                      int     `json:"zumbis"`
	BateriaSaudeMinima          float64 `json:"bateria_saude_minima"`
	SegfaultsMesmoProcesso      int     `json:"segfaults_mesmo_processo"`
	ReinicioServicoContador     int     `json:"reinicio_servico_contador"`
	ReiniciosContainer          int     `json:"reinicios_container"`
	FalhasBancoDados            int     `json:"falhas_autenticacao_banco"`
	FonteSilenciosaMediaMinima  float64 `json:"fonte_silenciosa_media_minima"`
	FonteSilenciosaHorasMinimas int     `json:"fonte_silenciosa_horas_minimas"`
}

type Deteccao struct {
	Sensibilidade              string            `json:"sensibilidade"` // baixa | media | alta
	SensibilidadePersonalizada Sensibilidade     `json:"sensibilidade_personalizada"`
	RegrasDesativadas          []string          `json:"regras_desativadas"`
	SeveridadePersonalizada    map[string]string `json:"severidade_personalizada"`
	ForcaBrutaSSH              Janela            `json:"forca_bruta_ssh"`
	ForcaBrutaLocal            Janela            `json:"forca_bruta_local"`
	ForcaBrutaSudo             Janela            `json:"forca_bruta_sudo"`
	HorarioLogin               Horario           `json:"horario_login"`
	JanelaManutencaoPacotes    Horario           `json:"janela_manutencao_pacotes"`
	VarreduraPortas            Varredura         `json:"varredura_portas"`
	Web                        Web               `json:"web"`
	Limites                    Limites           `json:"limites"`
	ComandosSuspeitos          []string          `json:"comandos_suspeitos"`
	DiretoriosSuspeitos        []string          `json:"diretorios_suspeitos"`
	ChavesAuditdAlerta         []string          `json:"chaves_auditd_alerta"`
	ArquivosIntegridade        []string          `json:"arquivos_integridade"`
	ServicosLogin              []string          `json:"servicos_login_interativo"`
}

type ListaBranca struct {
	IPs             []string `json:"ips"`
	Usuarios        []string `json:"usuarios"`
	PadroesRegex    []string `json:"padroes_regex"`
	UnidadesSystemd []string `json:"unidades_systemd"`
	Portas          []string `json:"portas"`
	Processos       []string `json:"processos"`
	Pacotes         []string `json:"pacotes"`
}

type Fonte struct {
	Ativo    *bool    `json:"ativo,omitempty"`
	Modo     string   `json:"modo,omitempty"` // auto | arquivo | journal
	Caminhos []string `json:"caminhos,omitempty"`
}

type FontePersonalizada struct {
	Nome          string `json:"nome"`
	Caminho       string `json:"caminho"`
	Formato       string `json:"formato"` // texto | json | regex | syslog
	Regex         string `json:"regex"`
	LayoutTempo   string `json:"layout_tempo"`
	CampoTempo    string `json:"campo_tempo"`
	CampoMensagem string `json:"campo_mensagem"`
	CampoNivel    string `json:"campo_nivel"`
	Ativo         *bool  `json:"ativo,omitempty"`
}

type BuscaWeb struct {
	Ativo                bool     `json:"ativo"`
	Provedores           []string `json:"provedores"` // brave, duckduckgo
	BraveChaveAPI        string   `json:"brave_chave_api"`
	MaxBuscasPorExecucao int      `json:"max_buscas_por_execucao"`
	ResultadosPorBusca   int      `json:"resultados_por_busca"`
	TimeoutSegundos      int      `json:"timeout_segundos"`
	CacheDias            int      `json:"cache_dias"`
	Idioma               string   `json:"idioma"`
	SeveridadeMinima     string   `json:"severidade_minima"`
	Proxy                string   `json:"proxy"`
}

type Criptografia struct {
	Ativo        bool   `json:"ativo"`
	ArquivoSenha string `json:"arquivo_senha"`
}

type Backup struct {
	Ativo                       bool         `json:"ativo"`
	Diretorio                   string       `json:"diretorio"`
	RetencaoDias                int          `json:"retencao_dias"` // 0 = manter sempre
	MaxBackups                  int          `json:"max_backups"`   // 0 = ilimitado
	Caminhos                    []string     `json:"caminhos"`
	Excluir                     []string     `json:"excluir"`
	ExportacaoJournal           string       `json:"exportacao_journal"` // completa | periodo | nenhuma
	TamanhoMaxArquivoMB         int          `json:"tamanho_max_arquivo_mb"`
	EspacoLivreMinimoPercentual float64      `json:"espaco_livre_minimo_percentual"`
	Criptografia                Criptografia `json:"criptografia"`
}

type Relatorio struct {
	AnalisesNoHistorico      int  `json:"analises_no_historico"`
	MaxAnomaliasDetalhadas   int  `json:"max_anomalias_detalhadas"`
	MostrarInfo              bool `json:"mostrar_info"`
	HistoricoMaximoRegistros int  `json:"historico_maximo_registros"`
	RetencaoRelatoriosDias   int  `json:"retencao_relatorios_dias"` // 0 = manter sempre
	LarguraLinha             int  `json:"largura_linha"`
}

func bptr(b bool) *bool { return &b }

// Default devolve a configuração padrão.
func Default() *Config {
	allDays := []int{0, 1, 2, 3, 4, 5, 6}
	c := &Config{
		DiretorioDados:      "/var/lib/logcentralizer",
		DiretorioRelatorios: "/var/lib/logcentralizer/relatorios",
		Analise: Analise{
			JanelaInicialHoras:     24,
			RetroativoMaximoDias:   7,
			TimeoutFonteSegundos:   300,
			MaxAmostrasPorAnomalia: 5,
		},
		LinhaDeBase: LinhaDeBase{
			Dias:                  14,
			HorasMinimas:          24,
			RetencaoEntidadesDias: 90,
			AprenderComAnomalias:  false,
			MaxModelosPorFonte:    5000,
		},
		Deteccao: Deteccao{
			Sensibilidade:           "media",
			SeveridadePersonalizada: map[string]string{},
			RegrasDesativadas:       []string{},
			ForcaBrutaSSH:           Janela{Falhas: 5, JanelaMinutos: 10},
			ForcaBrutaLocal:         Janela{Falhas: 5, JanelaMinutos: 10},
			ForcaBrutaSudo:          Janela{Falhas: 3, JanelaMinutos: 10},
			HorarioLogin:            Horario{Inicio: "07:00", Fim: "23:59", DiasSemana: allDays},
			JanelaManutencaoPacotes: Horario{Inicio: "08:00", Fim: "22:00", DiasSemana: allDays},
			VarreduraPortas:         Varredura{PortasDistintas: 15, JanelaMinutos: 5},
			Web:                     Web{Erros5xxPorHora: 50, Requisicoes404PorIP: 100, AssinaturasScanner: 5},
			Limites: Limites{
				DiscoPercentual:             90,
				InodesPercentual:            90,
				MemoriaLivrePercentualMin:   5,
				SwapPercentual:              80,
				TemperaturaCelsius:          85,
				CPUProcessoPercentual:       90,
				MemoriaProcessoPercentual:   50,
				CargaPorCPU:                 4,
				Zumbis:                      20,
				BateriaSaudeMinima:          60,
				SegfaultsMesmoProcesso:      5,
				ReinicioServicoContador:     5,
				ReiniciosContainer:          3,
				FalhasBancoDados:            10,
				FonteSilenciosaMediaMinima:  5,
				FonteSilenciosaHorasMinimas: 6,
			},
			ComandosSuspeitos: []string{"nc", "ncat", "netcat", "socat", "nmap", "masscan", "hydra", "john",
				"hashcat", "tcpdump", "insmod", "rmmod", "chattr", "xmrig", "minerd", "msfconsole", "msfvenom",
				"mimikatz", "linpeas.sh", "pspy", "cryptominer"},
			DiretoriosSuspeitos: []string{"/tmp", "/var/tmp", "/dev/shm"},
			ChavesAuditdAlerta:  []string{},
			ArquivosIntegridade: []string{
				"/etc/passwd", "/etc/shadow", "/etc/group", "/etc/gshadow",
				"/etc/sudoers", "/etc/sudoers.d/*",
				"/etc/ssh/sshd_config", "/etc/ssh/sshd_config.d/*",
				"/etc/pam.d/common-auth", "/etc/pam.d/sshd", "/etc/pam.d/sudo",
				"/etc/hosts", "/etc/resolv.conf", "/etc/ld.so.preload", "/etc/ld.so.conf.d/*",
				"/etc/environment", "/etc/profile", "/etc/bash.bashrc", "/etc/rc.local",
				"/root/.ssh/authorized_keys", "/home/*/.ssh/authorized_keys",
				"/etc/systemd/system/*.service", "/etc/apt/sources.list", "/etc/apt/sources.list.d/*",
			},
			ServicosLogin: []string{"sshd", "login", "gdm-password", "gdm-autologin", "gdm-fingerprint",
				"gdm-smartcard", "lightdm", "sddm", "xrdp-sesman", "cockpit"},
		},
		ListaBranca: ListaBranca{
			IPs:             []string{"127.0.0.1", "::1"},
			Usuarios:        []string{},
			PadroesRegex:    []string{},
			UnidadesSystemd: []string{},
			Portas:          []string{},
			Processos:       []string{},
			Pacotes:         []string{},
		},
		Fontes:               map[string]*Fonte{},
		FontesPersonalizadas: []FontePersonalizada{},
		BuscaWeb: BuscaWeb{
			Ativo:                true,
			Provedores:           []string{"brave", "duckduckgo"},
			MaxBuscasPorExecucao: 8,
			ResultadosPorBusca:   3,
			TimeoutSegundos:      10,
			CacheDias:            7,
			Idioma:               "pt-BR",
			SeveridadeMinima:     "MEDIA",
		},
		Backup: Backup{
			Ativo:                       true,
			Diretorio:                   "/var/backups/logcentralizer",
			RetencaoDias:                0,
			MaxBackups:                  0,
			Caminhos:                    []string{"/var/log", "/var/lib/lastlog", "/var/crash"},
			Excluir:                     []string{"/var/log/journal"},
			ExportacaoJournal:           "completa",
			TamanhoMaxArquivoMB:         2048,
			EspacoLivreMinimoPercentual: 10,
			Criptografia:                Criptografia{Ativo: false, ArquivoSenha: "/etc/logcentralizer/backup.key"},
		},
		Relatorio: Relatorio{
			AnalisesNoHistorico:      10,
			MaxAnomaliasDetalhadas:   60,
			MostrarInfo:              false,
			HistoricoMaximoRegistros: 1000,
			RetencaoRelatoriosDias:   0,
			LarguraLinha:             100,
		},
	}
	return c
}

// Load lê a configuração do disco mesclando sobre os valores padrão.
func Load(path string) (*Config, error) {
	c := Default()
	data, err := os.ReadFile(path)
	if err != nil {
		if os.IsNotExist(err) {
			if err := c.Prepare(); err != nil {
				return nil, err
			}
			return c, nil
		}
		return nil, err
	}
	if err := json.Unmarshal(data, c); err != nil {
		return nil, fmt.Errorf("erro de sintaxe no arquivo de configuração %s: %w", path, err)
	}
	if err := c.Prepare(); err != nil {
		return nil, err
	}
	return c, nil
}

// Save grava a configuração formatada.
func (c *Config) Save(path string) error {
	if err := os.MkdirAll(filepath.Dir(path), 0o750); err != nil {
		return err
	}
	cp := *c
	cp.NomeHost = c.nomeHostOriginal
	data, err := json.MarshalIndent(&cp, "", "  ")
	if err != nil {
		return err
	}
	return os.WriteFile(path, append(data, '\n'), 0o600)
}

// Prepare valida e pré-compila estruturas auxiliares.
func (c *Config) Prepare() error {
	c.nomeHostOriginal = c.NomeHost
	if c.NomeHost == "" {
		h, _ := os.Hostname()
		c.NomeHost = h
	}
	if c.Fontes == nil {
		c.Fontes = map[string]*Fonte{}
	}
	if c.Deteccao.SeveridadePersonalizada == nil {
		c.Deteccao.SeveridadePersonalizada = map[string]string{}
	}
	switch strings.ToLower(c.Deteccao.Sensibilidade) {
	case "baixa", "media", "média", "alta":
	default:
		return fmt.Errorf("deteccao.sensibilidade inválida: %q (use baixa, media ou alta)", c.Deteccao.Sensibilidade)
	}
	for _, h := range []Horario{c.Deteccao.HorarioLogin, c.Deteccao.JanelaManutencaoPacotes} {
		if _, err := parseHM(h.Inicio); err != nil {
			return fmt.Errorf("horário inválido %q: %w", h.Inicio, err)
		}
		if _, err := parseHM(h.Fim); err != nil {
			return fmt.Errorf("horário inválido %q: %w", h.Fim, err)
		}
	}
	for r, s := range c.Deteccao.SeveridadePersonalizada {
		if _, ok := model.ParseSeverity(s); !ok {
			return fmt.Errorf("severidade_personalizada[%s] inválida: %q", r, s)
		}
	}
	if _, ok := model.ParseSeverity(c.BuscaWeb.SeveridadeMinima); !ok {
		return fmt.Errorf("busca_web.severidade_minima inválida: %q", c.BuscaWeb.SeveridadeMinima)
	}
	c.compiledIgnore = nil
	for _, p := range c.ListaBranca.PadroesRegex {
		re, err := regexp.Compile(p)
		if err != nil {
			return fmt.Errorf("lista_branca.padroes_regex inválido %q: %w", p, err)
		}
		c.compiledIgnore = append(c.compiledIgnore, re)
	}
	c.whiteNets = nil
	for _, ip := range c.ListaBranca.IPs {
		if !strings.Contains(ip, "/") {
			if strings.Contains(ip, ":") {
				ip += "/128"
			} else {
				ip += "/32"
			}
		}
		_, n, err := net.ParseCIDR(ip)
		if err != nil {
			return fmt.Errorf("lista_branca.ips inválido %q: %w", ip, err)
		}
		c.whiteNets = append(c.whiteNets, n)
	}
	for _, fp := range c.FontesPersonalizadas {
		if fp.Nome == "" || fp.Caminho == "" {
			return fmt.Errorf("fontes_personalizadas: 'nome' e 'caminho' são obrigatórios")
		}
		if fp.Formato == "regex" {
			if _, err := regexp.Compile(fp.Regex); err != nil {
				return fmt.Errorf("fonte personalizada %s: regex inválida: %w", fp.Nome, err)
			}
		}
	}
	switch c.Backup.ExportacaoJournal {
	case "completa", "periodo", "nenhuma", "":
	default:
		return fmt.Errorf("backup.exportacao_journal inválido: %q (completa, periodo ou nenhuma)", c.Backup.ExportacaoJournal)
	}
	if c.LinhaDeBase.Dias <= 0 {
		c.LinhaDeBase.Dias = 14
	}
	if c.Analise.JanelaInicialHoras <= 0 {
		c.Analise.JanelaInicialHoras = 24
	}
	if c.Analise.TimeoutFonteSegundos <= 0 {
		c.Analise.TimeoutFonteSegundos = 300
	}
	if c.Analise.MaxAmostrasPorAnomalia <= 0 {
		c.Analise.MaxAmostrasPorAnomalia = 5
	}
	if c.Relatorio.AnalisesNoHistorico <= 0 {
		c.Relatorio.AnalisesNoHistorico = 10
	}
	if c.Relatorio.LarguraLinha < 60 {
		c.Relatorio.LarguraLinha = 100
	}
	if c.LinhaDeBase.MaxModelosPorFonte <= 0 {
		c.LinhaDeBase.MaxModelosPorFonte = 5000
	}
	return nil
}

// SensitivityParams devolve os parâmetros efetivos de sensibilidade.
func (c *Config) SensitivityParams() Sensibilidade {
	var s Sensibilidade
	switch strings.ToLower(c.Deteccao.Sensibilidade) {
	case "baixa":
		s = Sensibilidade{ZScore: 4, MinimoEventos: 50, FatorMultiplicador: 5}
	case "alta":
		s = Sensibilidade{ZScore: 2, MinimoEventos: 10, FatorMultiplicador: 2}
	default:
		s = Sensibilidade{ZScore: 3, MinimoEventos: 20, FatorMultiplicador: 3}
	}
	p := c.Deteccao.SensibilidadePersonalizada
	if p.ZScore > 0 {
		s.ZScore = p.ZScore
	}
	if p.MinimoEventos > 0 {
		s.MinimoEventos = p.MinimoEventos
	}
	if p.FatorMultiplicador > 0 {
		s.FatorMultiplicador = p.FatorMultiplicador
	}
	return s
}

// SourceEnabled informa se a fonte está ativa (padrão: ativa).
func (c *Config) SourceEnabled(id string) bool {
	if f, ok := c.Fontes[id]; ok && f != nil && f.Ativo != nil {
		return *f.Ativo
	}
	return true
}

// SourceMode devolve o modo configurado da fonte (auto, arquivo, journal).
func (c *Config) SourceMode(id string) string {
	if f, ok := c.Fontes[id]; ok && f != nil && f.Modo != "" {
		return f.Modo
	}
	return "auto"
}

// SourcePaths devolve os caminhos configurados ou os padrões informados.
func (c *Config) SourcePaths(id string, def []string) []string {
	if f, ok := c.Fontes[id]; ok && f != nil && len(f.Caminhos) > 0 {
		return f.Caminhos
	}
	return def
}

// RuleEnabled informa se uma regra está ativa.
func (c *Config) RuleEnabled(rule string) bool {
	for _, r := range c.Deteccao.RegrasDesativadas {
		if r == rule {
			return false
		}
	}
	return true
}

// SeverityFor aplica severidade personalizada, se houver.
func (c *Config) SeverityFor(rule string, def model.Severity) model.Severity {
	if s, ok := c.Deteccao.SeveridadePersonalizada[rule]; ok {
		if v, ok := model.ParseSeverity(s); ok {
			return v
		}
	}
	return def
}

// IPWhitelisted informa se o IP está na lista branca.
func (c *Config) IPWhitelisted(ip string) bool {
	p := net.ParseIP(strings.Trim(ip, "[]"))
	if p == nil {
		return false
	}
	for _, n := range c.whiteNets {
		if n.Contains(p) {
			return true
		}
	}
	return false
}

// UserWhitelisted informa se o usuário está na lista branca.
func (c *Config) UserWhitelisted(u string) bool { return contains(c.ListaBranca.Usuarios, u) }

// MessageIgnored informa se a mensagem bate com algum padrão ignorado.
func (c *Config) MessageIgnored(msg string) bool {
	for _, re := range c.compiledIgnore {
		if re.MatchString(msg) {
			return true
		}
	}
	return false
}

func contains(l []string, v string) bool {
	for _, x := range l {
		if x == v {
			return true
		}
	}
	return false
}

// Contains é exportado para outros pacotes.
func Contains(l []string, v string) bool { return contains(l, v) }

func parseHM(s string) (int, error) {
	t, err := time.Parse("15:04", s)
	if err != nil {
		return 0, err
	}
	return t.Hour()*60 + t.Minute(), nil
}

// InWindow informa se o instante t está dentro do horário configurado.
// Suporta janelas que atravessam a meia-noite (ex.: 22:00-06:00).
func (h Horario) InWindow(t time.Time) bool {
	if len(h.DiasSemana) > 0 && !containsInt(h.DiasSemana, int(t.Weekday())) {
		return false
	}
	start, err1 := parseHM(h.Inicio)
	end, err2 := parseHM(h.Fim)
	if err1 != nil || err2 != nil {
		return true
	}
	m := t.Hour()*60 + t.Minute()
	if start <= end {
		return m >= start && m <= end
	}
	return m >= start || m <= end
}

func containsInt(l []int, v int) bool {
	for _, x := range l {
		if x == v {
			return true
		}
	}
	return false
}

// Describe devolve descrição legível do horário.
func (h Horario) Describe() string {
	nomes := []string{"dom", "seg", "ter", "qua", "qui", "sex", "sáb"}
	var d []string
	for _, x := range h.DiasSemana {
		if x >= 0 && x < 7 {
			d = append(d, nomes[x])
		}
	}
	return fmt.Sprintf("%s–%s (%s)", h.Inicio, h.Fim, strings.Join(d, ","))
}
