#!/usr/bin/env bash
# Instalador do logcentralizer (Ubuntu 26.04 LTS; funciona em 22.04/24.04 também).
#
#   sudo ./scripts/install.sh              instalação interativa
#   sudo ./scripts/install.sh --compilar   força compilar a partir do código-fonte (requer Go)
#   sudo ./scripts/install.sh --sim        responde "sim" a todas as perguntas
#   sudo ./scripts/install.sh --nao        responde "não" (só instala o logcentralizer)
set -euo pipefail

HERE="$(cd "$(dirname "$0")/.." && pwd)"
PREFIX="/usr/local/bin"
CFG="/etc/logcentralizer/config.json"
FORCE_BUILD=0
ANSWER=""
for a in "$@"; do
  case "$a" in
    --compilar) FORCE_BUILD=1 ;;
    --sim|-y)   ANSWER="s" ;;
    --nao|-n)   ANSWER="n" ;;
    *) echo "opção desconhecida: $a" >&2; exit 1 ;;
  esac
done

c_ok()   { printf '\033[32m✔\033[0m %s\n' "$*"; }
c_warn() { printf '\033[33m!\033[0m %s\n' "$*"; }
c_err()  { printf '\033[31m✘\033[0m %s\n' "$*" >&2; }
ask() {
  local q="$1" r
  if [ -n "$ANSWER" ]; then [ "$ANSWER" = "s" ]; return; fi
  read -r -p "$q [s/N] " r || true
  [[ "$r" =~ ^([sS]|[sS][iI][mM]|[yY])$ ]]
}

echo "=============================================="
echo " Instalação do logcentralizer"
echo "=============================================="

if [ "$(id -u)" -ne 0 ]; then
  c_err "Execute como root: sudo $0"
  exit 1
fi

if [ -r /etc/os-release ]; then
  . /etc/os-release
  echo "Sistema: ${PRETTY_NAME:-desconhecido}"
  if [ "${ID:-}" != "ubuntu" ]; then
    c_warn "Este instalador foi feito para Ubuntu; prosseguindo mesmo assim."
  elif [ "${VERSION_ID:-}" != "26.04" ]; then
    c_warn "Desenvolvido para Ubuntu 26.04 LTS; detectado ${VERSION_ID:-?} (deve funcionar)."
  fi
fi

case "$(uname -m)" in
  x86_64|amd64)  ARCH="amd64" ;;
  aarch64|arm64) ARCH="arm64" ;;
  *)             ARCH="" ;;
esac

# ------------------------------------------------------------------ binários
BIN_DIR="$HERE/bin/linux-$ARCH"
if [ "$FORCE_BUILD" -eq 0 ] && [ -n "$ARCH" ] && [ -x "$BIN_DIR/logcentralizer" ]; then
  c_ok "Usando binários pré-compilados ($BIN_DIR)"
  SRC_LCZ="$BIN_DIR/logcentralizer"
  SRC_SIM="$BIN_DIR/logcentralizer-simulador"
else
  if ! command -v go >/dev/null 2>&1; then
    c_warn "Go não encontrado. Para compilar é necessário o pacote golang-go."
    if ask "Instalar o Go agora (apt install golang-go)?"; then
      apt-get update && apt-get install -y golang-go
    else
      c_err "Sem binário pré-compilado para '$(uname -m)' e sem Go. Abortando."
      exit 1
    fi
  fi
  echo "Compilando com $(go version)..."
  mkdir -p "$HERE/build"
  (cd "$HERE" && CGO_ENABLED=0 go build -trimpath -ldflags "-s -w" -o build/logcentralizer ./cmd/logcentralizer \
               && CGO_ENABLED=0 go build -trimpath -ldflags "-s -w" -o build/logcentralizer-simulador ./cmd/simulador)
  c_ok "Compilação concluída"
  SRC_LCZ="$HERE/build/logcentralizer"
  SRC_SIM="$HERE/build/logcentralizer-simulador"
fi

install -m 0755 "$SRC_LCZ" "$PREFIX/logcentralizer"
install -m 0755 "$SRC_SIM" "$PREFIX/logcentralizer-simulador"
c_ok "Instalado em $PREFIX/logcentralizer ($("$PREFIX/logcentralizer" versao))"

# ------------------------------------------------------------------ diretórios e configuração
install -d -m 0750 /etc/logcentralizer
install -d -m 0700 /var/lib/logcentralizer /var/lib/logcentralizer/relatorios
install -d -m 0700 /var/backups/logcentralizer
if [ -f "$CFG" ]; then
  c_ok "Configuração existente mantida: $CFG"
  "$PREFIX/logcentralizer" config validar || c_warn "Revise o arquivo de configuração."
else
  "$PREFIX/logcentralizer" config init
  c_ok "Configuração padrão criada: $CFG"
fi

# ------------------------------------------------------------------ ferramentas de log
echo
echo "Verificando as ferramentas de monitoramento..."
"$PREFIX/logcentralizer" verificar | tail -n 4
echo
if ask "Deseja instalar as ferramentas que faltam (recomendadas e opcionais)?"; then
  "$PREFIX/logcentralizer" verificar --instalar -y || c_warn "Algumas instalações falharam (veja acima)."
  # ativa o que foi instalado
  if command -v ufw >/dev/null 2>&1; then
    if ask "Ativar o firewall UFW (bloqueia conexões de entrada não autorizadas) e o registro de bloqueios?"; then
      ufw default deny incoming >/dev/null; ufw default allow outgoing >/dev/null
      ufw --force enable >/dev/null && ufw logging on >/dev/null && c_ok "UFW ativo com logging"
    fi
  fi
  for svc in rsyslog auditd acct fail2ban smartmontools; do
    if systemctl list-unit-files "$svc.service" >/dev/null 2>&1 && systemctl list-unit-files "$svc.service" | grep -q "$svc"; then
      systemctl enable --now "$svc" >/dev/null 2>&1 && c_ok "Serviço $svc ativo" || true
    fi
  done
  if command -v auditctl >/dev/null 2>&1 && [ ! -f /etc/audit/rules.d/logcentralizer.rules ]; then
    if ask "Adicionar regras básicas de auditoria (contas, sudoers, SSH, cron, módulos do kernel)?"; then
      install -m 0640 "$HERE/configs/auditd-logcentralizer.rules" /etc/audit/rules.d/logcentralizer.rules
      augenrules --load >/dev/null 2>&1 || service auditd restart >/dev/null 2>&1 || true
      c_ok "Regras de auditoria instaladas (/etc/audit/rules.d/logcentralizer.rules)"
    fi
  fi
fi

# ------------------------------------------------------------------ criptografia
echo
if ask "Deseja criptografar os backups de logs (AES-256)?"; then
  "$PREFIX/logcentralizer" config criptografia ativar
fi

echo
echo "=============================================="
c_ok "Instalação concluída!"
echo "=============================================="
cat <<EOF
Próximos passos:
  1. Revise a configuração:      sudo nano $CFG
  2. Rode a primeira análise:    sudo logcentralizer analisar
  3. Leia o relatório:           sudo logcentralizer relatorio | less
  4. (Opcional) chave da Brave:  sudo logcentralizer config brave-chave SUA_CHAVE

Teste com ataques simulados (não mexe nos logs reais):
  sudo $HERE/scripts/teste_simulado.sh
EOF
