// Package util reúne funções auxiliares: leitura de arquivos (inclusive rotacionados
// e .gz), execução de comandos, parsing de datas e normalização de mensagens.
package util

import (
	"bufio"
	"compress/gzip"
	"context"
	"crypto/sha256"
	"encoding/hex"
	"hash/fnv"
	"io"
	"os"
	"os/exec"
	"path/filepath"
	"regexp"
	"sort"
	"strconv"
	"strings"
	"time"
)

// ---------------------------------------------------------------- normalização

var (
	reUUID   = regexp.MustCompile(`[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}`)
	reIPv4   = regexp.MustCompile(`\b\d{1,3}(?:\.\d{1,3}){3}(?::\d+)?\b`)
	reIPv6   = regexp.MustCompile(`\b(?:[0-9a-fA-F]{1,4}:){3,7}[0-9a-fA-F]{1,4}\b|\b(?:[0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{0,4}\b`)
	reMAC    = regexp.MustCompile(`\b(?:[0-9a-fA-F]{2}:){5}[0-9a-fA-F]{2}\b`)
	reHex    = regexp.MustCompile(`\b0x[0-9a-fA-F]+\b|\b[0-9a-fA-F]*\d[0-9a-fA-F]*[a-fA-F][0-9a-fA-F]{6,}\b|\b[0-9a-fA-F]{12,}\b`)
	reNum    = regexp.MustCompile(`\d+`)
	reQuoted = regexp.MustCompile(`"[^"]{40,}"`)
	reSpaces = regexp.MustCompile(`\s+`)
)

// Template transforma uma mensagem em um "modelo" sem partes variáveis
// (números, IPs, UUIDs, hashes), usado para detectar mensagens nunca vistas.
func Template(s string) string {
	s = reUUID.ReplaceAllString(s, "<uuid>")
	s = reMAC.ReplaceAllString(s, "<mac>")
	s = reIPv4.ReplaceAllString(s, "<ip>")
	s = reIPv6.ReplaceAllString(s, "<ip>")
	s = reHex.ReplaceAllString(s, "<hex>")
	s = reQuoted.ReplaceAllString(s, `"<txt>"`)
	s = reNum.ReplaceAllString(s, "<n>")
	s = reSpaces.ReplaceAllString(strings.TrimSpace(s), " ")
	if r := []rune(s); len(r) > 240 {
		s = string(r[:240])
	}
	return s
}

// Hash64 devolve um hash curto (FNV-64a) em hexadecimal.
func Hash64(s string) string {
	h := fnv.New64a()
	h.Write([]byte(s))
	return strconv.FormatUint(h.Sum64(), 16)
}

// SHA256File calcula o SHA-256 de um arquivo.
func SHA256File(path string) (string, error) {
	f, err := os.Open(path)
	if err != nil {
		return "", err
	}
	defer f.Close()
	h := sha256.New()
	if _, err := io.Copy(h, f); err != nil {
		return "", err
	}
	return hex.EncodeToString(h.Sum(nil)), nil
}

var reErrorish = regexp.MustCompile(`(?i)\b(error|erro|fail(ed|ure)?|fatal|critical|panic|denied|segfault|corrupt|cannot|can't|unable|timeout|timed out|refused|invalid|exception)\b`)

// LooksLikeError informa se uma mensagem parece ser de erro.
func LooksLikeError(msg string) bool { return reErrorish.MatchString(msg) }

// ---------------------------------------------------------------- comandos

// CmdExists informa se um comando existe no PATH (ou em sbin).
func CmdExists(name string) bool {
	_, err := LookCmd(name)
	return err == nil
}

// LookCmd procura um comando no PATH e nos diretórios sbin comuns.
func LookCmd(name string) (string, error) {
	if p, err := exec.LookPath(name); err == nil {
		return p, nil
	}
	for _, d := range []string{"/usr/sbin", "/sbin", "/usr/local/sbin", "/usr/bin", "/bin"} {
		p := filepath.Join(d, name)
		if st, err := os.Stat(p); err == nil && !st.IsDir() && st.Mode()&0o111 != 0 {
			return p, nil
		}
	}
	return "", exec.ErrNotFound
}

// RunLines executa um comando e entrega cada linha da saída padrão a fn.
func RunLines(ctx context.Context, fn func(string), name string, args ...string) error {
	p, err := LookCmd(name)
	if err != nil {
		return err
	}
	cmd := exec.CommandContext(ctx, p, args...)
	cmd.Env = append(os.Environ(), "LC_ALL=C", "LANG=C", "SYSTEMD_COLORS=0", "SYSTEMD_PAGER=")
	out, err := cmd.StdoutPipe()
	if err != nil {
		return err
	}
	var stderr strings.Builder
	cmd.Stderr = &limitedWriter{w: &stderr, n: 4096}
	if err := cmd.Start(); err != nil {
		return err
	}
	sc := bufio.NewScanner(out)
	sc.Buffer(make([]byte, 64*1024), 16*1024*1024)
	for sc.Scan() {
		fn(sc.Text())
	}
	scanErr := sc.Err()
	if scanErr != nil {
		_, _ = io.Copy(io.Discard, out)
	}
	if err := cmd.Wait(); err != nil {
		if ctx.Err() != nil {
			return ctx.Err()
		}
		msg := strings.TrimSpace(stderr.String())
		if msg != "" {
			return &CmdError{Err: err, Stderr: msg}
		}
		return err
	}
	return scanErr
}

// RunOutput executa um comando e devolve a saída completa (stdout).
func RunOutput(ctx context.Context, timeout time.Duration, name string, args ...string) (string, error) {
	ctx, cancel := context.WithTimeout(ctx, timeout)
	defer cancel()
	var b strings.Builder
	err := RunLines(ctx, func(l string) { b.WriteString(l); b.WriteByte('\n') }, name, args...)
	return b.String(), err
}

// CmdError carrega o stderr de um comando que falhou.
type CmdError struct {
	Err    error
	Stderr string
}

func (e *CmdError) Error() string { return e.Err.Error() + ": " + e.Stderr }

type limitedWriter struct {
	w io.Writer
	n int
}

func (l *limitedWriter) Write(p []byte) (int, error) {
	if l.n <= 0 {
		return len(p), nil
	}
	q := p
	if len(q) > l.n {
		q = q[:l.n]
	}
	l.n -= len(q)
	_, _ = l.w.Write(q)
	return len(p), nil
}

// ---------------------------------------------------------------- arquivos

// Exists informa se um caminho existe.
func Exists(p string) bool {
	_, err := os.Stat(p)
	return err == nil
}

// Readable informa se o arquivo pode ser aberto para leitura.
func Readable(p string) bool {
	f, err := os.Open(p)
	if err != nil {
		return false
	}
	f.Close()
	return true
}

// ExpandGlobs expande uma lista de padrões glob, mantendo apenas arquivos existentes.
func ExpandGlobs(patterns []string) []string {
	seen := map[string]bool{}
	var out []string
	for _, p := range patterns {
		m, err := filepath.Glob(p)
		if err != nil || len(m) == 0 {
			continue
		}
		sort.Strings(m)
		for _, f := range m {
			if !seen[f] {
				seen[f] = true
				out = append(out, f)
			}
		}
	}
	return out
}

// AnyExists informa se algum dos padrões casa com um arquivo existente.
func AnyExists(patterns []string) bool { return len(ExpandGlobs(patterns)) > 0 }

var reRotNum = regexp.MustCompile(`^\.(\d+)(\.gz)?$`)
var reRotDate = regexp.MustCompile(`^-(\d{8,10})(\.gz)?$`)

// RotatedFiles devolve o arquivo principal e suas versões rotacionadas, da mais
// antiga para a mais nova (arquivo principal por último).
func RotatedFiles(main string) []string {
	type rf struct {
		path string
		ord  int64 // maior = mais novo
	}
	var list []rf
	cands, _ := filepath.Glob(globEscape(main) + "*")
	for _, c := range cands {
		suf := strings.TrimPrefix(c, main)
		switch {
		case suf == "":
			list = append(list, rf{c, 1 << 62})
		case reRotNum.MatchString(suf):
			n, _ := strconv.ParseInt(reRotNum.FindStringSubmatch(suf)[1], 10, 64)
			list = append(list, rf{c, (1 << 40) - n})
		case reRotDate.MatchString(suf):
			n, _ := strconv.ParseInt(reRotDate.FindStringSubmatch(suf)[1], 10, 64)
			list = append(list, rf{c, n % (1 << 39)})
		}
	}
	sort.Slice(list, func(i, j int) bool { return list[i].ord < list[j].ord })
	out := make([]string, 0, len(list))
	for _, x := range list {
		out = append(out, x.path)
	}
	return out
}

func globEscape(s string) string {
	r := strings.NewReplacer("[", `\[`, "*", `\*`, "?", `\?`)
	return r.Replace(s)
}

// OpenMaybeGz abre um arquivo, descompactando se terminar em .gz.
func OpenMaybeGz(path string) (io.ReadCloser, error) {
	f, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	if strings.HasSuffix(path, ".gz") {
		gz, err := gzip.NewReader(f)
		if err != nil {
			f.Close()
			return nil, err
		}
		return &gzCloser{gz, f}, nil
	}
	return f, nil
}

type gzCloser struct {
	*gzip.Reader
	f *os.File
}

func (g *gzCloser) Close() error { g.Reader.Close(); return g.f.Close() }

// ScanFile lê o arquivo linha a linha (aceita .gz).
func ScanFile(ctx context.Context, path string, fn func(string)) error {
	r, err := OpenMaybeGz(path)
	if err != nil {
		return err
	}
	defer r.Close()
	sc := bufio.NewScanner(r)
	sc.Buffer(make([]byte, 64*1024), 8*1024*1024)
	n := 0
	for sc.Scan() {
		fn(sc.Text())
		n++
		if n%5000 == 0 && ctx.Err() != nil {
			return ctx.Err()
		}
	}
	return sc.Err()
}

// ScanLogFamily lê o arquivo principal e os rotacionados cujo mtime é >= since.
// Arquivos rotacionados mais antigos que since são ignorados (todas as linhas seriam antigas).
func ScanLogFamily(ctx context.Context, patterns []string, since time.Time, fn func(path, line string)) ([]string, error) {
	var mains []string
	var firstErr error
	for _, m := range ExpandGlobs(patterns) {
		if isRotatedName(m) {
			continue
		}
		mains = append(mains, m)
		for _, f := range RotatedFiles(m) {
			st, err := os.Stat(f)
			if err != nil || st.IsDir() {
				continue
			}
			if !since.IsZero() && st.ModTime().Before(since) {
				continue
			}
			path := f
			if err := ScanFile(ctx, f, func(l string) { fn(path, l) }); err != nil && firstErr == nil {
				firstErr = err
			}
		}
	}
	return mains, firstErr
}

var reRotatedName = regexp.MustCompile(`(\.\d+(\.gz)?|\.gz|-\d{8,10}(\.gz)?)$`)

func isRotatedName(p string) bool { return reRotatedName.MatchString(filepath.Base(p)) }

// ---------------------------------------------------------------- datas

var months = map[string]time.Month{"Jan": 1, "Feb": 2, "Mar": 3, "Apr": 4, "May": 5, "Jun": 6,
	"Jul": 7, "Aug": 8, "Sep": 9, "Oct": 10, "Nov": 11, "Dec": 12}

// SyslogLine é uma linha syslog decomposta.
type SyslogLine struct {
	Time    time.Time
	Host    string
	Program string
	PID     string
	Message string
}

var reBSD = regexp.MustCompile(`^([A-Z][a-z]{2})\s+(\d{1,2})\s+(\d{2}):(\d{2}):(\d{2})\s+(\S+)\s+(.*)$`)
var reISO = regexp.MustCompile(`^(\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}:?\d{2})?)\s+(\S+)\s+(.*)$`)
var reProg = regexp.MustCompile(`^([^\s:\[]+)(?:\[(\d+)\])?:\s?(.*)$`)

// ParseSyslog interpreta linhas nos formatos RFC3339 (rsyslog moderno) e BSD (tradicional).
func ParseSyslog(line string, now time.Time) (SyslogLine, bool) {
	var s SyslogLine
	var rest string
	if m := reISO.FindStringSubmatch(line); m != nil {
		t, ok := ParseISO(m[1])
		if !ok {
			return s, false
		}
		s.Time, s.Host, rest = t, m[2], m[3]
	} else if m := reBSD.FindStringSubmatch(line); m != nil {
		mon, ok := months[m[1]]
		if !ok {
			return s, false
		}
		d, _ := strconv.Atoi(m[2])
		hh, _ := strconv.Atoi(m[3])
		mi, _ := strconv.Atoi(m[4])
		ss, _ := strconv.Atoi(m[5])
		t := time.Date(now.Year(), mon, d, hh, mi, ss, 0, time.Local)
		if t.After(now.Add(48 * time.Hour)) {
			t = t.AddDate(-1, 0, 0)
		}
		s.Time, s.Host, rest = t, m[6], m[7]
	} else {
		return s, false
	}
	if pm := reProg.FindStringSubmatch(rest); pm != nil {
		s.Program, s.PID, s.Message = pm[1], pm[2], pm[3]
	} else {
		s.Message = rest
	}
	return s, true
}

// ParseISO interpreta datas ISO-8601 com ou sem fuso e frações.
func ParseISO(v string) (time.Time, bool) {
	layouts := []string{time.RFC3339Nano, "2006-01-02T15:04:05.999999999-0700", "2006-01-02T15:04:05-0700",
		"2006-01-02T15:04:05.999999999", "2006-01-02T15:04:05", "2006-01-02 15:04:05.999999999 -0700",
		"2006-01-02 15:04:05 -0700", "2006-01-02 15:04:05.999999999", "2006-01-02 15:04:05", "2006-01-02  15:04:05"}
	for _, l := range layouts {
		var t time.Time
		var err error
		if strings.Contains(l, "-0700") || strings.Contains(l, "Z07") {
			t, err = time.Parse(l, v)
		} else {
			t, err = time.ParseInLocation(l, v, time.Local)
		}
		if err == nil {
			return t, true
		}
	}
	return time.Time{}, false
}

// HourKey devolve a chave de hora local (AAAA-MM-DDTHH).
func HourKey(t time.Time) string { return t.Local().Format("2006-01-02T15") }

// ParseHourKey converte a chave de hora em time.Time.
func ParseHourKey(k string) (time.Time, error) {
	return time.ParseInLocation("2006-01-02T15", k, time.Local)
}

// HumanBytes formata bytes.
func HumanBytes(n int64) string {
	const u = 1024
	if n < u {
		return strconv.FormatInt(n, 10) + " B"
	}
	div, exp := int64(u), 0
	for m := n / u; m >= u; m /= u {
		div *= u
		exp++
	}
	return strconv.FormatFloat(float64(n)/float64(div), 'f', 1, 64) + " " + string("KMGTPE"[exp]) + "B"
}

// Truncate corta uma string em n runas.
func Truncate(s string, n int) string {
	r := []rune(s)
	if len(r) <= n {
		return s
	}
	if n <= 1 {
		return string(r[:n])
	}
	return string(r[:n-1]) + "…"
}

// Pad completa com espaços até n runas (corta se maior).
func Pad(s string, n int) string {
	s = Truncate(s, n)
	r := len([]rune(s))
	if r < n {
		s += strings.Repeat(" ", n-r)
	}
	return s
}

// PadLeft alinha à direita.
func PadLeft(s string, n int) string {
	s = Truncate(s, n)
	r := len([]rune(s))
	if r < n {
		s = strings.Repeat(" ", n-r) + s
	}
	return s
}

// WriteFileAtomic grava um arquivo de forma atômica.
func WriteFileAtomic(path string, data []byte, perm os.FileMode) error {
	if err := os.MkdirAll(filepath.Dir(path), 0o750); err != nil {
		return err
	}
	tmp, err := os.CreateTemp(filepath.Dir(path), "."+filepath.Base(path)+".tmp*")
	if err != nil {
		return err
	}
	name := tmp.Name()
	if _, err := tmp.Write(data); err != nil {
		tmp.Close()
		os.Remove(name)
		return err
	}
	if err := tmp.Sync(); err != nil {
		tmp.Close()
		os.Remove(name)
		return err
	}
	tmp.Close()
	if err := os.Chmod(name, perm); err != nil {
		os.Remove(name)
		return err
	}
	return os.Rename(name, path)
}

// Basename do executável/comando (primeiro token).
func CmdBase(cmd string) string {
	f := strings.Fields(cmd)
	if len(f) == 0 {
		return ""
	}
	return filepath.Base(f[0])
}
