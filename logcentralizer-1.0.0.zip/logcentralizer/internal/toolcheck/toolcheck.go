// Package toolcheck verifica se as ferramentas e arquivos necessários para cada
// fonte de log estão instalados e sugere os pacotes que faltam.
package toolcheck

import (
	"fmt"
	"io"
	"os"
	"os/exec"
	"sort"
	"strings"

	"logcentralizer/internal/collectors"
	"logcentralizer/internal/config"
	"logcentralizer/internal/util"
)

// Item é o estado de um requisito.
type Item struct {
	Source  string
	Req     collectors.Requirement
	Present bool
}

// SourceState resume uma fonte.
type SourceState struct {
	ID, Name  string
	Enabled   bool
	Available bool
	Mode      string
	Notes     []string
	Items     []Item
}

// Check verifica todas as fontes.
func Check(cfg *config.Config) []SourceState {
	var out []SourceState
	for _, c := range collectors.All(cfg) {
		st := SourceState{ID: c.ID(), Name: c.Name(), Enabled: cfg.SourceEnabled(c.ID())}
		p := c.Probe(cfg)
		st.Available, st.Mode, st.Notes = p.Available, p.Mode, p.Notes
		for _, r := range c.Requirements() {
			st.Items = append(st.Items, Item{Source: c.ID(), Req: r, Present: r.Present()})
		}
		out = append(out, st)
	}
	return out
}

// MissingPackages devolve os pacotes apt que ativariam/melhorariam fontes.
// recommended = pacotes cuja ausência desativa a fonte ou um recurso importante.
func MissingPackages(states []SourceState) (recommended, optional []string) {
	rec, opt := map[string]bool{}, map[string]bool{}
	for _, s := range states {
		if !s.Enabled {
			continue
		}
		for _, it := range s.Items {
			pk := it.Req.Package
			if it.Present || pk == "" || pk == "-" || strings.Contains(pk, "|") || pk == "linux-image" || pk == "base-files" {
				continue
			}
			if isService(s.ID) {
				continue // nginx, docker, bancos: só monitoramos se o usuário já usa
			}
			if it.Req.Optional {
				opt[pk] = true
			} else {
				rec[pk] = true
			}
		}
	}
	for k := range rec {
		delete(opt, k)
	}
	return keys(rec), keys(opt)
}

func isService(id string) bool {
	switch id {
	case "nginx", "apache", "docker", "mysql", "postgresql":
		return true
	}
	return strings.HasPrefix(id, "custom:")
}

func keys(m map[string]bool) []string {
	var l []string
	for k := range m {
		l = append(l, k)
	}
	sort.Strings(l)
	return l
}

// Print escreve a tabela de verificação.
func Print(w io.Writer, states []SourceState) {
	fmt.Fprintln(w, "VERIFICAÇÃO DAS FONTES DE LOG E FERRAMENTAS")
	fmt.Fprintln(w, strings.Repeat("=", 78))
	for _, s := range states {
		status := "OK      "
		switch {
		case !s.Enabled:
			status = "DESATIV."
		case !s.Available:
			status = "AUSENTE "
		}
		fmt.Fprintf(w, "[%s] %-12s %s\n", status, s.ID, s.Name)
		if s.Mode != "" && s.Available && s.Enabled {
			fmt.Fprintf(w, "             leitura: %s\n", s.Mode)
		}
		for _, it := range s.Items {
			mark := "✔"
			if !it.Present {
				mark = "✘"
			}
			opt := ""
			if it.Req.Optional {
				opt = " (opcional)"
			}
			fmt.Fprintf(w, "             %s %-28s %s [pacote: %s]%s\n", mark, it.Req.Name, it.Req.Desc, it.Req.Package, opt)
		}
		for _, n := range s.Notes {
			fmt.Fprintf(w, "             ! %s\n", n)
		}
	}
	rec, opt := MissingPackages(states)
	fmt.Fprintln(w, strings.Repeat("-", 78))
	if len(rec) == 0 && len(opt) == 0 {
		fmt.Fprintln(w, "Todas as ferramentas recomendadas estão instaladas.")
		return
	}
	if len(rec) > 0 {
		fmt.Fprintf(w, "Recomendado instalar: sudo apt install %s\n", strings.Join(rec, " "))
	}
	if len(opt) > 0 {
		fmt.Fprintf(w, "Opcional (melhora a coleta): sudo apt install %s\n", strings.Join(opt, " "))
	}
	fmt.Fprintln(w, "Ou execute: sudo logcentralizer verificar --instalar")
}

// Install instala pacotes via apt-get (interativo).
func Install(pkgs []string, assumeYes bool) error {
	if len(pkgs) == 0 {
		return nil
	}
	if !util.CmdExists("apt-get") {
		return fmt.Errorf("apt-get não encontrado")
	}
	args := []string{"install"}
	if assumeYes {
		args = append(args, "-y")
	}
	args = append(args, pkgs...)
	cmd := exec.Command("apt-get", args...)
	cmd.Stdin, cmd.Stdout, cmd.Stderr = os.Stdin, os.Stdout, os.Stderr
	return cmd.Run()
}
