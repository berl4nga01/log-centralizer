# logcentralizer: tutorial completo

O **logcentralizer** é um centralizador de logs de linha de comando para Ubuntu (feito e testado
para o **Ubuntu 26.04 LTS** em desktop). Cada vez que você o executa, ele:

1. **Captura** os principais logs do sistema operacional, de hardware, de processos e de serviços,
   todos de uma vez (os coletores rodam em paralelo).
2. **Compara** o período atual com a **linha de base**, que é o comportamento habitual da máquina
   aprendido nas análises anteriores e no histórico de logs.
3. **Aponta anomalias**: picos de volume, força bruta, IPs, usuários, portas ou erros nunca vistos,
   arquivos críticos alterados, falhas de hardware etc. Cada uma vem com o **motivo** da
   classificação, as **evidências** e a **severidade**.
4. **Sugere soluções**, combinando uma base local (sempre disponível) com uma **pesquisa na internet**
   (DuckDuckGo sem chave, ou Brave Search API com chave).
5. **Gera um relatório TXT** em português com o histórico das últimas análises.
6. **Cria um backup** `.tar.gz` (opcionalmente criptografado) com **todos** os logs, um manifesto
   SHA-256 e um hash do arquivo para verificar a integridade.

Tudo é escrito em Go usando apenas a biblioteca padrão, sem dependências externas. O programa é um
único executável estático.

---

## Sumário

1. [Requisitos](#1-requisitos)
2. [Instalação](#2-instalação)
3. [Primeiro uso](#3-primeiro-uso)
4. [Comandos](#4-comandos)
5. [Como ler o relatório](#5-como-ler-o-relatório)
6. [Fontes de log monitoradas](#6-fontes-de-log-monitoradas)
7. [Ferramentas recomendadas (e como ativá-las)](#7-ferramentas-recomendadas-e-como-ativá-las)
8. [Personalização (config.json)](#8-personalização-configjson)
9. [Pesquisa de soluções na internet (DuckDuckGo e Brave)](#9-pesquisa-de-soluções-na-internet)
10. [Backups: criptografia, verificação e restauração](#10-backups)
11. [Regras de detecção](#11-regras-de-detecção)
12. [Teste com ataques simulados](#12-teste-com-ataques-simulados)
13. [Arquitetura e como adicionar novas fontes](#13-arquitetura-e-como-adicionar-novas-fontes)
14. [Solução de problemas](#14-solução-de-problemas)
15. [Desinstalação](#15-desinstalação)

---

## 1. Requisitos

| Item | Detalhe |
|---|---|
| Sistema | Ubuntu 26.04 LTS (também roda em 22.04/24.04 e outras distribuições com systemd) |
| Arquitetura | x86-64 (amd64) ou ARM64. Os dois binários já vêm prontos no pacote |
| Permissão | **root** (`sudo`). A ferramenta só roda como root, conforme definido |
| Go | **Não é necessário** para instalar. Só é preciso para recompilar (Go 1.24 ou mais recente; o Ubuntu 26.04 traz o Go 1.26 no pacote `golang-go`) |
| Internet | Opcional. Usada apenas para pesquisar soluções. Sem internet, vale só a base local |
| Disco | Os backups guardam uma cópia completa dos logs a cada análise e são mantidos para sempre (ver [seção 10](#10-backups)) |

---

## 2. Instalação

### 2.1 Extrair o pacote

```bash
cd ~/Downloads
unzip logcentralizer-1.0.0.zip
cd logcentralizer
```

### 2.2 Instalador automático (recomendado)

```bash
sudo ./scripts/install.sh
```

O instalador:

1. detecta a arquitetura e instala o binário pré-compilado em `/usr/local/bin/logcentralizer`
   (junto com `logcentralizer-simulador`, usado nos testes);
2. cria os diretórios:
   - `/etc/logcentralizer/` para a configuração;
   - `/var/lib/logcentralizer/` para a linha de base, o histórico e os relatórios;
   - `/var/backups/logcentralizer/` para os backups;
3. cria a configuração padrão em `/etc/logcentralizer/config.json`;
4. **verifica quais ferramentas de log estão instaladas** e oferece instalar as que faltam
   (rsyslog, auditd, ufw, fail2ban, smartmontools, acct etc.), ativando os serviços;
5. oferece ativar o firewall UFW com registro de bloqueios;
6. oferece instalar regras básicas de auditoria (`configs/auditd-logcentralizer.rules`);
7. pergunta se você quer **criptografar os backups**.

Opções do instalador:

```bash
sudo ./scripts/install.sh --sim        # responde "sim" a tudo (instalação completa sem perguntas)
sudo ./scripts/install.sh --nao        # instala só o logcentralizer, sem pacotes extras
sudo ./scripts/install.sh --compilar   # compila a partir do código-fonte em vez de usar o binário
```

### 2.3 Instalação manual (alternativa)

```bash
# 1) binário (escolha linux-amd64 ou linux-arm64)
sudo install -m 0755 bin/linux-amd64/logcentralizer /usr/local/bin/
sudo install -m 0755 bin/linux-amd64/logcentralizer-simulador /usr/local/bin/

# 2) configuração e diretórios
sudo logcentralizer config init
sudo install -d -m 0700 /var/lib/logcentralizer /var/backups/logcentralizer

# 3) verificar e instalar as ferramentas de log
sudo logcentralizer verificar
sudo logcentralizer verificar --instalar
```

### 2.4 Compilar a partir do código-fonte

```bash
sudo apt install golang-go make
make test        # roda os testes unitários
make build       # gera build/logcentralizer e build/logcentralizer-simulador
make dist        # gera os binários estáticos para amd64 e arm64 em bin/
sudo ./scripts/install.sh --compilar
```

---

## 3. Primeiro uso

```bash
sudo logcentralizer verificar      # confere as fontes e as ferramentas
sudo logcentralizer analisar       # primeira análise
sudo logcentralizer relatorio | less
```

**O que acontece na primeira análise:**

- A linha de base ainda não existe. O logcentralizer lê os logs antigos que já estão na máquina
  (até `linha_de_base.dias`, padrão de 14 dias) **só para aprender** o habitual. Depois analisa as
  últimas 24 horas (`analise.janela_inicial_horas`).
- Se o histórico disponível tiver menos de `linha_de_base.horas_minimas` horas de atividade (padrão
  de 24), a análise roda em **modo aprendizado**. As regras de *novidade* (IP, usuário, porta ou
  erro nunca vistos) e de *pico de volume* ficam desligadas. As regras de limite e assinatura
  continuam valendo (força bruta, OOM, disco cheio, erro de disco, conta com UID 0 etc.).
- Os módulos de "fotografia" (processos, portas, contas, hashes de arquivos, cron) registram o
  estado atual. Mudanças só serão apontadas **a partir da segunda análise**.

**Nas análises seguintes**, o período analisado vai **desde a última análise até agora**. Se a
máquina ficou desligada ou sem análise por muito tempo, o período é limitado a
`analise.retroativo_maximo_dias` (padrão de 7). Rode `sudo logcentralizer analisar` sempre que
quiser avaliar a máquina, por exemplo uma vez por dia.

> A execução é manual, conforme escolhido. Para automatizar no futuro, basta agendar
> `logcentralizer analisar` no cron do root (`sudo crontab -e`), por exemplo:
> `30 12 * * * /usr/local/bin/logcentralizer analisar >/dev/null 2>&1`

---

## 4. Comandos

Todos os comandos exigem `sudo`, exceto `ajuda` e `versao`.

| Comando | O que faz |
|---|---|
| `logcentralizer analisar` | Análise completa: coleta, compara com a linha de base, pesquisa soluções, gera relatório e backup |
| `  --fontes auth,kernel` | Analisa só as fontes indicadas (IDs em `logcentralizer fontes`) |
| `  --periodo 6h` | Força o período (`30m`, `6h`, `3d`) em vez de "desde a última análise" |
| `  --sem-backup` | Não gera backup nesta execução |
| `  --sem-internet` | Não pesquisa na internet (usa só a base local) |
| `  --imprimir` | Mostra o relatório completo no terminal ao terminar |
| `  --codigo-saida` | Sai com código 2 (ATENÇÃO) ou 3 (ANORMAL), útil em scripts |
| `  --verbose` | Mostra detalhes da coleta e das consultas web |
| `logcentralizer verificar` | Mostra, para cada fonte, quais ferramentas ou arquivos estão presentes (✔) ou faltando (✘), com o pacote apt correspondente |
| `logcentralizer verificar --instalar [-y]` | Instala os pacotes que faltam |
| `logcentralizer fontes` | Lista as fontes e como cada uma está sendo lida |
| `logcentralizer relatorio` | Mostra o último relatório |
| `logcentralizer relatorio --lista` | Lista os relatórios salvos |
| `logcentralizer relatorio <arquivo>` | Mostra um relatório específico |
| `logcentralizer historico [-n 20]` | Resumo das análises anteriores |
| `logcentralizer backup listar` | Lista os backups e o espaço livre |
| `logcentralizer backup verificar` | Confere o SHA-256 de todos os backups |
| `logcentralizer backup criar` | Cria um backup agora, sem análise |
| `logcentralizer backup descriptografar <arq.enc> [--saida x.tar.gz]` | Abre um backup criptografado |
| `logcentralizer linha-de-base status` | Mostra o que é considerado habitual (médias por fonte, entidades conhecidas) |
| `logcentralizer linha-de-base resetar` | Apaga o aprendizado (guarda uma cópia) |
| `logcentralizer config init [--forcar]` | Cria o arquivo de configuração padrão |
| `logcentralizer config mostrar` | Mostra a configuração efetiva |
| `logcentralizer config validar` | Valida o `config.json` |
| `logcentralizer config sensibilidade baixa\|media\|alta` | Altera a sensibilidade |
| `logcentralizer config criptografia ativar\|desativar` | Liga ou desliga a criptografia (gera a senha automaticamente) |
| `logcentralizer config brave-chave <CHAVE>\|remover` | Grava ou remove a chave da Brave Search API |

Opção global: `--config /caminho/outro.json` usa outro arquivo de configuração.

---

## 5. Como ler o relatório

Os relatórios ficam em `/var/lib/logcentralizer/relatorios/relatorio_AAAAMMDD_HHMMSS.txt`.
`ultimo_relatorio.txt` aponta para o mais recente. As seções são:

1. **Veredito**
   - **NORMAL**: nada fora do habitual.
   - **NORMAL (com observações)**: só anomalias de severidade BAIXA.
   - **ATENÇÃO**: há anomalias de severidade MÉDIA para conferir.
   - **ANORMAL**: há anomalias ALTAS ou CRÍTICAS para tratar agora.

   A seção mostra também a contagem por severidade e se a análise rodou em modo aprendizado.
2. **Anomalias detectadas**: uma ficha para cada anomalia com:
   - regra, fontes, período e número de ocorrências;
   - **Por que é anomalia**: a comparação com a linha de base ou o limite configurado;
   - **Evidências**: linhas reais do log;
   - **Solução sugerida**: passos com comandos e referências oficiais (manpages do Ubuntu 26.04 e
     documentação do kernel, do Docker e outras);
   - **Pesquisa na internet**: links encontrados para o problema.
3. **Fontes monitoradas**: tabela *atual × habitual* com eventos por hora de atividade, média
   habitual e variação em %, mais o modo de leitura, erros e observações de cada fonte.
4. **Estado atual da máquina**: discos, memória, carga, temperatura, SMART, bateria e processos.
5. **Ferramentas de monitoramento**: pacotes que faltam e status da pesquisa web.
6. **Histórico das últimas N análises** (N configurável): eventos e anomalias por severidade em
   cada análise, mais **tendência** (piorou, melhorou ou estável) e **anomalias recorrentes**.
7. **Backup**: arquivo, tamanho, SHA-256, criptografia, arquivos ignorados e espaço livre.
8. **Linha de base**: quantas horas de atividade, modelos de erro e entidades (IPs, usuários,
   portas, executáveis etc.) já são conhecidos.

**Severidades:** `CRITICA` > `ALTA` > `MEDIA` > `BAIXA` > `INFO`. O nível INFO fica oculto, a menos
que você ative `relatorio.mostrar_info`.

---

## 6. Fontes de log monitoradas

Cada fonte verifica sozinha se as ferramentas necessárias existem. Quando falta um arquivo de texto,
ela usa o journal como alternativa (por exemplo, auth.log ausente → journal com as facilidades
auth/authpriv). Para ver o estado de cada fonte, use `sudo logcentralizer verificar`.

| ID | Fonte | Como lê |
|---|---|---|
| `journald` | journald/systemd: serviços que falharam, reinícios em loop, core dumps, erros gerais | `journalctl -o json` |
| `syslog` | `/var/log/syslog` (eventos gerais) | arquivo, incluindo os rotacionados `.1` e `.gz` |
| `auth` | SSH, sudo/sudo-rs, su, PAM (gdm/login), criação e alteração de contas e senhas | `auth.log` ou journal |
| `kernel` | kern.log/dmesg: OOM, segfault, BUG/Oops, erros de disco e sistema de arquivos, hardware (MCE, AER, temperatura), USB | journal (todos os boots), kern.log ou dmesg |
| `logins` | wtmp/wtmpdb (logins), btmp (falhas), lastlog/lastlog2 | `last`, `lastb`, `lastlog2` |
| `pacotes` | apt e dpkg: instalações e remoções | `/var/log/apt/history.log`, `/var/log/dpkg.log` |
| `ufw` | firewall: bloqueios e varreduras de porta | `ufw.log` ou journal |
| `auditd` | auditoria do kernel: ANOM_*, falhas, mudanças de regras, chaves | `/var/log/audit/audit.log` |
| `apparmor` | negações de perfil AppArmor | audit.log ou journal |
| `cron` | execuções do cron, arquivos de crontab e timers do systemd | journal + hash dos arquivos + `systemctl list-timers` |
| `fail2ban` | banimentos | `/var/log/fail2ban.log` |
| `nginx` / `apache` | acessos (varreduras, 404, 5xx) e erros | access.log e error.log |
| `docker` | containers que caíram, OOM, reinícios, imagens novas | `docker events` + journal |
| `mysql` / `postgresql` | falhas de login, travamentos, corrupção | logs de erro |
| `hardware` | temperaturas (hwmon), SMART (`smartctl`), EDAC/ECC, bateria, smartd/rasdaemon | `/sys` + smartctl + journal |
| `recursos` | disco, inodes, memória, swap, carga | `/proc` e `statfs` |
| `processos` | processos do SO: executáveis em /tmp, memfd (fileless), binários apagados, programas novos como root, portas em escuta, CPU e memória | `/proc` |
| `acct` | contabilidade de processos: todos os comandos executados | `lastcomm` (pacote acct) |
| `integridade` | SHA-256 de arquivos críticos (passwd, shadow, sudoers, sshd_config, PAM, authorized_keys, unidades systemd, sources.list) e contas UID 0 | leitura direta |
| `crash` | relatórios de travamento do apport | `/var/crash` |
| `custom:<nome>` | logs da sua aplicação | ver [8.6](#86-logs-de-aplicações-próprias) |

Fontes de serviços que você não usa (nginx, apache, docker, bancos) aparecem como "ausente" e não
atrapalham em nada.

---

## 7. Ferramentas recomendadas (e como ativá-las)

`sudo logcentralizer verificar --instalar` instala tudo de uma vez. Para fazer manualmente:

```bash
sudo apt install rsyslog auditd ufw fail2ban smartmontools acct apparmor apparmor-utils \
                 lm-sensors rasdaemon lastlog2
```

| Pacote | Para que serve | Pós-instalação |
|---|---|---|
| `rsyslog` | arquivos de texto `/var/log/syslog`, `auth.log`, `kern.log` e `ufw.log` (o Ubuntu 26.04 pode vir só com o journal) | `sudo systemctl enable --now rsyslog` |
| `auditd` | auditoria detalhada do kernel | `sudo systemctl enable --now auditd`. Regras sugeridas: `sudo cp configs/auditd-logcentralizer.rules /etc/audit/rules.d/logcentralizer.rules && sudo augenrules --load` |
| `ufw` | firewall com registro de bloqueios | `sudo ufw enable && sudo ufw logging on` |
| `fail2ban` | bloqueio automático de força bruta | `sudo systemctl enable --now fail2ban` |
| `smartmontools` | saúde dos discos (SMART) | `sudo systemctl enable --now smartmontools` |
| `acct` | registro de todos os comandos executados | `sudo systemctl enable --now acct` |
| `lm-sensors` | detecção extra de sensores | `sudo sensors-detect` |
| `rasdaemon` | registro de erros de hardware (MCE/ECC) | `sudo systemctl enable --now rasdaemon` |

**Journal persistente.** No Ubuntu desktop o journal já é persistente (`/var/log/journal`). Se não
for, ative assim:

```bash
sudo mkdir -p /var/log/journal && sudo systemctl restart systemd-journald
```

---

## 8. Personalização (config.json)

O arquivo fica em `/etc/logcentralizer/config.json`. Edite com `sudo nano` e valide com
`sudo logcentralizer config validar`. Chaves ausentes assumem o valor padrão, então você pode
manter no arquivo só o que alterou. Há um exemplo completo em `configs/config.exemplo.json`.

### 8.1 Geral e análise

| Chave | Padrão | Significado |
|---|---|---|
| `nome_host` | (hostname) | Nome que aparece no relatório e no backup |
| `diretorio_dados` | `/var/lib/logcentralizer` | Linha de base, histórico e cache |
| `diretorio_relatorios` | `/var/lib/logcentralizer/relatorios` | Relatórios TXT |
| `analise.janela_inicial_horas` | 24 | Período da primeira análise |
| `analise.retroativo_maximo_dias` | 7 | Limite do período quando a última análise é muito antiga |
| `analise.timeout_fonte_segundos` | 300 | Tempo máximo de leitura de cada fonte |
| `analise.max_amostras_por_anomalia` | 5 | Linhas de evidência por anomalia |

### 8.2 Linha de base (o "habitual")

| Chave | Padrão | Significado |
|---|---|---|
| `linha_de_base.dias` | 14 | Janela do histórico comparado (7, 14 ou 30 dias, por exemplo) |
| `linha_de_base.horas_minimas` | 24 | Horas de atividade necessárias para sair do modo aprendizado |
| `linha_de_base.retencao_entidades_dias` | 90 | Por quanto tempo um IP, usuário ou porta continua "conhecido" sem aparecer |
| `linha_de_base.aprender_com_anomalias` | false | Se `false`, horas com pico de volume não entram na média, e IPs de força bruta e itens de anomalias CRÍTICAS continuam sendo tratados como novidade |
| `linha_de_base.max_modelos_por_fonte` | 5000 | Limite de modelos de mensagem de erro guardados |

### 8.3 Sensibilidade e regras

```json
"deteccao": {
  "sensibilidade": "media",
  "sensibilidade_personalizada": {"zscore": 0, "minimo_eventos": 0, "fator_multiplicador": 0},
  "regras_desativadas": ["bateria_degradada"],
  "severidade_personalizada": {"sudo_novo_comando": "INFO", "login_fora_horario": "ALTA"}
}
```

- **Sensibilidade** do pico de volume. Uma hora é anômala quando
  `contagem > máx(média + Z × desvio, média × fator)` e `contagem ≥ mínimo`:

  | Nível | Z | Mínimo de eventos | Fator |
  |---|---|---|---|
  | `baixa` | 4 | 50 | 5× |
  | `media` (padrão) | 3 | 20 | 3× |
  | `alta` | 2 | 10 | 2× |

  Em `sensibilidade_personalizada`, qualquer valor diferente de 0 substitui o do nível escolhido.
- **`regras_desativadas`**: lista de IDs de regras ([seção 11](#11-regras-de-detecção)).
- **`severidade_personalizada`**: muda a severidade de uma regra (`INFO`, `BAIXA`, `MEDIA`, `ALTA`,
  `CRITICA`).

### 8.4 Limites e janelas

| Chave | Padrão | Significado |
|---|---|---|
| `forca_bruta_ssh` | 5 falhas / 10 min | Força bruta SSH por IP |
| `forca_bruta_local` | 5 / 10 min | Falhas de login local (gdm, tty), su e auditd |
| `forca_bruta_sudo` | 3 / 10 min | Senha errada no sudo |
| `horario_login` | 07:00–23:59, todos os dias | **Seu horário habitual**; logins fora dele são anomalia. `dias_semana`: 0 = domingo … 6 = sábado. Aceita janelas que atravessam a meia-noite (ex.: 22:00–06:00) |
| `janela_manutencao_pacotes` | 08:00–22:00 | Instalações e remoções fora dessa janela são anomalia |
| `varredura_portas` | 15 portas / 5 min | Varredura detectada no UFW |
| `web.erros_5xx_por_hora` | 50 | Erros 5xx por hora |
| `web.requisicoes_404_por_ip` | 100 | Respostas 404 por IP |
| `web.assinaturas_scanner_por_ip` | 5 | Requisições com assinatura de ataque por IP |
| `limites.disco_percentual` / `inodes_percentual` | 90 | Disco ou inodes quase cheios |
| `limites.memoria_livre_percentual_minima` | 5 | Memória disponível baixa |
| `limites.swap_percentual` | 80 | Uso de swap |
| `limites.temperatura_celsius` | 85 | Temperatura alta (também usa o limite crítico do sensor) |
| `limites.cpu_processo_percentual` | 90 | Processo com CPU alta |
| `limites.memoria_processo_percentual` | 50 | Processo usando grande parte da RAM |
| `limites.carga_por_cpu` | 4 | Carga média por núcleo |
| `limites.zumbis` | 20 | Processos zumbis |
| `limites.bateria_saude_minima` | 60 | % da capacidade original da bateria |
| `limites.segfaults_mesmo_processo` | 5 | Segfaults repetidos que elevam a severidade |
| `limites.reinicio_servico_contador` | 5 | Reinícios seguidos de um serviço |
| `limites.reinicios_container` | 3 | Reinícios de um container |
| `limites.falhas_autenticacao_banco` | 10 | Logins recusados no banco por hora |
| `limites.fonte_silenciosa_media_minima` / `_horas_minimas` | 5 / 6 | Uma fonte que costuma registrar ≥ 5 eventos/h e ficou ≥ 6 horas de atividade sem nada |
| `comandos_suspeitos` | nc, nmap, socat, hydra, xmrig… | Ferramentas que geram alerta ao rodar |
| `diretorios_suspeitos` | /tmp, /var/tmp, /dev/shm | Processos executando daqui são anomalia (AppImages em `/tmp/.mount_*` são ignorados) |
| `chaves_auditd_alerta` | [] | Chaves de regras auditd que geram alerta |
| `arquivos_integridade` | passwd, shadow, sudoers… | Arquivos cujo SHA-256 é monitorado (aceita `*`) |
| `servicos_login_interativo` | sshd, gdm-password, login… | Serviços PAM considerados login interativo |

### 8.5 Lista branca (ignorar)

```json
"lista_branca": {
  "ips": ["127.0.0.1", "::1", "192.168.1.0/24"],
  "usuarios": ["backup"],
  "padroes_regex": ["gnome-shell.*Window manager warning", "pulseaudio.*"],
  "unidades_systemd": ["fwupd-refresh.service"],
  "portas": ["8080"],
  "processos": ["/opt/meu-app/bin/servidor", "ollama"],
  "pacotes": ["google-chrome-stable"]
}
```

- `ips` aceita CIDR. IPs, usuários, processos, portas, unidades e pacotes da lista **não disparam
  regras**, mas continuam sendo contados.
- Mensagens que casam com `padroes_regex` são **descartadas** (nem contam no volume).

### 8.6 Fontes: ativar, desativar e trocar caminhos

```json
"fontes": {
  "nginx":  {"ativo": false},
  "auth":   {"modo": "journal"},
  "syslog": {"caminhos": ["/var/log/syslog"]},
  "mysql":  {"caminhos": ["/srv/mysql/logs/error.log"]}
}
```

`modo` aceita `auto` (padrão: arquivo se existir, senão journal), `arquivo` ou `journal`.

### 8.7 Logs de aplicações próprias

```json
"fontes_personalizadas": [
  {"nome": "minha_api", "caminho": "/var/log/minha_api/*.log", "formato": "json",
   "campo_tempo": "time", "campo_mensagem": "msg", "campo_nivel": "level"},
  {"nome": "legado", "caminho": "/opt/legado/app.log", "formato": "texto"},
  {"nome": "worker", "caminho": "/var/log/worker.log", "formato": "regex",
   "regex": "^(?P<time>\\S+ \\S+) \\[(?P<level>\\w+)\\] (?P<message>.*)$",
   "layout_tempo": "2006-01-02 15:04:05"},
  {"nome": "app_syslog", "caminho": "/var/log/app_syslog.log", "formato": "syslog"}
]
```

- `texto`: linhas que começam com data ISO (`2026-11-05 10:00:00` ou `2026-11-05T10:00:00Z`).
  O nível (ERROR, WARN…) é detectado quando vem logo após a data.
- `json`: uma linha JSON por evento. O tempo pode ser ISO ou epoch.
- `regex`: grupos nomeados `time`, `level` e `message`. `layout_tempo` usa o formato de data do Go
  (`2006-01-02 15:04:05`).
- `syslog`: formato syslog tradicional.

Essas fontes ganham automaticamente pico de volume, fonte silenciosa, erro nunca visto e proteção
contra truncamento.

### 8.8 Relatório

| Chave | Padrão | Significado |
|---|---|---|
| `relatorio.analises_no_historico` | 10 | Quantas análises anteriores aparecem no comparativo |
| `relatorio.max_anomalias_detalhadas` | 60 | Fichas completas (as demais saem em resumo) |
| `relatorio.mostrar_info` | false | Exibe observações de nível INFO |
| `relatorio.historico_maximo_registros` | 1000 | Tamanho do `historico.json` |
| `relatorio.retencao_relatorios_dias` | 0 | 0 = guardar todos os relatórios |
| `relatorio.largura_linha` | 100 | Largura do texto |

---

## 9. Pesquisa de soluções na internet

Para cada anomalia, o relatório sempre traz a **solução da base local**. Além disso, as anomalias
com severidade a partir de `busca_web.severidade_minima` (padrão `MEDIA`) recebem links pesquisados
na internet.

```json
"busca_web": {
  "ativo": true,
  "provedores": ["brave", "duckduckgo"],
  "brave_chave_api": "",
  "max_buscas_por_execucao": 8,
  "resultados_por_busca": 3,
  "timeout_segundos": 10,
  "cache_dias": 7,
  "idioma": "pt-BR",
  "severidade_minima": "MEDIA",
  "proxy": ""
}
```

- Os provedores são tentados **na ordem da lista**. O Brave é pulado enquanto não houver chave.
- **DuckDuckGo** funciona sem chave, mas pode limitar consultas automáticas. Quando isso acontece, o
  relatório informa e mantém a base local.
- Os resultados ficam em cache por `cache_dias` para não repetir consultas.
- Se duas consultas seguidas falharem por falta de rede, a pesquisa é interrompida naquela execução.
- `proxy`: ex. `http://proxy.empresa:3128`. A variável `HTTPS_PROXY` também é respeitada.
- Para não usar a internet numa execução: `sudo logcentralizer analisar --sem-internet`.

### 9.1 Como obter a chave da Brave Search API

Passos conforme a documentação da Brave em novembro de 2026. Os planos mudam com frequência,
então confira no próprio painel antes de contratar.

1. Acesse **https://api-dashboard.search.brave.com** e crie uma conta (e-mail e senha).
2. Confirme o e-mail pelo link que a Brave enviar.
3. No painel, abra **Plans** (Planos) e ative o plano de pesquisa (**Search**). Hoje ele funciona com
   créditos pré-pagos e inclui **US$ 5 de crédito grátis por mês**, o que dá cerca de **1.000
   consultas/mês**. A Brave **pede um cartão de crédito** para ativar o plano, mesmo usando só o
   crédito gratuito. O logcentralizer faz no máximo `max_buscas_por_execucao` consultas por análise
   (padrão de 8) e guarda os resultados em cache, então uma análise diária cabe com folga no crédito
   gratuito.
4. Vá em **API Keys**, clique para **criar uma chave**, dê um nome (ex.: `logcentralizer`) e copie
   o valor.
5. Grave a chave:

   ```bash
   sudo logcentralizer config brave-chave COLE_A_CHAVE_AQUI
   ```

6. Teste: `sudo logcentralizer analisar --verbose` mostra as consultas feitas (`[busca] ...`) e o
   relatório indica o motor usado em cada link (`[brave]`).

A chave fica só em `/etc/logcentralizer/config.json`, com permissão 0600 (somente root), e o
`config mostrar` a exibe mascarada. Para removê-la: `sudo logcentralizer config brave-chave remover`.

---

## 10. Backups

Ao final de **cada análise** é criado em `/var/backups/logcentralizer/`:

```
logcentralizer_<host>_AAAAMMDD_HHMMSS.tar.gz        (ou .tar.gz.enc, se criptografado)
logcentralizer_<host>_AAAAMMDD_HHMMSS.tar.gz.sha256 (hash do arquivo, formato sha256sum)
```

**Conteúdo do backup.** Cada backup é uma **recapitulação geral**, não um incremento:

- todo o `/var/log`, inclusive os arquivos rotacionados;
- `/var/lib/lastlog` e `/var/crash`;
- o estado do logcentralizer (linha de base, histórico e todos os relatórios), que embasa as decisões;
- uma **exportação em texto do journal completo** (`journal/journal_exportado.log`). O journal
  binário (`/var/log/journal`) fica de fora por padrão, porque já vai exportado;
- `MANIFESTO.sha256` com o hash de cada arquivo e um `LEIA-ME.txt` com o veredito da análise.

**Retenção: para sempre.** O padrão é `retencao_dias: 0` e `max_backups: 0`. Como cada backup é
completo, o espaço usado cresce a cada análise. O logcentralizer:

- **cancela o backup** se o espaço livre ficar abaixo de `espaco_livre_minimo_percentual` (10%);
- avisa no relatório quando o destino estiver com menos de 25% livre.

Se quiser limitar, defina `retencao_dias` (ex.: 90) ou `max_backups` (ex.: 60). Outra opção é
apontar `diretorio` para um HD externo.

| Chave | Padrão | Significado |
|---|---|---|
| `backup.ativo` | true | Gera backup em cada análise |
| `backup.diretorio` | `/var/backups/logcentralizer` | Destino (fora de `/var/log`) |
| `backup.retencao_dias` / `max_backups` | 0 / 0 | 0 = manter sempre |
| `backup.caminhos` | `/var/log`, `/var/lib/lastlog`, `/var/crash` | O que copiar |
| `backup.excluir` | `/var/log/journal` | O que não copiar (aceita padrões) |
| `backup.exportacao_journal` | `completa` | `completa`, `periodo` (só o período analisado) ou `nenhuma` |
| `backup.tamanho_max_arquivo_mb` | 2048 | Arquivos maiores são ignorados e listados no relatório |
| `backup.espaco_livre_minimo_percentual` | 10 | Abaixo disso o backup é cancelado |
| `backup.criptografia.ativo` | false | Criptografia AES-256-GCM |
| `backup.criptografia.arquivo_senha` | `/etc/logcentralizer/backup.key` | Arquivo com a senha (mínimo de 12 caracteres) |

### 10.1 Criptografia

```bash
sudo logcentralizer config criptografia ativar
```

O comando gera uma senha aleatória em `/etc/logcentralizer/backup.key` (0600) e ativa a
criptografia. A chave é derivada com PBKDF2-SHA256 (600 mil iterações) e os dados são cifrados com
AES-256-GCM em blocos autenticados, o que detecta adulteração e truncamento.

> **Guarde uma cópia da senha fora da máquina** (gerenciador de senhas ou pendrive). Sem ela, os
> backups criptografados não podem ser abertos.

### 10.2 Verificar a integridade

```bash
sudo logcentralizer backup verificar      # compara com os arquivos .sha256
cd /var/backups/logcentralizer && sudo sha256sum -c logcentralizer_*.sha256   # equivalente manual
```

### 10.3 Restaurar ou consultar

```bash
# (se criptografado) descriptografar
sudo logcentralizer backup descriptografar /var/backups/logcentralizer/ARQUIVO.tar.gz.enc --saida /tmp/restauro.tar.gz

# extrair em uma pasta separada (nunca por cima do /var/log em uso)
mkdir -p /tmp/restauro && sudo tar -xzf /tmp/restauro.tar.gz -C /tmp/restauro
cd /tmp/restauro && sudo sha256sum -c MANIFESTO.sha256      # confere arquivo por arquivo
less /tmp/restauro/var/log/auth.log
```

O logcentralizer **nunca apaga nem altera os logs originais**. A rotação continua a cargo do
logrotate e do journald.

---

## 11. Regras de detecção

**Tipos de regra:**

- **Linha de base**: compara com o habitual e depende de histórico. São as regras de volume, os
  itens "nunca visto" e "novo", a fonte silenciosa e as alterações de arquivos.
- **Limite/assinatura**: valem desde a primeira análise.

Para desativar uma regra, use `deteccao.regras_desativadas`. Para mudar a severidade, use
`deteccao.severidade_personalizada`.

| Regra | Severidade padrão | Detecta |
|---|---|---|
| `volume_pico` | MÉDIA/ALTA | Hora com volume de eventos acima do habitual (por fonte e hora do dia) |
| `fonte_silenciosa` | MÉDIA | Fonte que sempre registra e ficou muda |
| `log_truncado` / `log_removido` | ALTA | Log que encolheu sem rotação ou sumiu (ocultação de rastros) |
| `erro_novo` | BAIXA/MÉDIA | Modelo de mensagem de erro nunca visto |
| `ssh_forca_bruta` | ALTA | N falhas SSH de um IP em X minutos |
| `ssh_sucesso_apos_forca_bruta` | **CRÍTICA** | Login aceito do mesmo IP após a força bruta |
| `ssh_login_root` | ALTA | Root entrando direto por SSH |
| `login_novo_ip` / `login_novo_usuario` | MÉDIA (IP novo com usuário root: ALTA) | Login de IP ou usuário nunca visto |
| `login_fora_horario` | MÉDIA | Login fora de `horario_login` |
| `login_falhas_repetidas` | MÉDIA | Falhas seguidas de login local |
| `sudo_novo_usuario` / `sudo_novo_comando` | MÉDIA / BAIXA | Primeiro uso de sudo, comando sudo inédito |
| `sudo_falhas` / `sudo_nao_autorizado` | MÉDIA / ALTA | Senhas erradas, usuário fora do sudoers |
| `su_falhas` / `su_novo` | MÉDIA / BAIXA | Tentativas e trocas de usuário inéditas |
| `usuario_criado` | ALTA (CRÍTICA se UID 0) | Conta nova (por log ou por /etc/passwd) |
| `usuario_uid0` | **CRÍTICA** | Conta extra com UID 0 |
| `usuario_privilegio` | ALTA | Usuário incluído em sudo/adm/docker/lxd… |
| `usuario_modificado` / `usuario_removido` / `grupo_criado` / `senha_alterada` | BAIXA–MÉDIA | Alterações de contas |
| `conta_sistema_login` | ALTA | Conta de serviço (UID < 1000) com login |
| `servico_falhou` / `servico_reinicio_loop` | MÉDIA (BAIXA se recorrente) / ALTA | Unidades systemd com falha ou em loop |
| `core_dump` / `crash_aplicacao` / `segfault` | MÉDIA / BAIXA / BAIXA | Travamentos de programas |
| `oom` | ALTA | Kernel matou processo por falta de memória |
| `kernel_erro` | ALTA | BUG, Oops, lockup, tarefa travada |
| `hardware_erro` | ALTA (MÉDIA para throttling/ACPI) | MCE, PCIe AER, EDAC, térmico, smartd, rasdaemon |
| `disco_io_erro` | ALTA (CRÍTICA se remontou read-only) | Erros de E/S, EXT4/BTRFS/XFS, NVMe, ATA |
| `smart_falha` / `smart_setores` / `smart_desgaste` | CRÍTICA / ALTA / MÉDIA | Saúde SMART dos discos |
| `memoria_ecc_erro` | CRÍTICA / MÉDIA | Erros ECC não corrigidos ou corrigidos |
| `temperatura_alta` | MÉDIA/ALTA | Sensores acima do limite |
| `disco_cheio` / `inodes_cheio` | ALTA (CRÍTICA ≥ 98%) | Espaço ou inodes esgotando |
| `memoria_baixa` / `swap_alto` / `carga_alta` | ALTA / MÉDIA / MÉDIA | Recursos |
| `bateria_degradada` | BAIXA | Bateria abaixo da saúde mínima |
| `usb_novo_dispositivo` | BAIXA | Dispositivo USB nunca conectado (BadUSB) |
| `firewall_varredura` | MÉDIA/ALTA | Varredura de portas |
| `firewall_inativo` | BAIXA | UFW instalado e desativado |
| `fail2ban_banimento` | MÉDIA/ALTA | IPs banidos |
| `apparmor_negacao` | MÉDIA | Negação AppArmor inédita |
| `auditd_anomalia` / `auditd_config_alterada` / `auditd_chave` / `auditd_falhas` | ALTA / MÉDIA / MÉDIA / BAIXA | Eventos de auditoria |
| `cron_novo_comando` / `cron_novo_arquivo` / `cron_arquivo_alterado` / `timer_novo` | MÉDIA / MÉDIA / MÉDIA / BAIXA | Persistência por agendamento |
| `pacote_fora_janela` / `pacote_suspeito` / `pacote_seguranca_removido` | MÉDIA / MÉDIA / ALTA | apt fora de hora, ferramenta ofensiva instalada, auditd/ufw/rsyslog removido |
| `web_scanner` / `web_404_ip` / `web_5xx` | MÉDIA/ALTA / MÉDIA / MÉDIA | Ataques e erros web |
| `docker_container_falhou` / `docker_oom` / `docker_reinicios` / `docker_imagem_nova` | MÉDIA / ALTA / MÉDIA / BAIXA | Containers |
| `db_falhas_autenticacao` / `db_falha_critica` | MÉDIA / ALTA | Bancos de dados |
| `processo_sem_arquivo` | **CRÍTICA** | Processo rodando de memfd (malware fileless) |
| `processo_local_suspeito` | ALTA | Executável em /tmp, /var/tmp ou /dev/shm |
| `processo_binario_apagado` | ALTA (INFO se for do sistema após atualização) | Executável apagado do disco |
| `processo_root_novo` | BAIXA | Programa novo rodando como root |
| `processo_cpu_alta` / `processo_memoria_alta` / `processos_zumbis` | BAIXA / MÉDIA / BAIXA | Consumo |
| `porta_nova` | MÉDIA (BAIXA se só local) | Nova porta em escuta |
| `comando_suspeito` | MÉDIA/ALTA | Ferramenta da lista de suspeitos executando ou escutando |
| `integridade_arquivo_alterado` / `integridade_arquivo_novo` | MÉDIA–ALTA | Hash de arquivo crítico mudou |
| `chave_ssh_alterada` | ALTA | authorized_keys novo ou alterado |
| `ld_preload` | **CRÍTICA** | `/etc/ld.so.preload` em uso (rootkit) |

---

## 12. Teste com ataques simulados

Para comprovar que a detecção funciona **sem tocar nos seus logs reais**:

```bash
sudo ./scripts/teste_simulado.sh            # usa /tmp/logcentralizer-teste
sudo ./scripts/teste_simulado.sh /tmp/x --sem-internet
```

O script:

1. gera 14 dias de logs de um desktop "normal" (syslog, auth, kernel, ufw, apt, nginx, auditd, mysql);
2. roda a primeira análise, que deve dar **NORMAL**;
3. injeta incidentes:
   - força bruta SSH seguida de login aceito;
   - login root de IP novo;
   - conta UID 0 e usuário incluído no sudo;
   - sudo negado e `nc` executado via sudo;
   - varredura de portas;
   - serviço em loop;
   - OOM, erro EXT4 e segfault;
   - teclado USB desconhecido;
   - nmap instalado de madrugada e auditd removido;
   - ataque web e erros 502;
   - fail2ban, ANOM_PROMISCUOUS e força bruta no MySQL;
   - truncamento de log;
4. roda a segunda análise, que deve dar **ANORMAL**, com cerca de 35 anomalias.

O teste usa um `config.json` próprio dentro da pasta de teste. Para ver o relatório gerado:

```bash
sudo logcentralizer --config /tmp/logcentralizer-teste/config.json relatorio | less
sudo rm -rf /tmp/logcentralizer-teste     # limpar
```

---

## 13. Arquitetura e como adicionar novas fontes

```
cmd/logcentralizer/      CLI (analisar, verificar, backup, config...)
cmd/simulador/           gerador de logs sintéticos para testes
internal/collectors/     um coletor por fonte (interface Collector) + registro em All()
internal/analyzer/       linha de base × período atual, regras de detecção, volume, silêncio, truncamento
internal/store/          persistência JSON: linha de base, histórico, cache de busca
internal/solutions/      base local de soluções + pesquisa web (Brave/DuckDuckGo)
internal/backup/         tar.gz + manifesto SHA-256 + criptografia AES-256-GCM
internal/report/         relatório TXT
internal/toolcheck/      verificação de ferramentas instaladas
internal/config/         configuração JSON com valores padrão e validação
```

**Fluxo:**

1. Os coletores rodam em paralelo (até 6 ao mesmo tempo) e enviam eventos normalizados por um canal.
2. Um único consumidor atualiza as contagens por hora e aplica as regras em fluxo contínuo, sem
   carregar todos os logs na memória.
3. No pós-processamento entram as janelas deslizantes (força bruta, varredura), o pico de volume,
   o silêncio e o truncamento.
4. O que foi visto passa a fazer parte da linha de base.

**Para adicionar uma fonte nova:**

1. Crie um tipo em `internal/collectors/` que implemente `Collector`: `ID`, `Name`, `Category`,
   `Requirements`, `Probe`, `Collect`, `SnapshotOnly` e `WatchedFiles`. Embutir `base` já fornece
   os padrões.
2. Em `Collect`, emita `model.Event` com `Kind` e campos (`F`) para as regras semânticas. Eventos sem
   `Kind` já recebem automaticamente volume, silêncio, erro novo e truncamento.
3. Registre o coletor em `All()`.
4. Para regras específicas, adicione um `case` em `internal/analyzer/rules.go` e a solução em
   `internal/solutions/kb.go`. O teste `TestKBCoversRules` confere se toda regra tem solução.

---

## 14. Solução de problemas

| Sintoma | Causa e solução |
|---|---|
| `este comando precisa ser executado como root` | Use `sudo` |
| Muitas fontes "ausente" | Normal para serviços que você não usa. Para as de sistema, rode `sudo logcentralizer verificar --instalar` |
| "MODO APRENDIZADO" em toda análise | Pouco histórico de atividade (máquina recém-instalada, journal não persistente). Ative o journal persistente e rode por alguns dias, ou reduza `linha_de_base.horas_minimas` |
| Muitos alertas `erro_novo` no começo | Esperado nas primeiras análises: cada modelo de erro só alerta na primeira vez. Ruídos conhecidos podem ir para `lista_branca.padroes_regex` |
| Muitos picos de volume | Use `config sensibilidade baixa` ou aumente `sensibilidade_personalizada.minimo_eventos` |
| `login_fora_horario` indevido | Ajuste `deteccao.horario_login` para o seu horário |
| Pesquisa web "não realizada" | Sem internet, DuckDuckGo limitando ou proxy. Configure a Brave ([9.1](#91-como-obter-a-chave-da-brave-search-api)) ou use `--sem-internet` |
| `backup cancelado: apenas X% livre` | Libere espaço, mova `backup.diretorio` para outro disco ou defina `retencao_dias` |
| `já existe uma análise em andamento` | Outra execução está rodando; aguarde. Se travou, apague `/run/logcentralizer.lock` |
| Fonte com "tempo limite excedido" | Aumente `analise.timeout_fonte_segundos` (logs muito grandes na primeira execução) |
| Quero recomeçar o aprendizado | `sudo logcentralizer linha-de-base resetar` |

Para diagnosticar, rode `sudo logcentralizer analisar --verbose --sem-backup`.

---

## 15. Desinstalação

```bash
sudo ./scripts/uninstall.sh
```

O script remove os binários e **pergunta** antes de apagar a configuração (inclusive a senha dos
backups), os dados e relatórios, os backups e as regras de auditoria. Os pacotes do sistema (ufw,
auditd etc.) são mantidos.
