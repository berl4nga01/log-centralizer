package analyzer

import (
	"fmt"
	"math"
	"os"
	"regexp"
	"sort"
	"strconv"
	"strings"
	"syscall"
	"time"

	"logcentralizer/internal/collectors"
	"logcentralizer/internal/config"
	"logcentralizer/internal/model"
	"logcentralizer/internal/store"
	"logcentralizer/internal/util"
)

func atof(s string) float64 { v, _ := strconv.ParseFloat(s, 64); return v }
func atoi(s string) int     { v, _ := strconv.Atoi(s); return v }

var privilegedGroups = map[string]bool{"sudo": true, "admin": true, "adm": true, "root": true, "wheel": true,
	"docker": true, "lxd": true, "disk": true, "shadow": true, "systemd-journal": false}

var securityPackages = map[string]bool{"auditd": true, "apparmor": true, "ufw": true, "fail2ban": true,
	"rsyslog": true, "clamav": true, "rkhunter": true, "chkrootkit": true, "unattended-upgrades": true,
	"aide": true, "apparmor-utils": true, "logrotate": true, "systemd-journal-remote": false}

var offensivePackages = map[string]bool{"nmap": true, "hydra": true, "john": true, "hashcat": true, "masscan": true,
	"netcat-openbsd": false, "netcat-traditional": true, "ncat": true, "socat": true, "sqlmap": true, "nikto": true,
	"aircrack-ng": true, "ettercap-text-only": true, "ettercap-graphical": true, "metasploit-framework": true,
	"medusa": true, "dsniff": true, "wireshark": false, "tcpdump": false}

var reScanner = regexp.MustCompile(`(?i)(\.\./|/etc/passwd|wp-login\.php|/wp-admin|xmlrpc\.php|phpmyadmin|/\.env\b|/\.git/|union(?:\s|%20|\+)+select|<script|%3cscript|/cgi-bin/|/actuator|/boaform|/HNAP1|/shell\b|eval\(|base64_decode|/vendor/phpunit|\$\{jndi:|/solr/|/owa/|/manager/html|\bsqlmap\b|\bnikto\b|\bnmap\b|masscan|zgrab|nuclei|dirbuster|gobuster|wpscan|acunetix|nessus)`)

func (a *Analyzer) whitelistedIP(ip string) bool  { return ip != "" && a.cfg.IPWhitelisted(ip) }
func (a *Analyzer) whitelistedUser(u string) bool { return u != "" && a.cfg.UserWhitelisted(u) }
func (a *Analyzer) whitelistedProc(p string) bool {
	return p != "" && (config.Contains(a.cfg.ListaBranca.Processos, p) || config.Contains(a.cfg.ListaBranca.Processos, baseName(p)))
}

func (a *Analyzer) interactive(service string) bool {
	return config.Contains(a.cfg.Deteccao.ServicosLogin, service)
}

func (a *Analyzer) suspiciousCmd(name string) bool {
	b := baseName(strings.TrimSuffix(name, " (deleted)"))
	return b != "" && config.Contains(a.cfg.Deteccao.ComandosSuspeitos, b)
}

func (a *Analyzer) inSuspiciousDir(p string) bool {
	for _, d := range a.cfg.Deteccao.DiretoriosSuspeitos {
		d = strings.TrimSuffix(d, "/")
		if strings.HasPrefix(p, d+"/") {
			return true
		}
	}
	return false
}

// rules aplica as regras de detecção ao evento.
func (a *Analyzer) rules(e *model.Event) {
	ip := e.Get("ip")
	user := e.Get("user")
	if a.whitelistedUser(user) {
		return
	}
	lim := a.cfg.Deteccao.Limites
	switch e.Kind {

	// ---------------------------------------------------------- autenticação
	case "ssh_fail":
		if a.whitelistedIP(ip) {
			return
		}
		a.burstAdd("ssh_forca_bruta", ip, e, user)
	case "ssh_ok":
		if a.whitelistedIP(ip) {
			return
		}
		a.sshOK[ip] = append(a.sshOK[ip], e.Time)
		if user == "root" {
			a.raise("ssh_login_root", ip, model.High, "Login SSH direto como root a partir de "+ip,
				"O usuário root entrou via SSH. Em uma estação de trabalho isso não é habitual e "+
					"amplia muito o impacto de uma credencial vazada.", e)
		}
		a.loginChecks(e, user, ip)
	case "login":
		if a.whitelistedIP(ip) {
			return
		}
		a.loginChecks(e, user, ip)
	case "session_open":
		if a.interactive(e.Get("service")) {
			a.loginChecks(e, user, "")
		}
	case "login_fail", "local_fail":
		if a.whitelistedIP(ip) {
			return
		}
		a.burstAdd("login_falhas_repetidas", user, e, e.Get("service"))
	case "sudo":
		cmd := e.Get("cmd")
		if a.isNew("sudo_user", user) {
			a.raise("sudo_novo_usuario", user, model.Medium, "Usuário usou sudo pela primeira vez: "+user,
				"O usuário '"+user+"' nunca havia executado sudo na linha de base. Confirme se ele deveria ter privilégios administrativos.", e)
		}
		key := user + "|" + sudoCmdKey(cmd)
		if a.isNew("sudo_cmd", key) {
			a.raise("sudo_novo_comando", key, model.Low, "Comando novo via sudo: "+sudoCmdKey(cmd)+" ("+user+")",
				"O comando '"+util.Truncate(cmd, 120)+"' foi executado com sudo por '"+user+"' e nunca havia sido visto antes.", e)
		}
		if a.suspiciousCmd(util.CmdBase(cmd)) {
			a.raise("comando_suspeito", util.CmdBase(cmd)+"|"+user, model.Medium,
				"Ferramenta sensível executada com sudo: "+util.CmdBase(cmd),
				"'"+util.CmdBase(cmd)+"' está na lista de comandos suspeitos (ferramentas de rede/ataque/ocultação) e foi executada como root por '"+user+"'.", e)
		}
	case "sudo_fail":
		a.burstAdd("sudo_falhas", user, e, "")
	case "sudo_denied":
		a.raise("sudo_nao_autorizado", user, model.High, "Tentativa de sudo por usuário sem permissão: "+user,
			"O usuário '"+user+"' tentou usar sudo sem estar autorizado no sudoers. Pode indicar tentativa de escalada de privilégio.", e)
	case "su_fail":
		a.burstAdd("su_falhas", user+"->"+e.Get("to"), e, "")
	case "su":
		k := user + "->" + e.Get("to")
		if a.isNew("su_pair", k) {
			a.raise("su_novo", k, model.Low, "Troca de usuário (su) nunca vista: "+k,
				"O usuário '"+user+"' passou a agir como '"+e.Get("to")+"' via su, combinação ausente da linha de base.", e)
		}
	case "user_add":
		sev := model.High
		title := "Conta de usuário criada: " + user
		if e.Get("uid") == "0" {
			sev = model.Critical
			title = "Conta criada com UID 0 (privilégio de root): " + user
		}
		a.raise("usuario_criado", user, sev, title, "Uma nova conta foi criada no sistema (UID "+e.Get("uid")+"). Criação de contas não faz parte da rotina habitual.", e)
	case "group_add":
		a.raise("grupo_criado", e.Get("group"), model.Medium, "Grupo criado: "+e.Get("group"), "Um novo grupo foi criado no sistema.", e)
	case "user_mod":
		g := e.Get("group")
		if privilegedGroups[g] {
			a.raise("usuario_privilegio", user+"|"+g, model.High, "Usuário adicionado a grupo privilegiado: "+user+" → "+g,
				"O grupo '"+g+"' concede privilégios administrativos (ou equivalentes a root). Verifique se a mudança foi autorizada.", e)
		} else {
			a.raise("usuario_modificado", user, model.Low, "Conta de usuário modificada: "+user, "A conta foi alterada (grupos, bloqueio ou atributos).", e)
		}
	case "user_del":
		a.raise("usuario_removido", user, model.Medium, "Conta de usuário removida: "+user, "Uma conta local foi apagada.", e)
	case "group_del":
		a.raise("usuario_removido", "grupo:"+e.Get("group"), model.Medium, "Grupo removido: "+e.Get("group"), "Um grupo local foi apagado.", e)
	case "passwd_change":
		sev := model.Low
		if user == "root" {
			sev = model.Medium
		}
		a.raise("senha_alterada", user, sev, "Senha alterada: "+user, "A senha (ou validade da senha) da conta foi modificada.", e)

	// ---------------------------------------------------------- systemd / processos com falha
	case "unit_failed":
		unit := e.Get("unit")
		if config.Contains(a.cfg.ListaBranca.UnidadesSystemd, unit) {
			return
		}
		if ent := a.base.GetEntity("unit_failed", unit); ent != nil && !a.learning {
			a.raise("servico_falhou", unit, model.Low, "Serviço falhou (recorrente): "+unit,
				fmt.Sprintf("A unidade já havia falhado %d vez(es) na linha de base; a falha é recorrente, mas continua sem solução.", ent.Count), e)
		} else {
			a.raise("servico_falhou", unit, model.Medium, "Serviço falhou: "+unit,
				"A unidade systemd terminou em estado de falha (resultado: "+e.Get("result")+").", e)
		}
	case "unit_restart":
		unit := e.Get("unit")
		if config.Contains(a.cfg.ListaBranca.UnidadesSystemd, unit) {
			return
		}
		if atoi(e.Get("counter")) >= lim.ReinicioServicoContador {
			a.raise("servico_reinicio_loop", unit, model.High, "Serviço reiniciando em loop: "+unit,
				"O systemd reiniciou a unidade "+e.Get("counter")+" vezes seguidas (limite configurado: "+itoa(lim.ReinicioServicoContador)+").", e)
		}
	case "core_dump":
		p := e.Get("proc")
		sev := model.Medium
		if a.base.KnownEntity("core_proc", p) {
			sev = model.Low
		}
		a.raise("core_dump", p, sev, "Processo travou e gerou core dump: "+p, "O processo terminou de forma anormal (falha de segmentação, abort etc.).", e)
	case "app_crash":
		a.raise("crash_aplicacao", e.Get("exe"), model.Low, "Relatório de crash (apport): "+baseName(e.Get("exe")), "O apport registrou um travamento em /var/crash.", e)

	// ---------------------------------------------------------- kernel / hardware
	case "oom":
		a.raise("oom", e.Get("proc"), model.High, "Falta de memória: kernel matou o processo "+e.Get("proc"),
			"O OOM killer do kernel encerrou um processo porque a memória (RAM + swap) se esgotou.", e)
	case "segfault":
		p := e.Get("proc")
		a.counters["segfault|"+p]++
		sev := model.Low
		if a.counters["segfault|"+p] >= lim.SegfaultsMesmoProcesso {
			sev = model.Medium
		}
		a.raise("segfault", p, sev, "Falha de segmentação: "+p, "O processo acessou memória inválida e foi encerrado pelo kernel.", e)
	case "kernel_bug":
		w := e.Get("what")
		a.raise("kernel_erro", util.Template(w), model.High, "Erro grave do kernel: "+strings.TrimSpace(w),
			"O kernel registrou um BUG/Oops/travamento. Isso pode indicar driver defeituoso, hardware com problema ou bug do kernel.", e)
	case "hw_error":
		w := e.Get("what")
		sev := model.High
		lw := strings.ToLower(w)
		if strings.Contains(lw, "throttl") || strings.Contains(lw, "above threshold") || strings.Contains(lw, "acpi error") || strings.Contains(lw, "firmware bug") {
			sev = model.Medium
		}
		a.raise("hardware_erro", util.Template(w), sev, "Erro de hardware reportado pelo kernel: "+strings.TrimSpace(w),
			"O kernel registrou um evento de hardware (MCE, PCIe/AER, temperatura, ACPI, EDAC).", e)
	case "hw_log":
		a.raise("hardware_erro", e.Program+"|"+util.Template(util.Truncate(e.Message, 80)), model.High,
			"Alerta de hardware ("+e.Program+")", "O daemon "+e.Program+" registrou um problema de hardware.", e)
	case "disk_error":
		w := e.Get("what")
		sev := model.High
		if strings.Contains(strings.ToLower(w), "read-only") {
			sev = model.Critical
		}
		a.raise("disco_io_erro", util.Template(w), sev, "Erro de disco/sistema de arquivos: "+strings.TrimSpace(w),
			"O kernel registrou erros de entrada/saída ou corrupção de sistema de arquivos. Risco de perda de dados.", e)
	case "usb_new":
		a.counters["usbport|"+e.Get("port")] = 0
		id := e.Get("id")
		if a.isNew("usb_device", id) {
			an := a.raise("usb_novo_dispositivo", id, model.Low, "Dispositivo USB nunca visto conectado ("+id+")",
				"Um dispositivo USB com este fabricante/produto nunca havia sido conectado. Dispositivos desconhecidos podem ser vetores de ataque (ex.: BadUSB).", e)
			if an != nil {
				a.usbAnom[e.Get("port")] = an
			}
		}
	case "usb_product":
		if an := a.usbAnom[e.Get("port")]; an != nil && !strings.Contains(an.Title, "—") {
			an.Title += " — " + e.Get("product")
		}

	// ---------------------------------------------------------- firewall / fail2ban / MAC
	case "fw_block":
		src := e.Get("src")
		if a.whitelistedIP(src) {
			return
		}
		a.burstAdd("firewall_varredura", src, e, e.Get("dpt"))
		if b := a.bursts["firewall_varredura|"+src]; b != nil {
			b.ports = append(b.ports, atoi(e.Get("dpt")))
		}
	case "fw_inactive":
		a.raise("firewall_inativo", "ufw", model.Low, "Firewall UFW está inativo",
			"O UFW está instalado, mas desativado: nenhuma regra de entrada está sendo aplicada.", e)
	case "f2b_ban":
		if a.whitelistedIP(ip) {
			return
		}
		an := a.raise("fail2ban_banimento", e.Get("jail"), model.Medium, "fail2ban baniu IPs na jail "+e.Get("jail"),
			"O fail2ban detectou tentativas repetidas e bloqueou endereços. Indica ataque ativo contra o serviço.", e)
		if an != nil && an.Count > 10 {
			an.Severity = a.cfg.SeverityFor("fail2ban_banimento", model.High)
		}
	case "apparmor_denied":
		k := e.Get("profile") + "|" + e.Get("op")
		if a.isNew("apparmor", k) {
			a.raise("apparmor_negacao", k, model.Medium, "AppArmor bloqueou ação nova: "+e.Get("profile")+" ("+e.Get("op")+")",
				"O perfil AppArmor negou uma operação que não aparece na linha de base. Pode ser um programa tentando acessar algo fora do esperado ou um perfil desatualizado.", e)
		}
	case "audit_anom":
		a.raise("auditd_anomalia", e.Get("type"), model.High, "auditd registrou anomalia: "+e.Get("type"),
			"Eventos ANOM_* indicam comportamento anômalo detectado pelo kernel (ex.: modo promíscuo, falhas de login em massa, abends).", e)
	case "audit_fail":
		a.burstAdd("auditd_falhas", e.Get("exe"), e, e.Get("acct"))
	case "audit_config":
		a.raise("auditd_config_alterada", "config", model.Medium, "Regras de auditoria alteradas",
			"A configuração do auditd foi modificada (CONFIG_CHANGE). Atacantes costumam desativar auditoria.", e)
	case "audit_key":
		a.raise("auditd_chave", e.Get("key"), model.Medium, "Evento de auditoria monitorado: "+e.Get("key"),
			"Uma regra de auditoria marcada como alerta (chaves_auditd_alerta) foi acionada.", e)

	// ---------------------------------------------------------- cron / timers
	case "cron_cmd":
		k := e.Get("user") + "|" + util.Template(e.Get("cmd"))
		if a.isNew("cron_cmd", k) {
			a.raise("cron_novo_comando", k, model.Medium, "Tarefa agendada nova executada pelo cron ("+e.Get("user")+")",
				"O cron executou um comando nunca visto: '"+util.Truncate(e.Get("cmd"), 120)+"'. Persistência via cron é técnica comum de malware.", e)
		}
	case "cron_file":
		p, h := e.Get("path"), e.Get("hash")
		ent := a.base.GetEntity("cron_file", p)
		if ent == nil && a.isNew("cron_file", p) {
			a.raise("cron_novo_arquivo", p, model.Medium, "Novo arquivo de agendamento: "+p, "Um novo arquivo de cron apareceu desde a última análise.", e)
		} else if ent != nil && ent.Extra != "" && ent.Extra != h {
			a.raise("cron_arquivo_alterado", p, model.Medium, "Arquivo de agendamento modificado: "+p, "O conteúdo do arquivo de cron mudou desde a última análise.", e)
		}
	case "timer":
		if a.isNew("timer", e.Get("unit")) {
			a.raise("timer_novo", e.Get("unit"), model.Low, "Novo timer do systemd: "+e.Get("unit"), "Um novo agendamento systemd (timer) foi registrado.", e)
		}

	// ---------------------------------------------------------- pacotes
	case "apt_tx":
		inst := strings.Fields(e.Get("install"))
		rem := append(strings.Fields(e.Get("remove")), strings.Fields(e.Get("purge"))...)
		inst = a.filterPkgs(inst)
		rem = a.filterPkgs(rem)
		if len(inst)+len(rem) > 0 && !a.cfg.Deteccao.JanelaManutencaoPacotes.InWindow(e.Time) {
			a.raise("pacote_fora_janela", e.Time.Format("2006-01-02T15"), model.Medium,
				"Pacotes instalados/removidos fora da janela de manutenção",
				"Janela configurada: "+a.cfg.Deteccao.JanelaManutencaoPacotes.Describe()+". Instalados: "+
					util.Truncate(strings.Join(inst, ", "), 150)+". Removidos: "+util.Truncate(strings.Join(rem, ", "), 150)+".", e)
		}
		for _, p := range inst {
			if offensivePackages[p] {
				a.raise("pacote_suspeito", p, model.Medium, "Ferramenta ofensiva instalada: "+p,
					"O pacote '"+p+"' é usado para varredura/quebra de senha/interceptação. Confirme se a instalação foi intencional.", e)
			}
		}
		for _, p := range rem {
			if securityPackages[p] {
				a.raise("pacote_seguranca_removido", p, model.High, "Pacote de segurança removido: "+p,
					"A remoção de '"+p+"' reduz a capacidade de defesa/registro da máquina. Atacantes removem ferramentas de log e auditoria.", e)
			}
		}

	// ---------------------------------------------------------- web
	case "http":
		if a.whitelistedIP(ip) {
			return
		}
		st := e.Get("status")
		if st == "404" {
			a.counters["404|"+ip]++
			if a.counters["404|"+ip] >= a.cfg.Deteccao.Web.Requisicoes404PorIP {
				a.raise("web_404_ip", ip, model.Medium, "Muitas requisições 404 do IP "+ip,
					"O IP gerou "+itoa(a.cfg.Deteccao.Web.Requisicoes404PorIP)+"+ respostas 404: típico de varredura de diretórios.", e)
			}
		}
		if strings.HasPrefix(st, "5") {
			a.web5xx[e.Source+"|"+util.HourKey(e.Time)]++
		}
		if reScanner.MatchString(e.Get("path")) || reScanner.MatchString(e.Get("ua")) {
			a.burstAdd("web_scanner", ip, e, util.Truncate(e.Get("path"), 60))
		}

	// ---------------------------------------------------------- docker
	case "container_die":
		a.raise("docker_container_falhou", e.Get("name"), model.Medium, "Container terminou com erro: "+e.Get("name"),
			"O container encerrou com código de saída "+e.Get("exit")+".", e)
	case "container_oom":
		a.raise("docker_oom", e.Get("name"), model.High, "Container sem memória (OOM): "+e.Get("name"), "O container foi encerrado por falta de memória.", e)
	case "container_restart":
		a.counters["crestart|"+e.Get("name")]++
		if a.counters["crestart|"+e.Get("name")] >= a.cfg.Deteccao.Limites.ReiniciosContainer {
			a.raise("docker_reinicios", e.Get("name"), model.Medium, "Container reiniciando repetidamente: "+e.Get("name"),
				"O container reiniciou várias vezes no período.", e)
		}
	case "container_start":
		if a.isNew("container_image", e.Get("image")) {
			a.raise("docker_imagem_nova", e.Get("image"), model.Low, "Container de imagem nunca vista: "+e.Get("image"),
				"Um container foi iniciado a partir de uma imagem ausente da linha de base.", e)
		}

	// ---------------------------------------------------------- bancos de dados
	case "db_auth_fail":
		a.burstAdd("db_falhas_autenticacao", e.Source+"|"+user, e, ip)
	case "db_crash":
		a.raise("db_falha_critica", e.Source+"|"+e.Get("what"), model.High, "Falha crítica no banco de dados ("+e.Source+"): "+e.Get("what"),
			"O servidor de banco de dados registrou travamento, corrupção ou recuperação após desligamento anormal.", e)

	// ---------------------------------------------------------- processos / acct
	case "exec":
		if a.suspiciousCmd(e.Get("cmd")) {
			a.raise("comando_suspeito", e.Get("cmd")+"|"+user, model.Medium, "Ferramenta sensível executada: "+e.Get("cmd")+" ("+user+")",
				"O registro de contabilidade de processos mostra a execução de um comando da lista de suspeitos.", e)
		}
	case "proc":
		a.procRules(e)
	case "proc_summary":
		z := atoi(e.Get("zombies"))
		a.procTotal = atof(e.Get("total"))
		a.snapshot = append(a.snapshot, "Processos: "+e.Message)
		if z >= lim.Zumbis {
			a.raise("processos_zumbis", "zumbis", model.Low, fmt.Sprintf("%d processos zumbis", z),
				"Muitos processos terminados não foram recolhidos pelo processo pai.", e)
		}
	case "listen":
		port := e.Get("port")
		if config.Contains(a.cfg.ListaBranca.Portas, port) || a.whitelistedProc(e.Get("exe")) {
			return
		}
		k := listenKey(e)
		if a.isNew("listen_port", k) {
			sev := model.Medium
			loop := strings.HasPrefix(e.Get("addr"), "127.") || e.Get("addr") == "::1"
			if loop {
				sev = model.Low
			}
			where := "todas as interfaces"
			if loop {
				where = "somente local (loopback)"
			}
			a.raise("porta_nova", k, sev, "Nova porta em escuta: "+e.Get("proto")+"/"+port+" ("+baseName(e.Get("exe"))+")",
				"Um programa passou a aceitar conexões em "+where+" e isso não existia na linha de base. Portas inesperadas podem ser backdoors.", e)
		}
		if a.suspiciousCmd(e.Get("exe")) {
			a.raise("comando_suspeito", baseName(e.Get("exe"))+"|listen", model.High, "Ferramenta suspeita escutando na porta "+port,
				"'"+baseName(e.Get("exe"))+"' está aceitando conexões de rede (possível shell reverso/backdoor).", e)
		}

	// ---------------------------------------------------------- integridade
	case "file_hash":
		a.integrityRules(e)
	case "account":
		u, uid := e.Get("user"), e.Get("uid")
		if uid == "0" && u != "root" {
			a.raise("usuario_uid0", u, model.Critical, "Conta extra com UID 0: "+u,
				"Além do root existe outra conta com UID 0, ou seja, com poder total sobre o sistema. Técnica clássica de backdoor.", e)
		}
		if ent := a.base.GetEntity("account", u); ent != nil && ent.Extra != "" && ent.Extra != uid {
			a.raise("usuario_modificado", u, model.Medium, "UID da conta alterado: "+u, "O UID mudou de "+ent.Extra+" para "+uid+".", e)
		} else if ent == nil && a.isNew("account", u) {
			a.raise("usuario_criado", u, model.High, "Conta de usuário criada: "+u, "A conta apareceu em /etc/passwd desde a última análise.", e)
		}
	case "lastlog":
		uid, ok := a.uidOf[user]
		if ok && uid > 0 && uid < 1000 && !config.Contains([]string{"gdm", "gnome-initial-setup", "lightdm", "sddm", "nobody"}, user) {
			if a.isNew("lastlog_user", user) {
				a.raise("conta_sistema_login", user, model.High, "Conta de sistema com registro de login: "+user,
					"Contas de serviço (UID < 1000) normalmente não fazem login interativo. Pode indicar abuso de conta de serviço.", e)
			}
		}
	case "ld_preload":
		a.raise("ld_preload", "preload", model.Critical, "/etc/ld.so.preload em uso",
			"Bibliotecas listadas em /etc/ld.so.preload são carregadas em TODOS os programas. Em um Ubuntu padrão esse arquivo não existe; é técnica comum de rootkits.", e)

	// ---------------------------------------------------------- hardware / recursos
	case "hw_temp":
		v, crit := atof(e.Get("value")), atof(e.Get("crit"))
		if v > a.maxTemp {
			a.maxTemp = v
		}
		thr := lim.TemperaturaCelsius
		if v >= thr || (crit > 0 && v >= crit-3) {
			sev := model.Medium
			if crit > 0 && v >= crit {
				sev = model.High
			}
			a.raise("temperatura_alta", e.Get("sensor"), sev, fmt.Sprintf("Temperatura alta: %s = %.0f°C", e.Get("sensor"), v),
				fmt.Sprintf("Limite configurado %.0f°C (crítico do sensor: %.0f°C).", thr, crit), e)
		}
	case "hw_smart":
		a.smartRules(e)
	case "hw_edac":
		mc := e.Get("mc")
		ce, ue := atof(e.Get("ce")), atof(e.Get("ue"))
		pce, okc := a.base.Counters["edac|"+mc+"|ce"]
		pue, oku := a.base.Counters["edac|"+mc+"|ue"]
		if ue > 0 && (!oku || ue > pue) {
			a.raise("memoria_ecc_erro", mc+"|ue", model.Critical, "Erros de memória NÃO corrigidos (ECC) em "+mc, "A memória RAM apresentou erros incorrigíveis: risco de corrupção de dados e travamentos.", e)
		}
		if ce > 0 && okc && ce > pce {
			a.raise("memoria_ecc_erro", mc+"|ce", model.Medium, fmt.Sprintf("Erros de memória corrigidos aumentaram em %s (+%.0f)", mc, ce-pce), "Erros corrigíveis crescentes costumam anteceder falha do módulo de memória.", e)
		}
		a.pendCnt["edac|"+mc+"|ce"] = ce
		a.pendCnt["edac|"+mc+"|ue"] = ue
	case "hw_battery":
		h := atof(e.Get("health"))
		a.snapshot = append(a.snapshot, "Bateria: "+e.Message)
		if h > 0 && h < lim.BateriaSaudeMinima {
			a.raise("bateria_degradada", e.Get("bat"), model.Low, fmt.Sprintf("Bateria degradada: %.0f%% da capacidade original", h), "A capacidade máxima da bateria caiu abaixo do limite configurado.", e)
		}
	case "res_disk":
		a.snapshot = append(a.snapshot, "Disco "+e.Message)
		pct, ipct := atof(e.Get("pct")), atof(e.Get("ipct"))
		if pct >= lim.DiscoPercentual {
			sev := model.High
			if pct >= 98 {
				sev = model.Critical
			}
			a.raise("disco_cheio", e.Get("mount"), sev, fmt.Sprintf("Disco quase cheio: %s (%.1f%%)", e.Get("mount"), pct),
				fmt.Sprintf("Limite configurado: %.0f%%. Livre: %s. Disco cheio impede gravação de logs e pode travar serviços.", lim.DiscoPercentual, e.Get("free")), e)
		}
		if ipct >= lim.InodesPercentual {
			a.raise("inodes_cheio", e.Get("mount"), model.High, fmt.Sprintf("Inodes quase esgotados: %s (%.1f%%)", e.Get("mount"), ipct),
				"Sem inodes livres não é possível criar arquivos, mesmo com espaço em disco.", e)
		}
	case "res_mem":
		a.snapshot = append(a.snapshot, "Memória: "+e.Message)
		if av := atof(e.Get("avail_pct")); av < lim.MemoriaLivrePercentualMin {
			a.raise("memoria_baixa", "ram", model.High, fmt.Sprintf("Memória disponível muito baixa (%.1f%%)", av), "Risco iminente de OOM killer e lentidão extrema.", e)
		}
		if sw := atof(e.Get("swap_pct")); sw >= lim.SwapPercentual && atof(e.Get("swap_total")) > 0 {
			a.raise("swap_alto", "swap", model.Medium, fmt.Sprintf("Uso de swap alto (%.1f%%)", sw), "O sistema está paginando memória para o disco.", e)
		}
	case "res_load":
		a.snapshot = append(a.snapshot, "Carga: "+e.Message)
		l5, n := atof(e.Get("load5")), atof(e.Get("ncpu"))
		if n > 0 && l5/n >= lim.CargaPorCPU {
			a.raise("carga_alta", "load", model.Medium, fmt.Sprintf("Carga do sistema alta (%.2f para %d CPUs)", l5, int(n)), "A fila de processos está muito acima da capacidade dos processadores.", e)
		}
	case "res_uptime":
		a.snapshot = append(a.snapshot, "Uptime: "+e.Message)
	}
}

func (a *Analyzer) filterPkgs(l []string) []string {
	var out []string
	for _, p := range l {
		if !config.Contains(a.cfg.ListaBranca.Pacotes, p) {
			out = append(out, p)
		}
	}
	return out
}

func listenKey(e *model.Event) string {
	port := atoi(e.Get("port"))
	ps := e.Get("port")
	if port >= 32768 {
		ps = "efemera"
	}
	return strings.TrimSuffix(e.Get("proto"), "6") + "/" + ps + "/" + baseName(normExe(e.Get("exe")))
}

func (a *Analyzer) loginChecks(e *model.Event, user, ip string) {
	if user == "" {
		return
	}
	if !a.cfg.Deteccao.HorarioLogin.InWindow(e.Time) {
		a.raise("login_fora_horario", user+"|"+e.Time.Format("2006-01-02"), model.Medium,
			"Login fora do horário habitual: "+user+" às "+e.Time.Format("15:04 (02/01)"),
			"Horário permitido configurado: "+a.cfg.Deteccao.HorarioLogin.Describe()+".", e)
	}
	if a.isNew("login_user", user) {
		a.raise("login_novo_usuario", user, model.Medium, "Primeiro login registrado do usuário "+user,
			"Este usuário nunca havia feito login interativo na linha de base.", e)
	}
	if ip != "" && a.isNew("login_ip", ip) {
		sev := model.Medium
		if user == "root" {
			sev = model.High
		}
		a.raise("login_novo_ip", ip, sev, "Login a partir de IP nunca visto: "+ip+" ("+user+")",
			"Nenhum login bem-sucedido vindo deste endereço existe na linha de base.", e)
	}
}

func (a *Analyzer) procRules(e *model.Event) {
	exe, comm, user := e.Get("exe"), e.Get("comm"), e.Get("user")
	if a.whitelistedProc(exe) || a.whitelistedProc(comm) {
		return
	}
	lim := a.cfg.Deteccao.Limites
	clean := strings.TrimSuffix(exe, " (deleted)")
	if strings.HasPrefix(exe, "/memfd:") {
		a.raise("processo_sem_arquivo", comm, model.Critical, "Processo executando a partir da memória (memfd): "+comm,
			"O executável não existe em disco (memfd_create). Técnica típica de malware \"fileless\".", e)
	} else if a.inSuspiciousDir(clean) && !strings.HasPrefix(clean, "/tmp/.mount_") { // .mount_ = AppImage montado
		a.raise("processo_local_suspeito", clean, model.High, "Processo executando de diretório temporário: "+clean,
			"Programas legítimos raramente rodam de /tmp, /var/tmp ou /dev/shm; esses diretórios são usados por malware por serem graváveis por todos.", e)
	} else if strings.HasSuffix(exe, " (deleted)") {
		std := strings.HasPrefix(clean, "/usr/") || strings.HasPrefix(clean, "/snap/") || strings.HasPrefix(clean, "/opt/") || strings.HasPrefix(clean, "/bin/") || strings.HasPrefix(clean, "/sbin/") || strings.HasPrefix(clean, "/lib")
		if !std {
			a.raise("processo_binario_apagado", clean, model.High, "Processo cujo executável foi apagado: "+clean,
				"O binário foi removido do disco enquanto o processo continua rodando, forma comum de esconder malware.", e)
		} else if a.isNew("deleted_exe", normExe(clean)) {
			a.raise("processo_binario_apagado", clean, model.Info, "Processo usando binário antigo (atualizado no disco): "+baseName(clean),
				"Normal após atualizações: o programa precisa ser reiniciado para usar a versão nova.", e)
		}
	}
	if a.suspiciousCmd(comm) || a.suspiciousCmd(clean) {
		a.raise("comando_suspeito", baseName(clean)+"|"+user, model.Medium, "Ferramenta sensível em execução: "+baseName(clean)+" ("+user+")",
			"O processo está na lista de comandos suspeitos (comandos_suspeitos).", e)
	}
	if cpu := atof(e.Get("cpu")); cpu >= lim.CPUProcessoPercentual {
		a.raise("processo_cpu_alta", normExe(clean), model.Low, fmt.Sprintf("Processo com CPU alta: %s (%.0f%%)", comm, cpu),
			"Consumo contínuo de CPU elevado pode indicar travamento, laço infinito ou mineração de criptomoedas.", e)
	}
	if mem := atof(e.Get("mem")); mem >= lim.MemoriaProcessoPercentual {
		a.raise("processo_memoria_alta", normExe(clean), model.Medium, fmt.Sprintf("Processo usando muita memória: %s (%.0f%% da RAM)", comm, mem),
			"Um único processo ocupa grande parte da memória (possível vazamento).", e)
	}
	if e.Get("uid") == "0" && a.isNew("root_exe", normExe(clean)) {
		a.raise("processo_root_novo", normExe(clean), model.Low, "Programa novo rodando como root: "+clean,
			"Este executável nunca havia sido visto rodando com privilégios de root.", e)
	}
}

func (a *Analyzer) integrityRules(e *model.Event) {
	p, h := e.Get("path"), e.Get("hash")
	ent := a.base.GetEntity("file_hash", p)
	isKeys := strings.HasSuffix(p, "authorized_keys")
	if ent == nil {
		if a.isNew("file_hash", p) {
			if isKeys {
				a.raise("chave_ssh_alterada", p, model.High, "Novo arquivo de chaves SSH autorizadas: "+p,
					"Alguém passou a poder entrar por SSH com chave nesta conta. Verifique se a chave é sua.", e)
			} else {
				a.raise("integridade_arquivo_novo", p, model.Medium, "Novo arquivo crítico de configuração: "+p,
					"Um arquivo monitorado (configuração sensível) apareceu desde a última análise.", e)
			}
		}
		return
	}
	if ent.Extra == "" || ent.Extra == h {
		return
	}
	sev := model.Medium
	switch {
	case isKeys:
		a.raise("chave_ssh_alterada", p, model.High, "Chaves SSH autorizadas alteradas: "+p,
			"O arquivo authorized_keys mudou: uma chave pode ter sido adicionada para acesso persistente.", e)
		return
	case strings.Contains(p, "sudoers"), strings.Contains(p, "/pam.d/"), strings.Contains(p, "ld.so"),
		strings.Contains(p, "sshd_config"), strings.HasSuffix(p, ".service"), strings.Contains(p, "sources.list"):
		sev = model.High
	case p == "/etc/hosts", p == "/etc/resolv.conf":
		sev = model.Low
	}
	a.raise("integridade_arquivo_alterado", p, sev, "Arquivo crítico modificado: "+p,
		"O hash SHA-256 do arquivo mudou desde a última análise (modificado em "+e.Get("mtime")+").", e)
}

func (a *Analyzer) smartRules(e *model.Event) {
	dev := e.Get("dev")
	a.snapshot = append(a.snapshot, "SMART: "+e.Message)
	if e.Get("status") == "FAILED" {
		a.raise("smart_falha", dev, model.Critical, "Disco reprovado no teste SMART: "+dev+" ("+e.Get("model")+")",
			"O próprio disco declara falha iminente. Faça backup IMEDIATAMENTE e substitua o disco.", e)
	}
	if w := atoi(e.Get("nvme_warn")); w != 0 {
		a.raise("smart_falha", dev+"|nvme", model.High, fmt.Sprintf("NVMe com aviso crítico (código %d): %s", w, dev), "O controlador NVMe reportou critical_warning ≠ 0.", e)
	}
	if e.Get("spare_low") == "1" {
		a.raise("smart_falha", dev+"|spare", model.High, "NVMe com área reserva abaixo do limite: "+dev, "O SSD está sem blocos reserva suficientes.", e)
	}
	if u := atof(e.Get("pct_used")); u >= 90 {
		a.raise("smart_desgaste", dev, model.Medium, fmt.Sprintf("SSD com %.0f%% da vida útil consumida: %s", u, dev), "O SSD está perto do fim da vida útil estimada.", e)
	}
	for _, attr := range []string{"realloc", "pending", "uncorrect", "media_errors"} {
		vs := e.Get(attr)
		if vs == "" {
			continue
		}
		v := atof(vs)
		k := "smart|" + dev + "|" + attr
		prev, ok := a.base.Counters[k]
		a.pendCnt[k] = v
		names := map[string]string{"realloc": "setores realocados", "pending": "setores pendentes",
			"uncorrect": "setores incorrigíveis", "media_errors": "erros de mídia"}
		if v > 0 && ok && v > prev {
			a.raise("smart_setores", k, model.High, fmt.Sprintf("Aumento de %s no disco %s (%.0f → %.0f)", names[attr], dev, prev, v),
				"Contadores de defeito físico aumentando indicam degradação do disco.", e)
		} else if v > 0 && !ok {
			a.raise("smart_setores", k, model.Medium, fmt.Sprintf("Disco %s possui %.0f %s", dev, v, names[attr]),
				"Primeira leitura: o disco já tem defeitos registrados. Acompanhe se o número cresce.", e)
		}
	}
}

// learnEntities registra o que foi visto (vale para as duas passadas).
func (a *Analyzer) learnEntities(e *model.Event) {
	t := e.Time
	u := e.Get("user")
	switch e.Kind {
	case "ssh_ok":
		a.touch("login_ip", e.Get("ip"), "", t)
		a.touch("login_user", u, "", t)
	case "login":
		a.touch("login_user", u, "", t)
		a.touch("login_ip", e.Get("ip"), "", t)
	case "session_open":
		if a.interactive(e.Get("service")) {
			a.touch("login_user", u, "", t)
		}
	case "sudo":
		a.touch("sudo_user", u, "", t)
		a.touch("sudo_cmd", u+"|"+sudoCmdKey(e.Get("cmd")), "", t)
	case "su":
		a.touch("su_pair", u+"->"+e.Get("to"), "", t)
	case "cron_cmd":
		a.touch("cron_cmd", u+"|"+util.Template(e.Get("cmd")), "", t)
	case "cron_file":
		a.touch("cron_file", e.Get("path"), e.Get("hash"), t)
	case "timer":
		a.touch("timer", e.Get("unit"), "", t)
	case "usb_new":
		a.touch("usb_device", e.Get("id"), "", t)
	case "apparmor_denied":
		a.touch("apparmor", e.Get("profile")+"|"+e.Get("op"), "", t)
	case "unit_failed":
		a.touch("unit_failed", e.Get("unit"), "", t)
	case "core_dump":
		a.touch("core_proc", e.Get("proc"), "", t)
	case "segfault":
		a.touch("segfault_proc", e.Get("proc"), "", t)
	case "app_crash":
		a.touch("crash_exe", e.Get("exe"), "", t)
	case "container_start":
		a.touch("container_image", e.Get("image"), "", t)
	case "listen":
		a.touch("listen_port", listenKey(e), "", t)
	case "proc":
		exe := strings.TrimSuffix(e.Get("exe"), " (deleted)")
		if e.Get("uid") == "0" {
			a.touch("root_exe", normExe(exe), "", t)
		}
		if strings.HasSuffix(e.Get("exe"), " (deleted)") {
			a.touch("deleted_exe", normExe(exe), "", t)
		}
	case "file_hash":
		a.touch("file_hash", e.Get("path"), e.Get("hash"), t)
	case "account":
		a.touch("account", u, e.Get("uid"), t)
	case "lastlog":
		a.touch("lastlog_user", u, "", t)
	}
}

// ---------------------------------------------------------------- pós-processamento

func (a *Analyzer) finalize(all, active []collectors.Collector) {
	if a.learn {
		return
	}
	d := a.cfg.Deteccao
	a.finalizeBursts(d)

	// 5xx por hora
	for k, n := range a.web5xx {
		if n >= d.Web.Erros5xxPorHora {
			src, h, _ := strings.Cut(k, "|")
			an := a.raise("web_5xx", k, model.Medium, fmt.Sprintf("%d erros HTTP 5xx em uma hora (%s)", n, src),
				"O servidor web respondeu com erro interno muitas vezes na hora "+h+":00.", nil)
			if an != nil {
				an.AddSource(src)
				an.Count = n
				t, _ := util.ParseHourKey(h)
				an.First, an.Last = t, t.Add(time.Hour)
			}
		}
	}

	if !a.learning {
		a.volumeRules(active)
		a.silenceRules(active)
	}
	a.fileIntegrity(all)
	if a.maxTemp > 0 {
		a.snapshot = append(a.snapshot, fmt.Sprintf("Temperatura máxima medida: %.1f°C", a.maxTemp))
	}
}

func (a *Analyzer) finalizeBursts(d config.Deteccao) {
	keys := make([]string, 0, len(a.bursts))
	for k := range a.bursts {
		keys = append(keys, k)
	}
	sort.Strings(keys)
	for _, k := range keys {
		b := a.bursts[k]
		rule, key, _ := strings.Cut(k, "|")
		sort.Slice(b.times, func(i, j int) bool { return b.times[i].Before(b.times[j]) })
		var win config.Janela
		switch rule {
		case "ssh_forca_bruta":
			win = d.ForcaBrutaSSH
		case "login_falhas_repetidas", "su_falhas", "auditd_falhas":
			win = d.ForcaBrutaLocal
		case "sudo_falhas":
			win = d.ForcaBrutaSudo
		case "db_falhas_autenticacao":
			win = config.Janela{Falhas: d.Limites.FalhasBancoDados, JanelaMinutos: 60}
		case "web_scanner":
			win = config.Janela{Falhas: d.Web.AssinaturasScanner, JanelaMinutos: 60}
		case "firewall_varredura":
			a.portScan(key, b, d.VarreduraPortas)
			continue
		}
		maxIn, firstHit := maxInWindow(b.times, time.Duration(win.JanelaMinutos)*time.Minute, win.Falhas)
		if win.Falhas <= 0 || maxIn < win.Falhas {
			continue
		}
		extra := setList(b.extra)
		var an *model.Anomaly
		switch rule {
		case "ssh_forca_bruta":
			an = a.raise(rule, key, model.High, "Força bruta SSH vinda de "+key,
				fmt.Sprintf("%d falhas de autenticação SSH (pico de %d em %d min; limite %d em %d min). Usuários tentados: %s.",
					len(b.times), maxIn, win.JanelaMinutos, win.Falhas, win.JanelaMinutos, extra), nil)
			for _, t := range a.sshOK[key] {
				if !t.Before(firstHit) {
					if x := a.raise("ssh_sucesso_apos_forca_bruta", key, model.Critical, "LOGIN SSH BEM-SUCEDIDO após força bruta de "+key,
						"Depois de uma série de falhas, o mesmo IP conseguiu autenticar em "+t.Format("02/01 15:04:05")+
							". Trate como possível comprometimento: troque senhas, revise sessões e chaves SSH.", nil); x != nil {
						x.First, x.Last = t, t
						x.AddSource("auth")
					}
					break
				}
			}
		case "login_falhas_repetidas":
			an = a.raise(rule, key, model.Medium, "Falhas repetidas de login local para "+key,
				fmt.Sprintf("%d falhas (pico de %d em %d min). Serviços: %s.", len(b.times), maxIn, win.JanelaMinutos, extra), nil)
		case "sudo_falhas":
			an = a.raise(rule, key, model.Medium, "Falhas repetidas de senha no sudo: "+key,
				fmt.Sprintf("%d falhas de senha no sudo (pico de %d em %d min).", len(b.times), maxIn, win.JanelaMinutos), nil)
		case "su_falhas":
			an = a.raise(rule, key, model.Medium, "Falhas repetidas no su: "+key,
				fmt.Sprintf("%d tentativas de su falharam (pico de %d em %d min).", len(b.times), maxIn, win.JanelaMinutos), nil)
		case "auditd_falhas":
			an = a.raise(rule, key, model.Low, "auditd: falhas de autenticação em "+baseName(key),
				fmt.Sprintf("%d falhas registradas pela auditoria. Contas: %s.", len(b.times), extra), nil)
		case "db_falhas_autenticacao":
			an = a.raise(rule, key, model.Medium, "Falhas de autenticação no banco: "+key,
				fmt.Sprintf("%d logins recusados pelo banco de dados (pico de %d por hora). Origens: %s.", len(b.times), maxIn, extra), nil)
		case "web_scanner":
			sev := model.Medium
			if len(b.times) >= 10*win.Falhas {
				sev = model.High
			}
			an = a.raise(rule, key, sev, "Varredura/ataque web vindo de "+key,
				fmt.Sprintf("%d requisições com assinaturas de scanner/exploit. Exemplos: %s.", len(b.times), extra), nil)
		}
		if an != nil {
			an.Count = len(b.times)
			an.First, an.Last = b.times[0], b.times[len(b.times)-1]
			an.Evidence = b.evidence
			for s := range b.sources {
				an.AddSource(s)
			}
		}
	}
}

func (a *Analyzer) portScan(src string, b *burst, v config.Varredura) {
	type tp struct {
		t time.Time
		p int
	}
	var l []tp
	for i := range b.times {
		p := 0
		if i < len(b.ports) {
			p = b.ports[i]
		}
		l = append(l, tp{b.times[i], p})
	}
	sort.Slice(l, func(i, j int) bool { return l[i].t.Before(l[j].t) })
	win := time.Duration(v.JanelaMinutos) * time.Minute
	cnt := map[int]int{}
	j, best := 0, 0
	for i := range l {
		cnt[l[i].p]++
		for l[i].t.Sub(l[j].t) > win {
			cnt[l[j].p]--
			if cnt[l[j].p] == 0 {
				delete(cnt, l[j].p)
			}
			j++
		}
		if len(cnt) > best {
			best = len(cnt)
		}
	}
	if best < v.PortasDistintas || v.PortasDistintas <= 0 {
		return
	}
	sev := model.Medium
	if best >= 3*v.PortasDistintas {
		sev = model.High
	}
	an := a.raise("firewall_varredura", src, sev, "Varredura de portas vinda de "+src,
		fmt.Sprintf("%d portas distintas sondadas em até %d min (limite %d). Total de pacotes bloqueados: %d.", best, v.JanelaMinutos, v.PortasDistintas, len(l)), nil)
	if an != nil {
		an.Count = len(l)
		an.First, an.Last = l[0].t, l[len(l)-1].t
		an.Evidence = b.evidence
		an.AddSource("ufw")
	}
}

// maxInWindow devolve o maior número de eventos dentro de uma janela deslizante e
// o instante em que o limite thr foi atingido pela primeira vez.
func maxInWindow(ts []time.Time, w time.Duration, thr int) (int, time.Time) {
	best, j := 0, 0
	var hit time.Time
	for i := range ts {
		for ts[i].Sub(ts[j]) > w {
			j++
		}
		n := i - j + 1
		if n > best {
			best = n
		}
		if hit.IsZero() && thr > 0 && n >= thr {
			hit = ts[i]
		}
	}
	return best, hit
}

func setList(m map[string]bool) string {
	var l []string
	for k := range m {
		if k != "" {
			l = append(l, k)
		}
	}
	sort.Strings(l)
	if len(l) == 0 {
		return "-"
	}
	return strings.Join(l, ", ")
}

// volumeRules compara a contagem de cada hora atual com a distribuição histórica.
func (a *Analyzer) volumeRules(active []collectors.Collector) {
	sp := a.cfg.SensitivityParams()
	keys := a.base.CoveredHoursSince(a.opt.Now.AddDate(0, 0, -a.cfg.LinhaDeBase.Dias))
	if len(keys) < a.cfg.LinhaDeBase.HorasMinimas {
		return
	}
	for _, c := range active {
		if c.SnapshotOnly() {
			continue
		}
		src := c.ID()
		cur := a.curHours[src]
		if len(cur) == 0 {
			continue
		}
		hist := a.base.Hours[src]
		all := make([]float64, 0, len(keys))
		byHour := map[int][]float64{}
		for _, k := range keys {
			v := float64(hist[k])
			all = append(all, v)
			if t, err := util.ParseHourKey(k); err == nil {
				byHour[t.Hour()] = append(byHour[t.Hour()], v)
			}
		}
		meanAll, sdAll := meanStd(all)
		type spike struct {
			h      string
			c      int
			mean   float64
			thresh float64
		}
		var spikes []spike
		hks := make([]string, 0, len(cur))
		for h := range cur {
			hks = append(hks, h)
		}
		sort.Strings(hks)
		for _, h := range hks {
			cnt := cur[h]
			mean, sd := meanAll, sdAll
			if t, err := util.ParseHourKey(h); err == nil && len(byHour[t.Hour()]) >= 5 {
				mean, sd = meanStd(byHour[t.Hour()])
			}
			thr := math.Max(mean+sp.ZScore*math.Max(sd, math.Sqrt(math.Max(mean, 1))), mean*sp.FatorMultiplicador)
			if cnt >= sp.MinimoEventos && float64(cnt) > thr {
				spikes = append(spikes, spike{h, cnt, mean, thr})
				if a.spikeHours[src] == nil {
					a.spikeHours[src] = map[string]bool{}
				}
				a.spikeHours[src][h] = true
			}
		}
		if len(spikes) == 0 {
			continue
		}
		worst := spikes[0]
		for _, s := range spikes {
			if float64(s.c)/math.Max(s.thresh, 1) > float64(worst.c)/math.Max(worst.thresh, 1) {
				worst = s
			}
		}
		sev := model.Medium
		if float64(worst.c) >= 3*worst.thresh {
			sev = model.High
		}
		var ev []string
		for i, s := range spikes {
			if i >= a.cfg.Analise.MaxAmostrasPorAnomalia {
				break
			}
			ev = append(ev, fmt.Sprintf("%s:00 → %d eventos (habitual ≈ %.1f, limite %.1f)", strings.Replace(s.h, "T", " ", 1), s.c, s.mean, s.thresh))
		}
		an := a.raise("volume_pico", src, sev, fmt.Sprintf("Pico de volume de eventos na fonte %s", src),
			fmt.Sprintf("Em %d hora(s) o número de eventos ficou acima do habitual. Pior hora: %d eventos contra média de %.1f "+
				"(limite = máx(média + %.1f×desvio, média × %.1f), mínimo %d eventos; sensibilidade %s).",
				len(spikes), worst.c, worst.mean, sp.ZScore, sp.FatorMultiplicador, sp.MinimoEventos, a.cfg.Deteccao.Sensibilidade), nil)
		if an != nil {
			an.AddSource(src)
			an.Evidence = ev
			an.Count = len(spikes)
			t1, _ := util.ParseHourKey(spikes[0].h)
			t2, _ := util.ParseHourKey(spikes[len(spikes)-1].h)
			an.First, an.Last = t1, t2.Add(time.Hour)
		}
	}
}

// silenceRules detecta fontes que normalmente registram eventos e ficaram mudas.
func (a *Analyzer) silenceRules(active []collectors.Collector) {
	lim := a.cfg.Deteccao.Limites
	if len(a.curCovered) < lim.FonteSilenciosaHorasMinimas {
		return
	}
	keys := a.base.CoveredHoursSince(a.opt.Now.AddDate(0, 0, -a.cfg.LinhaDeBase.Dias))
	if len(keys) == 0 {
		return
	}
	for _, c := range active {
		if c.SnapshotOnly() {
			continue
		}
		src := c.ID()
		st := a.stats[src]
		if st == nil || st.Error != "" || st.Events > 0 {
			continue
		}
		var sum int
		for _, k := range keys {
			sum += a.base.Hours[src][k]
		}
		mean := float64(sum) / float64(len(keys))
		if mean >= lim.FonteSilenciosaMediaMinima {
			an := a.raise("fonte_silenciosa", src, model.Medium, "Fonte de log ficou em silêncio: "+src,
				fmt.Sprintf("Normalmente registra ≈ %.1f eventos por hora de atividade, mas nenhum evento foi registrado em %d horas de atividade da máquina. "+
					"Pode ser serviço de log parado, log redirecionado ou apagado.", mean, len(a.curCovered)), nil)
			if an != nil {
				an.AddSource(src)
				an.First, an.Last = a.opt.Now, a.opt.Now
			}
		}
	}
}

// fileIntegrity verifica truncamento e remoção dos arquivos de log principais.
func (a *Analyzer) fileIntegrity(all []collectors.Collector) {
	seen := map[string]bool{}
	for _, c := range all {
		if !a.cfg.SourceEnabled(c.ID()) {
			continue
		}
		for _, f := range c.WatchedFiles(a.cfg) {
			if seen[f] {
				continue
			}
			seen[f] = true
			st, err := os.Stat(f)
			if err != nil {
				continue
			}
			var ino uint64
			if s, ok := st.Sys().(*syscall.Stat_t); ok {
				ino = s.Ino
			}
			prev, ok := a.base.Files[f]
			if ok && prev.Inode == ino && st.Size() < prev.Size && !a.learning {
				an := a.raise("log_truncado", f, model.High, "Arquivo de log encolheu sem rotação: "+f,
					fmt.Sprintf("Mesmo arquivo (inode %d), mas o tamanho caiu de %s para %s. Apagar trechos de log é técnica de ocultação de rastros.",
						ino, util.HumanBytes(prev.Size), util.HumanBytes(st.Size())), nil)
				if an != nil {
					an.AddSource(c.ID())
					an.First, an.Last = st.ModTime(), st.ModTime()
				}
			}
			a.base.Files[f] = store.FileInfo{Inode: ino, Size: st.Size(), MTime: st.ModTime()}
		}
	}
	for f, prev := range a.base.Files {
		if seen[f] {
			continue
		}
		if _, err := os.Stat(f); os.IsNotExist(err) && !a.learning {
			an := a.raise("log_removido", f, model.High, "Arquivo de log desapareceu: "+f,
				"O arquivo existia na última análise (modificado em "+prev.MTime.Format("02/01 15:04")+") e não existe mais, sem rotação conhecida.", nil)
			if an != nil {
				an.First, an.Last = a.opt.Now, a.opt.Now
			}
			delete(a.base.Files, f)
		}
	}
}

func meanStd(v []float64) (float64, float64) {
	if len(v) == 0 {
		return 0, 0
	}
	var s float64
	for _, x := range v {
		s += x
	}
	m := s / float64(len(v))
	var q float64
	for _, x := range v {
		q += (x - m) * (x - m)
	}
	return m, math.Sqrt(q / float64(len(v)))
}

// commit incorpora o que foi visto nesta execução à linha de base.
func (a *Analyzer) commit(active []collectors.Collector, until time.Time) {
	for src, m := range a.curHours {
		for h, c := range m {
			if !a.cfg.LinhaDeBase.AprenderComAnomalias && a.spikeHours[src][h] {
				continue
			}
			a.base.AddHour(src, h, c)
		}
	}
	for h := range a.curCovered {
		a.base.Covered[h] = true
	}
	for k, t := range a.pendTpl {
		a.base.Templates[k] = t
	}
	skip := map[string]bool{}
	if !a.cfg.LinhaDeBase.AprenderComAnomalias {
		for _, an := range a.anomalies {
			if an.Severity >= model.Critical || an.Rule == "ssh_forca_bruta" {
				skip[an.Entity] = true
			}
		}
	}
	for _, p := range a.pendEnt {
		if skip[p.val] {
			continue // continua sendo tratado como novidade até o usuário resolver
		}
		a.base.TouchEntity(p.cat, p.val, p.extra, p.t)
	}
	for k, v := range a.pendCnt {
		a.base.Counters[k] = v
	}
	if a.procTotal > 0 {
		hk := util.HourKey(a.opt.Now)
		if a.base.Metrics["processos"] == nil {
			a.base.Metrics["processos"] = map[string]float64{}
		}
		a.base.Metrics["processos"][hk] = a.procTotal
	}
	if a.maxTemp > 0 {
		hk := util.HourKey(a.opt.Now)
		if a.base.Metrics["temperatura_max"] == nil {
			a.base.Metrics["temperatura_max"] = map[string]float64{}
		}
		a.base.Metrics["temperatura_max"][hk] = a.maxTemp
	}
	for _, c := range logCategories {
		a.base.InitCategory(c)
	}
	// categorias de fotografia só são inicializadas quando o coletor correspondente rodou
	ran := map[string]bool{}
	for _, c := range active {
		ran[c.ID()] = true
	}
	for cat, src := range snapshotCategoryOwner {
		if ran[src] {
			a.base.InitCategory(cat)
		}
	}
	a.base.LastRun = until
	a.base.Runs++
	a.base.Prune(a.opt.Now, a.cfg.LinhaDeBase.Dias, a.cfg.LinhaDeBase.RetencaoEntidadesDias, a.cfg.LinhaDeBase.MaxModelosPorFonte)
}
