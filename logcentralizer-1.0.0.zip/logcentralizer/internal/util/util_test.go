package util

import (
	"os"
	"path/filepath"
	"testing"
)

func TestTemplate(t *testing.T) {
	a := Template("Failed to connect to 10.0.0.5:5432 after 3 retries (id 7f3a9c2b11ee)")
	b := Template("Failed to connect to 192.168.1.9:5432 after 12 retries (id 0011aabbccdd)")
	if a != b {
		t.Fatalf("modelos diferentes:\n%s\n%s", a, b)
	}
	if Template("disk sda full") == Template("disk sdb error") {
		t.Fatal("mensagens diferentes não podem gerar o mesmo modelo")
	}
}

func TestRotatedOrder(t *testing.T) {
	d := t.TempDir()
	for _, n := range []string{"auth.log", "auth.log.1", "auth.log.2.gz", "auth.log.10.gz", "auth.log.bak"} {
		os.WriteFile(filepath.Join(d, n), []byte("x\n"), 0o644)
	}
	got := RotatedFiles(filepath.Join(d, "auth.log"))
	want := []string{"auth.log.10.gz", "auth.log.2.gz", "auth.log.1", "auth.log"}
	if len(got) != len(want) {
		t.Fatalf("%v", got)
	}
	for i := range want {
		if filepath.Base(got[i]) != want[i] {
			t.Fatalf("ordem errada: %v", got)
		}
	}
}

func TestLooksLikeError(t *testing.T) {
	if !LooksLikeError("Connection refused by peer") || LooksLikeError("Started session 3") {
		t.Fatal("classificação incorreta")
	}
}
