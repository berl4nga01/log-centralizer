package collectors

import (
	"context"
	"encoding/json"
	"fmt"
	"regexp"
	"strconv"
	"strings"
	"time"

	"logcentralizer/internal/config"
	"logcentralizer/internal/model"
	"logcentralizer/internal/util"
)

func itoa(n int) string { return strconv.Itoa(n) }

// ================================================================= logins (wtmp/btmp/lastlog)

type logins struct{ base }

func newLogins() Collector {
	return &logins{base{"logins", "histórico de logins (wtmp/wtmpdb, btmp, lastlog)", "seguranca"}}
}

func (l *logins) Requirements() []Requirement {
	return []Requirement{
		{Kind: "cmd", Name: "last", Package: "wtmpdb", Desc: "logins bem-sucedidos (wtmpdb no Ubuntu 25.04+, util-linux antes)"},
		{Kind: "cmd", Name: "lastb", Package: "util-linux", Optional: true, Desc: "logins falhos (btmp)"},
		{Kind: "cmd", Name: "lastlog2", Package: "lastlog2", Optional: true, Desc: "último login por usuário"},
	}
}

func (l *logins) WatchedFiles(cfg *config.Config) []string {
	return util.ExpandGlobs([]string{"/var/log/wtmp", "/var/log/btmp", "/var/log/wtmp.db", "/var/lib/wtmpdb/wtmp.db"})
}

func (l *logins) Probe(cfg *config.Config) Probe {
	var parts, notes []string
	if util.CmdExists("last") {
		parts = append(parts, "last")
	} else {
		notes = append(notes, "comando 'last' ausente (instale wtmpdb)")
	}
	if util.CmdExists("lastb") && util.Exists("/var/log/btmp") {
		parts = append(parts, "lastb")
	} else {
		notes = append(notes, "btmp/lastb indisponível: falhas de login virão do auth.log/journal")
	}
	if util.CmdExists("lastlog2") {
		parts = append(parts, "lastlog2")
	} else if util.CmdExists("lastlog") {
		parts = append(parts, "lastlog")
	}
	if len(parts) == 0 {
		return Probe{Available: false, Notes: notes}
	}
	return Probe{Available: true, Mode: strings.Join(parts, " + "), Notes: notes}
}

var reLast = regexp.MustCompile(`^(\S+)\s+(system boot|\S+)\s+(\S*)\s+(\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:[+-]\d{2}:?\d{2}|Z)?)`)

func (l *logins) runLast(ctx context.Context, c *Ctx, cmd, kind string) error {
	args := []string{"-i", "-w", "--time-format", "iso",
		"-s", c.Since.Format("2006-01-02 15:04:05"), "-t", c.Until.Format("2006-01-02 15:04:05")}
	return util.RunLines(ctx, func(line string) {
		x := reLast.FindStringSubmatch(line)
		if x == nil {
			return
		}
		user, tty, host := x[1], x[2], x[3]
		t, ok := util.ParseISO(x[4])
		if !ok || !c.InRange(t) {
			return
		}
		e := &model.Event{Time: t, Source: l.id, Program: cmd, Level: -1, Message: strings.TrimSpace(line), Raw: line}
		e.Set("skip_novel", "1")
		if user == "reboot" || user == "shutdown" || tty == "system boot" {
			e.Kind = "boot"
		} else {
			e.Kind = kind
			e.Set("user", user)
			e.Set("tty", tty)
			if host != "0.0.0.0" && host != "" && !strings.HasPrefix(host, ":") {
				e.Set("ip", host)
			}
		}
		c.Emit(e)
	}, cmd, args...)
}

func (l *logins) Collect(ctx context.Context, c *Ctx) error {
	var firstErr error
	if util.CmdExists("last") {
		if err := l.runLast(ctx, c, "last", "login"); err != nil {
			firstErr = err
		}
	}
	if util.CmdExists("lastb") && util.Exists("/var/log/btmp") {
		if err := l.runLast(ctx, c, "lastb", "login_fail"); err != nil && firstErr == nil {
			firstErr = err
		}
	}
	if !c.Learn {
		cmd := ""
		if util.CmdExists("lastlog2") {
			cmd = "lastlog2"
		} else if util.CmdExists("lastlog") {
			cmd = "lastlog"
		}
		if cmd != "" {
			_ = util.RunLines(ctx, func(line string) {
				f := strings.Fields(line)
				if len(f) < 2 || f[0] == "Username" || strings.Contains(line, "Never logged in") {
					return
				}
				e := &model.Event{Time: c.Now, Source: l.id, Kind: "lastlog", Snapshot: true, Message: line}
				e.Set("user", f[0])
				c.Emit(e)
			}, cmd)
		}
	}
	return firstErr
}

// ================================================================= pacotes (apt/dpkg)

type packages struct{ base }

func newPackages() Collector {
	return &packages{base{"pacotes", "pacotes (apt history.log e dpkg.log)", "sistema"}}
}

func (p *packages) aptPaths(cfg *config.Config) []string {
	return cfg.SourcePaths(p.id, []string{"/var/log/apt/history.log", "/var/log/dpkg.log"})
}

func (p *packages) Requirements() []Requirement {
	return []Requirement{
		{Kind: "file", Name: "/var/log/apt/history.log", Package: "apt", Desc: "histórico do apt"},
		{Kind: "file", Name: "/var/log/dpkg.log", Package: "dpkg", Desc: "log do dpkg"},
	}
}

func (p *packages) WatchedFiles(cfg *config.Config) []string {
	return util.ExpandGlobs(p.aptPaths(cfg))
}

func (p *packages) Probe(cfg *config.Config) Probe {
	f := util.ExpandGlobs(p.aptPaths(cfg))
	if len(f) == 0 {
		return Probe{Available: false, Notes: []string{"history.log e dpkg.log inexistentes"}}
	}
	return Probe{Available: true, Mode: "arquivos " + strings.Join(f, ", ")}
}

var reAptPkg = regexp.MustCompile(`([a-z0-9][a-z0-9+.\-]*)(?::[a-z0-9]+)? \(([^)]*)\)`)
var reDpkg = regexp.MustCompile(`^(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}) (install|upgrade|remove|purge|trigproc|configure|startup|status) (.*)$`)

func (p *packages) Collect(ctx context.Context, c *Ctx) error {
	var firstErr error
	for _, path := range util.ExpandGlobs(p.aptPaths(c.Cfg)) {
		if strings.HasSuffix(path, "history.log") || strings.Contains(path, "history") {
			if err := p.readHistory(ctx, c, path); err != nil && firstErr == nil {
				firstErr = err
			}
			continue
		}
		_, err := util.ScanLogFamily(ctx, []string{path}, c.Since, func(_, line string) {
			x := reDpkg.FindStringSubmatch(line)
			if x == nil {
				return
			}
			t, ok := util.ParseISO(x[1])
			if !ok || !c.InRange(t) {
				return
			}
			e := &model.Event{Time: t, Source: p.id, Program: "dpkg", Level: -1, Message: x[2] + " " + x[3], Raw: line}
			e.Set("skip_novel", "1")
			if x[2] == "install" || x[2] == "remove" || x[2] == "purge" {
				e.Kind = "dpkg_" + x[2]
				e.Set("pkg", strings.SplitN(strings.Fields(x[3])[0], ":", 2)[0])
			}
			c.Emit(e)
		})
		if err != nil && firstErr == nil {
			firstErr = err
		}
	}
	return firstErr
}

func (p *packages) readHistory(ctx context.Context, c *Ctx, path string) error {
	var cur *model.Event
	flush := func() {
		if cur != nil && c.InRange(cur.Time) {
			c.Emit(cur)
		}
		cur = nil
	}
	_, err := util.ScanLogFamily(ctx, []string{path}, c.Since, func(_, line string) {
		k, v, ok := strings.Cut(line, ": ")
		if !ok {
			return
		}
		switch k {
		case "Start-Date":
			flush()
			t, ok := util.ParseISO(strings.Join(strings.Fields(v), " "))
			if !ok {
				return
			}
			cur = &model.Event{Time: t, Source: p.id, Program: "apt", Level: -1, Kind: "apt_tx", Message: "transação apt"}
			cur.Set("skip_novel", "1")
		case "Commandline":
			if cur != nil {
				cur.Set("cmd", v)
				cur.Message = "apt: " + v
			}
		case "Requested-By":
			if cur != nil {
				cur.Set("by", v)
			}
		case "Install", "Remove", "Purge", "Upgrade", "Downgrade", "Reinstall":
			if cur == nil {
				return
			}
			var manual []string
			n := 0
			for _, m := range reAptPkg.FindAllStringSubmatch(v, -1) {
				n++
				if !strings.Contains(m[2], "automatic") {
					manual = append(manual, m[1])
				}
			}
			key := strings.ToLower(k)
			cur.Set(key, strings.Join(manual, " "))
			cur.Set(key+"_n", itoa(n))
		case "End-Date":
			flush()
		}
	})
	flush()
	return err
}

// ================================================================= auditd

type audit struct{ base }

func newAudit() Collector {
	return &audit{base{"auditd", "auditd (auditoria do kernel: syscalls, arquivos, autenticação)", "seguranca"}}
}

func (a *audit) paths(cfg *config.Config) []string {
	return cfg.SourcePaths(a.id, []string{"/var/log/audit/audit.log"})
}

func (a *audit) Requirements() []Requirement {
	return []Requirement{
		{Kind: "cmd", Name: "auditctl", Package: "auditd", Desc: "daemon de auditoria"},
		{Kind: "file", Name: "/var/log/audit/audit.log", Package: "auditd", Desc: "log de auditoria"},
	}
}

func (a *audit) WatchedFiles(cfg *config.Config) []string { return util.ExpandGlobs(a.paths(cfg)) }

func (a *audit) Probe(cfg *config.Config) Probe {
	if !util.AnyExists(a.paths(cfg)) {
		return Probe{Available: false, Notes: []string{"auditd não instalado (sudo apt install auditd)"}}
	}
	return Probe{Available: true, Mode: "arquivo " + strings.Join(util.ExpandGlobs(a.paths(cfg)), ", ")}
}

var reAuditHead = regexp.MustCompile(`^(?:node=\S+ )?type=(\S+) msg=audit\((\d+)\.(\d+):(\d+)\):\s*(.*)$`)
var reAuditKV = regexp.MustCompile(`(\w+)=("[^"]*"|'[^']*'|\S+)`)

// readAuditFiles lê audit.log (com rotação audit.log.1 ...).
func readAuditFiles(ctx context.Context, c *Ctx, source string, paths []string, fn func(*model.Event)) error {
	_, err := util.ScanLogFamily(ctx, paths, c.Since, func(_, line string) {
		x := reAuditHead.FindStringSubmatch(line)
		if x == nil {
			return
		}
		sec, _ := strconv.ParseInt(x[2], 10, 64)
		ms, _ := strconv.ParseInt((x[3] + "000")[:3], 10, 64)
		t := time.Unix(sec, ms*1e6).Local()
		if !c.InRange(t) {
			return
		}
		e := &model.Event{Time: t, Source: source, Program: "audit", Level: -1, Message: "type=" + x[1] + " " + x[5], Raw: line}
		e.Set("type", x[1])
		e.Set("serial", x[4])
		for _, kv := range reAuditKV.FindAllStringSubmatch(x[5], -1) {
			v := strings.Trim(kv[2], `"'`)
			switch kv[1] {
			case "res", "success", "key", "exe", "auid", "uid", "acct", "comm", "addr", "op", "terminal":
				if e.Get(kv[1]) == "" {
					e.Set(kv[1], v)
				}
			}
		}
		fn(e)
	})
	return err
}

func (a *audit) Collect(ctx context.Context, c *Ctx) error {
	keys := c.Cfg.Deteccao.ChavesAuditdAlerta
	return readAuditFiles(ctx, c, a.id, a.paths(c.Cfg), func(e *model.Event) {
		e.Set("skip_novel", "1")
		typ := e.Get("type")
		switch {
		case strings.HasPrefix(typ, "ANOM_"):
			e.Kind = "audit_anom"
		case typ == "CONFIG_CHANGE":
			e.Kind = "audit_config"
		case typ == "AVC" && strings.Contains(e.Message, "apparmor="):
			// tratado pela fonte apparmor
		case e.Get("res") == "failed" || e.Get("success") == "no":
			if strings.HasPrefix(typ, "USER_") || typ == "CRED_ACQ" || typ == "LOGIN" {
				e.Kind = "audit_fail"
			}
		}
		if k := e.Get("key"); k != "" && k != "(null)" && config.Contains(keys, k) {
			e.Kind = "audit_key"
		}
		c.Emit(e)
	})
}

// ================================================================= web (nginx/apache)

type web struct {
	base
	access, errors []string
	pkg            string
}

func newWeb(id, name string, access, errs []string, pkg string) Collector {
	return &web{base: base{id, name, "servicos"}, access: access, errors: errs, pkg: pkg}
}

func (w *web) paths(cfg *config.Config) []string {
	return cfg.SourcePaths(w.id, append(append([]string{}, w.access...), w.errors...))
}

func (w *web) Requirements() []Requirement {
	return []Requirement{{Kind: "file", Name: w.access[0], Package: w.pkg, Desc: "log de acesso"}}
}

func (w *web) WatchedFiles(cfg *config.Config) []string { return util.ExpandGlobs(w.paths(cfg)) }

func (w *web) Probe(cfg *config.Config) Probe {
	f := util.ExpandGlobs(w.paths(cfg))
	if len(f) == 0 {
		return Probe{Available: false, Notes: []string{w.pkg + " não instalado"}}
	}
	return Probe{Available: true, Mode: "arquivos " + strings.Join(f, ", ")}
}

var reCombined = regexp.MustCompile(`^(?:\S+:\d+ )?(\S+) \S+ (\S+) \[([^\]]+)\] "(?:(\S+) (\S+)(?: [^"]*)?|[^"]*)" (\d{3}) (\S+)(?: "([^"]*)" "([^"]*)")?`)
var reNginxErr = regexp.MustCompile(`^(\d{4}/\d{2}/\d{2} \d{2}:\d{2}:\d{2}) \[(\w+)\] \d+#\d+: (?:\*\d+ )?(.*)$`)
var reApacheErr = regexp.MustCompile(`^\[(\w{3} \w{3} \d{2} \d{2}:\d{2}:\d{2})(?:\.\d+)? (\d{4})\] \[(?:[\w]+:)?(\w+)\] (.*)$`)
var reClientIP = regexp.MustCompile(`client:? ([0-9a-fA-F.:]+?)(?::\d+)?[,\]]`)

func (w *web) Collect(ctx context.Context, c *Ctx) error {
	_, err := util.ScanLogFamily(ctx, w.paths(c.Cfg), c.Since, func(path, line string) {
		if x := reCombined.FindStringSubmatch(line); x != nil {
			t, err := time.Parse("02/Jan/2006:15:04:05 -0700", x[3])
			if err != nil || !c.InRange(t) {
				return
			}
			e := &model.Event{Time: t.Local(), Source: w.id, Program: w.pkg, Level: -1, Kind: "http", Message: line, Raw: line}
			e.Set("ip", x[1])
			e.Set("method", x[4])
			e.Set("path", x[5])
			e.Set("status", x[6])
			e.Set("ua", x[9])
			e.Set("skip_novel", "1")
			c.Emit(e)
			return
		}
		if x := reNginxErr.FindStringSubmatch(line); x != nil {
			t, err := time.ParseInLocation("2006/01/02 15:04:05", x[1], time.Local)
			if err != nil || !c.InRange(t) {
				return
			}
			e := &model.Event{Time: t, Source: w.id, Program: w.pkg, Level: levelFromWord(x[2]), Kind: "web_error", Message: x[3], Raw: line}
			if m := reClientIP.FindStringSubmatch(x[3]); m != nil {
				e.Set("ip", m[1])
			}
			c.Emit(e)
			return
		}
		if x := reApacheErr.FindStringSubmatch(line); x != nil {
			t, err := time.ParseInLocation("Mon Jan 02 15:04:05 2006", x[1]+" "+x[2], time.Local)
			if err != nil || !c.InRange(t) {
				return
			}
			e := &model.Event{Time: t, Source: w.id, Program: w.pkg, Level: levelFromWord(x[3]), Kind: "web_error", Message: x[4], Raw: line}
			if m := reClientIP.FindStringSubmatch(x[4]); m != nil {
				e.Set("ip", m[1])
			}
			c.Emit(e)
		}
	})
	return err
}

// ================================================================= docker

type docker struct{ base }

func newDocker() Collector {
	return &docker{base{"docker", "Docker / containers (eventos e daemon)", "servicos"}}
}

func (d *docker) Requirements() []Requirement {
	return []Requirement{
		{Kind: "cmd", Name: "docker", Package: "docker.io", Desc: "CLI do Docker"},
		{Kind: "file", Name: "/var/run/docker.sock", Package: "docker.io", Desc: "daemon do Docker em execução"},
	}
}

func (d *docker) Probe(cfg *config.Config) Probe {
	if !util.CmdExists("docker") {
		return Probe{Available: false, Notes: []string{"Docker não instalado"}}
	}
	if !util.Exists("/var/run/docker.sock") {
		return Probe{Available: false, Notes: []string{"daemon do Docker não está em execução"}}
	}
	return Probe{Available: true, Mode: "docker events + journal (docker.service, containerd.service)"}
}

type dockerEvent struct {
	Status string `json:"status"`
	ID     string `json:"id"`
	Type   string `json:"Type"`
	Action string `json:"Action"`
	Actor  struct {
		Attributes map[string]string `json:"Attributes"`
	} `json:"Actor"`
	TimeNano int64 `json:"timeNano"`
}

func (d *docker) Collect(ctx context.Context, c *Ctx) error {
	err := util.RunLines(ctx, func(line string) {
		var ev dockerEvent
		if json.Unmarshal([]byte(line), &ev) != nil {
			return
		}
		t := time.Unix(0, ev.TimeNano).Local()
		if !c.InRange(t) {
			return
		}
		name := ev.Actor.Attributes["name"]
		act := ev.Action
		if i := strings.Index(act, ":"); i > 0 {
			act = act[:i]
		}
		e := &model.Event{Time: t, Source: d.id, Program: "docker", Level: -1,
			Message: fmt.Sprintf("container %s (%s) %s", name, ev.Actor.Attributes["image"], ev.Action)}
		e.Set("skip_novel", "1")
		e.Set("name", name)
		e.Set("image", ev.Actor.Attributes["image"])
		switch act {
		case "die":
			if code := ev.Actor.Attributes["exitCode"]; code != "" && code != "0" {
				e.Kind = "container_die"
				e.Set("exit", code)
			}
		case "oom":
			e.Kind = "container_oom"
		case "restart":
			e.Kind = "container_restart"
		case "start":
			e.Kind = "container_start"
		}
		c.Emit(e)
	}, "docker", "events", "--since", strconv.FormatInt(c.Since.Unix(), 10), "--until", strconv.FormatInt(c.Until.Unix(), 10),
		"--filter", "type=container", "--format", "{{json .}}")
	if journalAvailable() {
		_ = readJournal(ctx, c, d.id, []string{"_SYSTEMD_UNIT=docker.service", "_SYSTEMD_UNIT=containerd.service"}, func(e *model.Event) {
			c.Emit(e)
		})
	}
	return err
}

// ================================================================= MySQL / MariaDB

type mysql struct{ base }

func newMySQL() Collector {
	return &mysql{base{"mysql", "MySQL / MariaDB (error.log)", "servicos"}}
}

func (m *mysql) paths(cfg *config.Config) []string {
	return cfg.SourcePaths(m.id, []string{"/var/log/mysql/error.log", "/var/log/mysql/mysql.err", "/var/log/mysql.err", "/var/log/mariadb/mariadb.log"})
}

func (m *mysql) Requirements() []Requirement {
	return []Requirement{{Kind: "file", Name: "/var/log/mysql/error.log", Package: "mysql-server | mariadb-server", Desc: "log de erros"}}
}

func (m *mysql) WatchedFiles(cfg *config.Config) []string { return util.ExpandGlobs(m.paths(cfg)) }

func (m *mysql) Probe(cfg *config.Config) Probe {
	f := util.ExpandGlobs(m.paths(cfg))
	if len(f) == 0 {
		return Probe{Available: false, Notes: []string{"MySQL/MariaDB não instalado"}}
	}
	return Probe{Available: true, Mode: "arquivos " + strings.Join(f, ", ")}
}

var reMySQL = regexp.MustCompile(`^(\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}:\d{2}(?:\.\d+)?Z?)\s+\d+\s+\[(\w+)\]\s*(?:\[[^\]]*\]\s*)*(.*)$`)
var reMariaDB = regexp.MustCompile(`^(\d{4}-\d{2}-\d{2}\s+\d{1,2}:\d{2}:\d{2})\s+\d+\s+\[(\w+)\]\s+(.*)$`)
var reDBAccess = regexp.MustCompile(`Access denied for user '([^']*)'@'([^']*)'`)
var reDBCrash = regexp.MustCompile(`(?i)(got signal \d+|Assertion failure|was not shut ?down normally|crash recovery|Database page corruption|Shutdown complete|ready for connections)`)

func (m *mysql) Collect(ctx context.Context, c *Ctx) error {
	_, err := util.ScanLogFamily(ctx, m.paths(c.Cfg), c.Since, func(_, line string) {
		x := reMySQL.FindStringSubmatch(line)
		if x == nil {
			x = reMariaDB.FindStringSubmatch(line)
		}
		if x == nil {
			return
		}
		ts := strings.Join(strings.Fields(x[1]), " ")
		t, ok := util.ParseISO(ts)
		if !ok {
			t, ok = util.ParseISO(strings.Replace(ts, " ", "T", 1))
		}
		if !ok || !c.InRange(t) {
			return
		}
		e := &model.Event{Time: t.Local(), Source: m.id, Program: "mysqld", Level: levelFromWord(x[2]), Message: x[3], Raw: line}
		classifyDB(e, x[3])
		c.Emit(e)
	})
	return err
}

func classifyDB(e *model.Event, msg string) {
	if a := reDBAccess.FindStringSubmatch(msg); a != nil {
		e.Kind = "db_auth_fail"
		e.Set("user", a[1])
		e.Set("ip", a[2])
		e.Set("skip_novel", "1")
		return
	}
	if a := rePGAuth.FindStringSubmatch(msg); a != nil {
		e.Kind = "db_auth_fail"
		e.Set("user", a[1]+a[2])
		e.Set("skip_novel", "1")
		return
	}
	if d := reDBCrash.FindString(msg); d != "" {
		switch strings.ToLower(d) {
		case "shutdown complete", "ready for connections":
			e.Kind = "db_restart"
		default:
			e.Kind = "db_crash"
			e.Set("what", d)
		}
		return
	}
	if strings.Contains(msg, "PANIC:") || strings.Contains(msg, "terminated by signal") {
		e.Kind = "db_crash"
		e.Set("what", "PANIC/sinal")
	}
}

// ================================================================= PostgreSQL

type postgres struct{ base }

func newPostgres() Collector {
	return &postgres{base{"postgresql", "PostgreSQL (logs do servidor)", "servicos"}}
}

func (p *postgres) paths(cfg *config.Config) []string {
	return cfg.SourcePaths(p.id, []string{"/var/log/postgresql/postgresql-*.log"})
}

func (p *postgres) Requirements() []Requirement {
	return []Requirement{{Kind: "file", Name: "/var/log/postgresql/postgresql-*.log", Package: "postgresql", Desc: "log do PostgreSQL"}}
}

func (p *postgres) WatchedFiles(cfg *config.Config) []string { return util.ExpandGlobs(p.paths(cfg)) }

func (p *postgres) Probe(cfg *config.Config) Probe {
	f := util.ExpandGlobs(p.paths(cfg))
	if len(f) == 0 {
		return Probe{Available: false, Notes: []string{"PostgreSQL não instalado"}}
	}
	return Probe{Available: true, Mode: "arquivos " + strings.Join(f, ", ")}
}

var rePG = regexp.MustCompile(`^(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}(?:\.\d+)?) (\S+) \[\d+\](?: \S*)? (LOG|ERROR|FATAL|PANIC|WARNING|DETAIL|HINT|STATEMENT|NOTICE|INFO|DEBUG\d?):\s+(.*)$`)
var rePGAuth = regexp.MustCompile(`(?:password authentication failed for user "([^"]*)"|no pg_hba\.conf entry for host "[^"]*", user "([^"]*)")`)

func (p *postgres) Collect(ctx context.Context, c *Ctx) error {
	_, err := util.ScanLogFamily(ctx, p.paths(c.Cfg), c.Since, func(_, line string) {
		x := rePG.FindStringSubmatch(line)
		if x == nil {
			return
		}
		t, ok := parsePGTime(x[1], x[2])
		if !ok || !c.InRange(t) {
			return
		}
		lvl := map[string]int{"PANIC": 0, "FATAL": 2, "ERROR": 3, "WARNING": 4, "NOTICE": 5, "LOG": 6, "INFO": 6}[x[3]]
		if _, ok := map[string]bool{"PANIC": true, "FATAL": true, "ERROR": true, "WARNING": true, "NOTICE": true, "LOG": true, "INFO": true}[x[3]]; !ok {
			lvl = 7
		}
		e := &model.Event{Time: t, Source: p.id, Program: "postgres", Level: lvl, Message: x[3] + ": " + x[4], Raw: line}
		classifyDB(e, x[3]+": "+x[4])
		c.Emit(e)
	})
	return err
}

func parsePGTime(ts, zone string) (time.Time, bool) {
	for _, l := range []string{"2006-01-02 15:04:05.000 -07", "2006-01-02 15:04:05 -07", "2006-01-02 15:04:05.000 MST", "2006-01-02 15:04:05 MST"} {
		if t, err := time.Parse(l, ts+" "+zone); err == nil {
			return t.Local(), true
		}
	}
	return util.ParseISO(ts)
}

// ================================================================= fontes personalizadas

type custom struct {
	base
	fp config.FontePersonalizada
	re *regexp.Regexp
}

func newCustom(fp config.FontePersonalizada) Collector {
	c := &custom{base: base{"custom:" + fp.Nome, "personalizada: " + fp.Nome + " (" + fp.Caminho + ")", "personalizada"}, fp: fp}
	if fp.Formato == "regex" {
		c.re, _ = regexp.Compile(fp.Regex)
	}
	return c
}

func (cu *custom) Requirements() []Requirement {
	return []Requirement{{Kind: "file", Name: cu.fp.Caminho, Package: "-", Desc: "arquivo da aplicação"}}
}

func (cu *custom) WatchedFiles(cfg *config.Config) []string {
	return util.ExpandGlobs([]string{cu.fp.Caminho})
}

func (cu *custom) Probe(cfg *config.Config) Probe {
	if cu.fp.Ativo != nil && !*cu.fp.Ativo {
		return Probe{Available: false, Notes: []string{"desativada na configuração"}}
	}
	if !util.AnyExists([]string{cu.fp.Caminho}) {
		return Probe{Available: false, Notes: []string{"arquivo não encontrado: " + cu.fp.Caminho}}
	}
	f := cu.fp.Formato
	if f == "" {
		f = "texto"
	}
	return Probe{Available: true, Mode: "arquivo (" + f + ") " + cu.fp.Caminho}
}

var reLeadTS = regexp.MustCompile(`^\[?(\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}:\d{2}(?:[.,]\d+)?(?:Z|\s?[+-]\d{2}:?\d{2})?)\]?\s*(.*)$`)
var reLeadLevel = regexp.MustCompile(`^\[?(EMERG|ALERT|CRIT(?:ICAL)?|FATAL|ERR(?:OR)?|WARN(?:ING)?|NOTICE|INFO|DEBUG|TRACE)\]?:?\s+(.*)$`)

func parseFlexibleTime(v, layout string) (time.Time, bool) {
	v = strings.TrimSpace(v)
	if layout != "" {
		if t, err := time.ParseInLocation(layout, v, time.Local); err == nil {
			return t, true
		}
	}
	if t, ok := util.ParseISO(strings.Replace(v, ",", ".", 1)); ok {
		return t, true
	}
	if n, err := strconv.ParseFloat(v, 64); err == nil && n > 1e9 {
		if n > 1e12 {
			return time.UnixMilli(int64(n)), true
		}
		return time.Unix(int64(n), int64((n-float64(int64(n)))*1e9)), true
	}
	return time.Time{}, false
}

func (cu *custom) Collect(ctx context.Context, c *Ctx) error {
	switch cu.fp.Formato {
	case "syslog":
		return readSyslogFiles(ctx, c, cu.id, []string{cu.fp.Caminho}, c.Emit)
	}
	var lastT time.Time
	_, err := util.ScanLogFamily(ctx, []string{cu.fp.Caminho}, c.Since, func(_, line string) {
		if strings.TrimSpace(line) == "" {
			return
		}
		var t time.Time
		var msg string
		lvl := -1
		ok := false
		switch cu.fp.Formato {
		case "json":
			var obj map[string]any
			if json.Unmarshal([]byte(line), &obj) != nil {
				return
			}
			tf, mf, lf := orDef(cu.fp.CampoTempo, "time"), orDef(cu.fp.CampoMensagem, "msg"), orDef(cu.fp.CampoNivel, "level")
			t, ok = parseFlexibleTime(fmt.Sprint(obj[tf]), cu.fp.LayoutTempo)
			if v, has := obj[mf]; has {
				msg = fmt.Sprint(v)
			} else if v, has := obj["message"]; has {
				msg = fmt.Sprint(v)
			} else {
				msg = line
			}
			if v, has := obj[lf]; has {
				lvl = levelFromWord(fmt.Sprint(v))
			}
		case "regex":
			if cu.re == nil {
				return
			}
			m := cu.re.FindStringSubmatch(line)
			if m == nil {
				return
			}
			msg = line
			for i, n := range cu.re.SubexpNames() {
				switch n {
				case "time", "tempo":
					t, ok = parseFlexibleTime(m[i], cu.fp.LayoutTempo)
				case "message", "mensagem", "msg":
					msg = m[i]
				case "level", "nivel":
					lvl = levelFromWord(m[i])
				}
			}
		default: // texto
			if x := reLeadTS.FindStringSubmatch(line); x != nil {
				t, ok = parseFlexibleTime(x[1], cu.fp.LayoutTempo)
				msg = x[2]
			} else if cu.fp.LayoutTempo != "" && len(line) >= len(cu.fp.LayoutTempo) {
				t, ok = parseFlexibleTime(line[:len(cu.fp.LayoutTempo)], cu.fp.LayoutTempo)
				msg = strings.TrimSpace(line[len(cu.fp.LayoutTempo):])
			}
			if !ok {
				if lastT.IsZero() {
					return
				}
				t, ok, msg = lastT, true, line // linha de continuação
			}
			if l := reLeadLevel.FindStringSubmatch(msg); l != nil {
				lvl = levelFromWord(l[1])
			}
		}
		if !ok {
			return
		}
		lastT = t
		if !c.InRange(t) {
			return
		}
		c.Emit(&model.Event{Time: t, Source: cu.id, Program: cu.fp.Nome, Level: lvl, Message: msg, Raw: line})
	})
	return err
}

func orDef(v, d string) string {
	if v == "" {
		return d
	}
	return v
}

