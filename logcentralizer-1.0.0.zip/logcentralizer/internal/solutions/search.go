package solutions

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"html"
	"io"
	"net/http"
	"net/url"
	"regexp"
	"strings"
	"time"

	"logcentralizer/internal/config"
	"logcentralizer/internal/model"
	"logcentralizer/internal/store"
	"logcentralizer/internal/util"
)

const userAgent = "Mozilla/5.0 (X11; Linux x86_64) logcentralizer/1.0"

// Searcher pesquisa soluções na internet usando os provedores configurados.
type Searcher struct {
	cfg    *config.Config
	client *http.Client
	cache  *store.SearchCache
	used   int
	Errors []string
}

// NewSearcher cria o pesquisador.
func NewSearcher(cfg *config.Config, cache *store.SearchCache) *Searcher {
	tr := &http.Transport{Proxy: http.ProxyFromEnvironment}
	if cfg.BuscaWeb.Proxy != "" {
		if u, err := url.Parse(cfg.BuscaWeb.Proxy); err == nil {
			tr.Proxy = http.ProxyURL(u)
		}
	}
	to := time.Duration(cfg.BuscaWeb.TimeoutSegundos) * time.Second
	if to <= 0 {
		to = 10 * time.Second
	}
	return &Searcher{cfg: cfg, cache: cache, client: &http.Client{Timeout: to, Transport: tr}}
}

// Used devolve quantas consultas reais foram feitas.
func (s *Searcher) Used() int { return s.used }

// Search consulta o cache e depois os provedores em ordem.
func (s *Searcher) Search(ctx context.Context, q string) ([]model.SearchResult, string, error) {
	n := s.cfg.BuscaWeb.ResultadosPorBusca
	if n <= 0 {
		n = 3
	}
	if s.cache != nil {
		if c, ok := s.cache.Entries[q]; ok && time.Since(c.Time) < time.Duration(s.cfg.BuscaWeb.CacheDias)*24*time.Hour {
			var out []model.SearchResult
			for _, r := range c.Results {
				var x model.SearchResult
				if json.Unmarshal(r, &x) == nil {
					out = append(out, x)
				}
			}
			if len(out) > 0 {
				return out, c.Engine + " (cache)", nil
			}
		}
	}
	var errs []string
	for _, p := range s.cfg.BuscaWeb.Provedores {
		var res []model.SearchResult
		var err error
		switch strings.ToLower(p) {
		case "brave":
			if s.cfg.BuscaWeb.BraveChaveAPI == "" {
				continue
			}
			res, err = s.brave(ctx, q, n)
		case "duckduckgo", "ddg":
			res, err = s.duck(ctx, q, n)
		default:
			continue
		}
		s.used++
		if err != nil {
			errs = append(errs, p+": "+err.Error())
			continue
		}
		if len(res) == 0 {
			errs = append(errs, p+": nenhum resultado")
			continue
		}
		if s.cache != nil {
			cs := &store.CachedSearch{Time: time.Now(), Engine: p}
			for _, r := range res {
				b, _ := json.Marshal(r)
				cs.Results = append(cs.Results, b)
			}
			s.cache.Entries[q] = cs
		}
		return res, p, nil
	}
	if len(errs) == 0 {
		return nil, "", errors.New("nenhum provedor de busca configurado")
	}
	return nil, "", errors.New(strings.Join(errs, "; "))
}

func (s *Searcher) get(ctx context.Context, req *http.Request) ([]byte, error) {
	req.Header.Set("User-Agent", userAgent)
	resp, err := s.client.Do(req.WithContext(ctx))
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()
	body, err := io.ReadAll(io.LimitReader(resp.Body, 4<<20))
	if err != nil {
		return nil, err
	}
	if resp.StatusCode != 200 {
		return nil, fmt.Errorf("HTTP %d", resp.StatusCode)
	}
	return body, nil
}

// ---------------------------------------------------------------- Brave

type braveResp struct {
	Web struct {
		Results []struct {
			Title       string `json:"title"`
			URL         string `json:"url"`
			Description string `json:"description"`
		} `json:"results"`
	} `json:"web"`
}

func (s *Searcher) brave(ctx context.Context, q string, n int) ([]model.SearchResult, error) {
	v := url.Values{}
	v.Set("q", q)
	v.Set("count", fmt.Sprint(n))
	v.Set("safesearch", "moderate")
	req, _ := http.NewRequest("GET", "https://api.search.brave.com/res/v1/web/search?"+v.Encode(), nil)
	req.Header.Set("Accept", "application/json")
	req.Header.Set("X-Subscription-Token", s.cfg.BuscaWeb.BraveChaveAPI)
	body, err := s.get(ctx, req)
	if err != nil {
		return nil, err
	}
	var br braveResp
	if err := json.Unmarshal(body, &br); err != nil {
		return nil, err
	}
	var out []model.SearchResult
	for _, r := range br.Web.Results {
		out = append(out, model.SearchResult{Title: stripTags(r.Title), URL: r.URL, Snippet: stripTags(r.Description), Engine: "brave"})
		if len(out) >= n {
			break
		}
	}
	return out, nil
}

// ---------------------------------------------------------------- DuckDuckGo (sem chave)

var (
	reDDGLink    = regexp.MustCompile(`(?s)<a[^>]+class="result__a"[^>]+href="([^"]+)"[^>]*>(.*?)</a>`)
	reDDGLink2   = regexp.MustCompile(`(?s)<a[^>]+href="([^"]+)"[^>]+class="result__a"[^>]*>(.*?)</a>`)
	reDDGSnippet = regexp.MustCompile(`(?s)class="result__snippet"[^>]*>(.*?)</(?:a|div|td)>`)
	reLiteLink   = regexp.MustCompile(`(?s)<a[^>]+href="([^"]+)"[^>]+class=['"]result-link['"][^>]*>(.*?)</a>`)
	reLiteLink2  = regexp.MustCompile(`(?s)<a[^>]+class=['"]result-link['"][^>]+href="([^"]+)"[^>]*>(.*?)</a>`)
	reLiteSnip   = regexp.MustCompile(`(?s)<td[^>]+class=['"]result-snippet['"][^>]*>(.*?)</td>`)
	reTags       = regexp.MustCompile(`<[^>]+>`)
)

func stripTags(s string) string {
	s = reTags.ReplaceAllString(s, "")
	s = html.UnescapeString(s)
	return strings.Join(strings.Fields(s), " ")
}

func decodeDDGURL(h string) string {
	h = html.UnescapeString(h)
	if strings.HasPrefix(h, "//") {
		h = "https:" + h
	}
	u, err := url.Parse(h)
	if err != nil {
		return h
	}
	if strings.Contains(u.Host, "duckduckgo.com") && u.Path == "/l/" {
		if t := u.Query().Get("uddg"); t != "" {
			return t
		}
	}
	return h
}

// ParseDDG extrai resultados do HTML do DuckDuckGo (versões html e lite).
func ParseDDG(body string, n int) []model.SearchResult {
	var out []model.SearchResult
	links := reDDGLink.FindAllStringSubmatch(body, -1)
	if len(links) == 0 {
		links = reDDGLink2.FindAllStringSubmatch(body, -1)
	}
	snips := reDDGSnippet.FindAllStringSubmatch(body, -1)
	if len(links) == 0 {
		links = reLiteLink.FindAllStringSubmatch(body, -1)
		if len(links) == 0 {
			links = reLiteLink2.FindAllStringSubmatch(body, -1)
		}
		snips = reLiteSnip.FindAllStringSubmatch(body, -1)
	}
	for i, l := range links {
		u := decodeDDGURL(l[1])
		if strings.Contains(u, "duckduckgo.com/y.js") || strings.Contains(u, "ad_domain") || !strings.HasPrefix(u, "http") {
			continue
		}
		r := model.SearchResult{Title: stripTags(l[2]), URL: u, Engine: "duckduckgo"}
		if i < len(snips) {
			r.Snippet = stripTags(snips[i][1])
		}
		out = append(out, r)
		if len(out) >= n {
			break
		}
	}
	return out
}

func (s *Searcher) duck(ctx context.Context, q string, n int) ([]model.SearchResult, error) {
	form := url.Values{}
	form.Set("q", q)
	form.Set("kl", ddgRegion(s.cfg.BuscaWeb.Idioma))
	req, _ := http.NewRequest("POST", "https://html.duckduckgo.com/html/", strings.NewReader(form.Encode()))
	req.Header.Set("Content-Type", "application/x-www-form-urlencoded")
	req.Header.Set("Accept-Language", s.cfg.BuscaWeb.Idioma+",en;q=0.8")
	body, err := s.get(ctx, req)
	if err == nil {
		if res := ParseDDG(string(body), n); len(res) > 0 {
			return res, nil
		}
	}
	// alternativa: versão lite
	req2, _ := http.NewRequest("GET", "https://lite.duckduckgo.com/lite/?"+form.Encode(), nil)
	body2, err2 := s.get(ctx, req2)
	if err2 != nil {
		if err != nil {
			return nil, err
		}
		return nil, err2
	}
	res := ParseDDG(string(body2), n)
	if len(res) == 0 {
		return nil, errors.New("resposta sem resultados (o DuckDuckGo pode ter limitado as consultas automáticas)")
	}
	return res, nil
}

func ddgRegion(lang string) string {
	switch strings.ToLower(lang) {
	case "pt-br":
		return "br-pt"
	case "pt-pt", "pt":
		return "pt-pt"
	case "es", "es-ar":
		return "ar-es"
	}
	return "wt-wt"
}

// ---------------------------------------------------------------- enriquecimento

// Enrich anexa a solução local a todas as anomalias e pesquisa na internet as
// mais graves (respeitando o limite de consultas por execução).
func Enrich(ctx context.Context, cfg *config.Config, list []*model.Anomaly, cache *store.SearchCache, web bool, progress func(string)) *Searcher {
	s := NewSearcher(cfg, cache)
	min, _ := model.ParseSeverity(cfg.BuscaWeb.SeveridadeMinima)
	done := map[string][]model.SearchResult{}
	queries, netFails := 0, 0
	offline := ""
	for _, a := range list {
		sol, q, ok := Lookup(a.Rule)
		if ok {
			a.Solution = sol
		}
		if !web || !cfg.BuscaWeb.Ativo || a.Severity < min {
			continue
		}
		query := buildQuery(a, q)
		if query == "" {
			continue
		}
		a.WebQuery = query
		if r, ok := done[query]; ok {
			a.Web = r
			continue
		}
		if offline != "" {
			a.WebError = offline
			continue
		}
		if queries >= cfg.BuscaWeb.MaxBuscasPorExecucao {
			a.WebError = "limite de pesquisas por execução atingido (busca_web.max_buscas_por_execucao)"
			continue
		}
		queries++
		if progress != nil {
			progress(query)
		}
		res, eng, err := s.Search(ctx, query)
		if err != nil {
			a.WebError = err.Error()
			s.Errors = append(s.Errors, err.Error())
			if !strings.Contains(err.Error(), "nenhum resultado") {
				netFails++
				if netFails >= 2 {
					offline = "pesquisa interrompida: a internet/provedor de busca não está acessível (" + util.Truncate(err.Error(), 120) + ")"
				}
			}
			continue
		}
		netFails = 0
		for i := range res {
			if strings.HasSuffix(eng, "(cache)") {
				res[i].Engine += " (cache)"
			}
		}
		a.Web = res
		done[query] = res
	}
	return s
}

var reVarPlaceholder = regexp.MustCompile(`<[a-z]+>`)
var reQuerySafe = regexp.MustCompile(`[^\p{L}\p{N}\s._\-:/]+`)

func buildQuery(a *model.Anomaly, base string) string {
	hint := a.SearchHint
	switch a.Rule {
	case "servico_falhou", "servico_reinicio_loop":
		hint = a.Entity
	case "oom", "segfault", "core_dump":
		hint = a.Entity
	case "kernel_erro", "hardware_erro", "disco_io_erro":
		hint = a.Entity
	case "erro_novo":
		base = ""
	}
	q := strings.TrimSpace("ubuntu " + base + " " + reVarPlaceholder.ReplaceAllString(hint, " "))
	q = reQuerySafe.ReplaceAllString(q, " ")
	q = strings.Join(strings.Fields(q), " ")
	if len([]rune(q)) > 140 {
		q = string([]rune(q)[:140])
	}
	if q == "ubuntu" {
		return ""
	}
	return q
}
